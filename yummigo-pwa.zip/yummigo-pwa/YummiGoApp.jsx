import { useState, useEffect, useRef } from "react";

// ─────────────────────────────────────────
// SUPABASE
// ─────────────────────────────────────────
const SB_URL = "https://fmeaecwbxhyihsdzfran.supabase.co";
const SB_KEY = "sb_publishable_JrCQZ5MdSUwhR0s1rXr8DA_gUgT6diR";
const sbH = { "apikey": SB_KEY, "Authorization": `Bearer ${SB_KEY}`, "Content-Type": "application/json", "Prefer": "return=representation" };

// Safe fetch — never throws, always returns array
const sbSafe = (url, opts={}) =>
  fetch(url, opts)
    .then(r => r.ok ? r.json() : [])
    .catch(() => []);

const sbGet   = (t, q="") => sbSafe(`${SB_URL}/rest/v1/${t}?${q}`, { headers: sbH });
const sbPost  = (t, b)    => sbSafe(`${SB_URL}/rest/v1/${t}`,     { method:"POST",  headers: sbH, body: JSON.stringify(b) });
const sbPatch = (t, id, b)=> sbSafe(`${SB_URL}/rest/v1/${t}?id=eq.${id}`, { method:"PATCH", headers: sbH, body: JSON.stringify(b) });
const sbDel   = (t, id)   => fetch(`${SB_URL}/rest/v1/${t}?id=eq.${id}`, { method:"DELETE", headers: sbH }).then(r=>r.ok).catch(()=>false);

// ─── DEMO DATA (shown while DB loads or if DB is empty) ───
const DEMO_RESTAURANTS = [
  { id:1, name:"Nápoli Pizza", cuisine:"Italiana · Pizza", emoji:"🍕", rating:4.8, hours:"12:00–23:00", active:true },
  { id:2, name:"Big Burger Co.", cuisine:"Americana · Burgers", emoji:"🍔", rating:4.7, hours:"11:00–22:00", active:true },
  { id:3, name:"Sushi Miyako", cuisine:"Japonesa · Sushi", emoji:"🍣", rating:4.9, hours:"13:00–22:00", active:true },
  { id:4, name:"Tacos El Güero", cuisine:"Mexicana · Tacos", emoji:"🌮", rating:4.6, hours:"08:00–01:00", active:true },
  { id:5, name:"Green Bowl", cuisine:"Saludable · Ensaladas", emoji:"🥗", rating:4.5, hours:"09:00–21:00", active:true },
  { id:6, name:"Pollo Bravo", cuisine:"Mexicana · Pollo", emoji:"🍗", rating:4.4, hours:"10:00–22:00", active:true },
];
const DEMO_MENU_ITEMS = [
  { id:101, restaurant_id:1, name:"Pizza Margherita", description:"Tomate, mozzarella y albahaca", price:120, category:"Pizzas", available:true },
  { id:102, restaurant_id:1, name:"Pizza Pepperoni", description:"Pepperoni y queso extra", price:145, category:"Pizzas", available:true },
  { id:103, restaurant_id:1, name:"Agua de limón", description:"Fresca y natural", price:30, category:"Bebidas", available:true },
  { id:201, restaurant_id:2, name:"Clásica Burger", description:"Carne, lechuga, tomate y cheddar", price:95, category:"Burgers", available:true },
  { id:202, restaurant_id:2, name:"BBQ Burger", description:"Con tocino y salsa BBQ", price:115, category:"Burgers", available:true },
  { id:301, restaurant_id:3, name:"Salmón Roll (8 pzas)", description:"Salmón fresco, aguacate", price:165, category:"Rolls", available:true },
  { id:401, restaurant_id:4, name:"Tacos de Pastor (3)", description:"Con piña, cilantro y cebolla", price:65, category:"Entradas", available:true },
  { id:402, restaurant_id:4, name:"Quesadillas (2)", description:"Queso Oaxaca y frijoles", price:75, category:"Entradas", available:true },
];

// ─────────────────────────────────────────
// CONSTANTS
// ─────────────────────────────────────────
const EMOJI_BG = { "🍕":"#FFF5F5","🍔":"#F0F9FF","🍣":"#F5F3FF","🌮":"#FFFBEB","🥗":"#F0FDF4","🍜":"#FFF7ED","🍗":"#FEF9C3","🧁":"#FDF4FF","🍽️":"#F9FAFB" };
const CAT_COLORS = { "Pizzas":"#FF4D4D","Burgers":"#F59E0B","Rolls":"#6366F1","Bebidas":"#06B6D4","Acompañamientos":"#16A34A","Entradas":"#8B5CF6","Postres":"#EC4899","Otros":"#6B7280" };
const TAG_COLORS = ["#FF4D4D","#2563EB","#7C3AED","#16A34A","#F59E0B"];
const loadAddresses = () => { try { return JSON.parse(localStorage.getItem("userAddresses")||"[]"); } catch { return []; } };
const saveAddresses = (list) => localStorage.setItem("userAddresses", JSON.stringify(list));
const PAYMENT_STATIC = [{ id:"cash", label:"Efectivo", icon:"💵", sub:"Pago al repartidor", type:"cash" }];
const loadPayments = () => { try { return JSON.parse(localStorage.getItem("userPayments")||"[]"); } catch { return []; } };
const savePayments = (list) => localStorage.setItem("userPayments", JSON.stringify(list));
const PROMOS_FREE_SHIPPING = ["BIENVENIDO"];
const PROMOS_DISCOUNT = ["PIZZA10","VERANO25"];
const CATS = ["Pizzas","Burgers","Rolls","Bebidas","Acompañamientos","Entradas","Postres","Otros"];
const EMOJIS = ["🍕","🍔","🌮","🍣","🥗","🍜","🍗","🧁","🥩","🌯","🍛","🥪","🍽️"];
const FILTER_CATS = [
  { id:1, icon:"🍕", label:"Pizza",    kw:"pizza" },
  { id:2, icon:"🍔", label:"Burgers",  kw:"burger" },
  { id:3, icon:"🌮", label:"Tacos",    kw:"taco" },
  { id:4, icon:"🍣", label:"Sushi",    kw:"sushi" },
  { id:5, icon:"🥗", label:"Saludable",kw:"saludable" },
  { id:6, icon:"🍗", label:"Pollo",    kw:"pollo" },
  { id:7, icon:"🧁", label:"Postres",  kw:"postre" },
];

// ─────────────────────────────────────────
// AUTH — CREDENTIALS
// ─────────────────────────────────────────
// ✅ CREDENCIALES DE ADMINISTRADOR
//    Usuario:    admin@yummigo.mx
//    Contraseña: YummiAdmin2025#
//
// ✅ CREDENCIALES DE REPARTIDOR (ejemplo pre-cargado)
//    Usuario:    carlos@yummigo.mx
//    Contraseña: Repartidor123#

const ADMIN_CREDENTIALS = { user:"admin@yummigo.mx", pass:"YummiAdmin2025#" };

// Repartidores se guardan en localStorage
const loadDrivers = () => {
  try {
    const saved = JSON.parse(localStorage.getItem("yg_drivers")||"null");
    if(saved) return saved;
    // Repartidor de ejemplo pre-cargado
    return [{ id:1, name:"Carlos Mendoza", user:"carlos@yummigo.mx", pass:"Repartidor123#", phone:"449-100-0001", vehicle:"Honda CB125", plate:"MXZ-4821", active:true, createdAt:"2025-01-01" }];
  } catch { return []; }
};
const saveDrivers = (list) => localStorage.setItem("yg_drivers", JSON.stringify(list));

// Session helpers
const getSession  = () => { try { return JSON.parse(localStorage.getItem("yg_session")||"null"); } catch { return null; } };
const setSession  = (s)  => localStorage.setItem("yg_session", JSON.stringify(s));
const clearSession= ()   => localStorage.removeItem("yg_session");

// ─────────────────────────────────────────
// LOGIN SCREEN (shared for admin & driver)
// ─────────────────────────────────────────
function LoginScreen({ role, onSuccess, onBack }) {
  const [user, setUser]   = useState("");
  const [pass, setPass]   = useState("");
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [shake, setShake] = useState(false);

  const isAdmin      = role === "admin";
  const isDriver     = role === "driver";
  const isRestaurant = role === "restaurant";
  const title    = isAdmin ? "Panel de Admin" : isDriver ? "Panel del Repartidor" : "Panel de Restaurante";
  const icon     = isAdmin ? "⚙️" : isDriver ? "🛵" : "🍽️";
  const accent   = isAdmin ? "#6366F1" : isDriver ? "#FF4D4D" : "#F97316";

  const doLogin = () => {
    setError(""); setLoading(true);
    setTimeout(() => {
      if (isAdmin) {
        if (user.trim().toLowerCase() === ADMIN_CREDENTIALS.user && pass === ADMIN_CREDENTIALS.pass) {
          setSession({ role:"admin", user: ADMIN_CREDENTIALS.user, name:"Administrador" });
          onSuccess({ role:"admin", user: ADMIN_CREDENTIALS.user, name:"Administrador" });
        } else {
          setError("Usuario o contraseña incorrectos"); setShake(true); setTimeout(()=>setShake(false),600);
        }
      } else if (isDriver) {
        const drivers = loadDrivers();
        const found = drivers.find(d => d.user.toLowerCase() === user.trim().toLowerCase() && d.pass === pass && d.active);
        if (found) {
          setSession({ role:"driver", user: found.user, name: found.name, driverId: found.id });
          onSuccess({ role:"driver", user: found.user, name: found.name, driverId: found.id });
        } else {
          setError("Credenciales incorrectas o cuenta inactiva"); setShake(true); setTimeout(()=>setShake(false),600);
        }
      } else if (isRestaurant) {
        const accounts = loadRestaurantAccounts();
        const found = accounts.find(a => a.user.toLowerCase() === user.trim().toLowerCase() && a.pass === pass && a.active);
        if (found) {
          const s = { role:"restaurant", user: found.user, name: found.restaurantName, restaurantName: found.restaurantName, restaurantEmoji: found.emoji||"🍽️", restaurantId: found.restaurantId };
          setSession(s); onSuccess(s);
        } else {
          setError("Credenciales incorrectas o restaurante inactivo"); setShake(true); setTimeout(()=>setShake(false),600);
        }
      }
      setLoading(false);
    }, 700);
  };

  return (
    <div style={{ background:"#F9FAFB", minHeight:"100vh", display:"flex", flexDirection:"column" }}>
      <style>{`@keyframes shake{0%,100%{transform:translateX(0)}20%,60%{transform:translateX(-8px)}40%,80%{transform:translateX(8px)}}`}</style>

      {/* Header */}
      <div style={{ background:"#fff", padding:"14px 24px 18px", borderBottom:"1px solid #F3F4F6" }}>
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          <div onClick={onBack} style={{ width:38,height:38,borderRadius:12,background:"#F9FAFB",border:"1.5px solid #F3F4F6",fontSize:18,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center" }}>←</div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:17, fontWeight:800, color:"#111" }}>{title}</div>
            <div style={{ fontSize:12, color:"#9CA3AF" }}>Acceso restringido</div>
          </div>
        </div>
      </div>

      {/* Body */}
      <div style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:"32px 24px" }}>
        {/* Icon badge */}
        <div style={{ width:88,height:88,borderRadius:28,background:`linear-gradient(135deg,${accent},${accent}cc)`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:40,marginBottom:24,boxShadow:`0 8px 32px ${accent}40` }}>
          {icon}
        </div>
        <div style={{ fontSize:22,fontWeight:900,color:"#111",marginBottom:6 }}>{title}</div>
        <div style={{ fontSize:14,color:"#9CA3AF",marginBottom:36,textAlign:"center",lineHeight:1.5 }}>
          {isAdmin ? "Solo el administrador puede acceder a este panel." : "Ingresa tus credenciales de repartidor."}
        </div>

        {/* Form */}
        <div style={{ width:"100%", maxWidth:360, animation:shake?"shake 0.5s ease":"none" }}>
          {/* User field */}
          <div style={{ marginBottom:14 }}>
            <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>USUARIO / CORREO</div>
            <div style={{ position:"relative" }}>
              <span style={{ position:"absolute",left:14,top:"50%",transform:"translateY(-50%)",fontSize:16,opacity:0.4 }}>👤</span>
              <input value={user} onChange={e=>{setUser(e.target.value);setError("");}}
                onKeyDown={e=>e.key==="Enter"&&doLogin()}
                placeholder={isAdmin?"admin@yummigo.mx":"tu@correo.mx"}
                autoCapitalize="none" autoComplete="username"
                style={{ width:"100%",padding:"13px 14px 13px 44px",background:"#fff",border:`2px solid ${error?"#FF4D4D":"#F3F4F6"}`,borderRadius:14,fontSize:15,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box",transition:"border-color 0.2s" }}
                onFocus={e=>e.target.style.borderColor=accent} onBlur={e=>e.target.style.borderColor=error?"#FF4D4D":"#F3F4F6"}/>
            </div>
          </div>

          {/* Pass field */}
          <div style={{ marginBottom:error?8:24 }}>
            <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>CONTRASEÑA</div>
            <div style={{ position:"relative" }}>
              <span style={{ position:"absolute",left:14,top:"50%",transform:"translateY(-50%)",fontSize:16,opacity:0.4 }}>🔒</span>
              <input value={pass} onChange={e=>{setPass(e.target.value);setError("");}}
                onKeyDown={e=>e.key==="Enter"&&doLogin()}
                type={showPass?"text":"password"} placeholder="••••••••"
                autoComplete="current-password"
                style={{ width:"100%",padding:"13px 48px 13px 44px",background:"#fff",border:`2px solid ${error?"#FF4D4D":"#F3F4F6"}`,borderRadius:14,fontSize:15,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box",transition:"border-color 0.2s" }}
                onFocus={e=>e.target.style.borderColor=accent} onBlur={e=>e.target.style.borderColor=error?"#FF4D4D":"#F3F4F6"}/>
              <span onClick={()=>setShowPass(p=>!p)} style={{ position:"absolute",right:14,top:"50%",transform:"translateY(-50%)",fontSize:18,cursor:"pointer",opacity:0.4 }}>{showPass?"🙈":"👁️"}</span>
            </div>
          </div>

          {/* Error */}
          {error && (
            <div style={{ display:"flex",alignItems:"center",gap:8,background:"#FFF5F5",border:"1.5px solid #FFE4E4",borderRadius:10,padding:"10px 14px",marginBottom:20,animation:"fadeUp 0.2s ease" }}>
              <span style={{ fontSize:16 }}>⚠️</span>
              <span style={{ fontSize:13,color:"#FF4D4D",fontWeight:600 }}>{error}</span>
            </div>
          )}

          {/* Submit */}
          <button onClick={doLogin} disabled={loading||!user||!pass}
            style={{ width:"100%",padding:"16px",background:(!user||!pass)?"#E5E7EB":accent,color:(!user||!pass)?"#9CA3AF":"#fff",border:"none",borderRadius:16,fontSize:15,fontWeight:700,cursor:(!user||!pass)?"not-allowed":"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",justifyContent:"center",gap:10,transition:"all 0.2s",boxShadow:(!user||!pass)?"none":`0 4px 16px ${accent}40` }}>
            {loading ? (
              <><div style={{ width:18,height:18,borderRadius:99,border:"2px solid rgba(255,255,255,0.4)",borderTopColor:"#fff",animation:"spin 0.7s linear infinite" }}/> Verificando...</>
            ) : `Ingresar al ${isAdmin?"panel de admin":isRestaurant?"panel de restaurante":"panel del repartidor"} →`}
          </button>
        </div>

        {/* Hint box */}
        <div style={{ marginTop:32,background:"#fff",borderRadius:16,padding:"14px 18px",width:"100%",maxWidth:360,border:"1.5px solid #F3F4F6" }}>
          <div style={{ fontSize:12,fontWeight:700,color:"#9CA3AF",marginBottom:8,letterSpacing:0.5 }}>🔐 ACCESO AUTORIZADO</div>
          <div style={{ fontSize:13,color:"#374151",lineHeight:1.6 }}>
          {isAdmin
            ? "Solo el dueño de la plataforma tiene acceso a este panel. Si olvidaste tus credenciales, contacta a soporte técnico."
            : isDriver
            ? "Tu usuario y contraseña fueron asignados por el administrador. Si tienes problemas para acceder, contáctalo directamente."
            : "Tu usuario y contraseña fueron asignados por el administrador de YummiGoApp. Contacta soporte si tienes problemas."}
          </div>
        </div>
      </div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}

// ─────────────────────────────────────────
// SHARED COMPONENTS
// ─────────────────────────────────────────
function Skeleton({ w="100%", h=14, r=8 }) {
  return <div style={{ width:w, height:h, borderRadius:r, background:"linear-gradient(90deg,#F3F4F6 25%,#E5E7EB 50%,#F3F4F6 75%)", backgroundSize:"200% 100%", animation:"shimmer 1.4s infinite" }} />;
}
function Toggle({ value, onChange }) {
  return (
    <div onClick={onChange} style={{ width:44, height:26, borderRadius:99, background:value?"#FF4D4D":"#E5E7EB", position:"relative", cursor:"pointer", transition:"background 0.2s", flexShrink:0 }}>
      <div style={{ position:"absolute", top:3, left:value?21:3, width:20, height:20, borderRadius:99, background:"#fff", boxShadow:"0 1px 4px rgba(0,0,0,0.2)", transition:"left 0.2s" }} />
    </div>
  );
}
function Modal({ title, onClose, children }) {
  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.45)", zIndex:600, display:"flex", alignItems:"flex-end", justifyContent:"center" }} onClick={onClose}>
      <div onClick={e=>e.stopPropagation()} style={{ background:"#fff", width:"100%", maxWidth:430, borderRadius:"24px 24px 0 0", padding:"20px 24px 36px", maxHeight:"90vh", overflowY:"auto" }}>
        <div style={{ width:40, height:4, background:"#E5E7EB", borderRadius:99, margin:"0 auto 18px" }} />
        <div style={{ fontSize:17, fontWeight:800, color:"#111", marginBottom:20 }}>{title}</div>
        {children}
      </div>
    </div>
  );
}
function Field({ label, value, onChange, type="text", placeholder }) {
  return (
    <div style={{ marginBottom:14 }}>
      <div style={{ fontSize:12, fontWeight:700, color:"#6B7280", marginBottom:6 }}>{label}</div>
      <input type={type} value={value??""} onChange={e=>onChange(e.target.value)} placeholder={placeholder}
        style={{ width:"100%", padding:"11px 14px", background:"#F9FAFB", border:"2px solid #F3F4F6", borderRadius:12, fontSize:14, fontFamily:"inherit", color:"#111", outline:"none", boxSizing:"border-box" }}
        onFocus={e=>e.target.style.borderColor="#FF4D4D"} onBlur={e=>e.target.style.borderColor="#F3F4F6"} />
    </div>
  );
}
function Toast({ msg, type }) {
  return (
    <div style={{ position:"fixed", top:20, left:"50%", transform:"translateX(-50%)", background:type==="error"?"#EF4444":"#111", color:"#fff", padding:"12px 20px", borderRadius:12, fontSize:14, fontWeight:700, zIndex:999, boxShadow:"0 4px 20px rgba(0,0,0,0.2)", animation:"fadeUp 0.2s ease", whiteSpace:"nowrap" }}>
      {msg}
    </div>
  );
}

// Screen header reusable
function ScreenHeader({ title, sub, onBack, rightEl }) {
  return (
    <div style={{ background:"#fff", padding:"14px 24px 18px", borderBottom:"1px solid #F3F4F6", position:"sticky", top:0, zIndex:100 }}>
      <div style={{ display:"flex", alignItems:"center", gap:12 }}>
        <div onClick={onBack} style={{ width:38,height:38,borderRadius:12,background:"#F9FAFB",border:"1.5px solid #F3F4F6",fontSize:18,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",color:"#111" }}>←</div>
        <div style={{ flex:1 }}>
          <div style={{ fontSize:17, fontWeight:800, color:"#111" }}>{title}</div>
          {sub && <div style={{ fontSize:12, color:"#9CA3AF", marginTop:1 }}>{sub}</div>}
        </div>
        {rightEl}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────
// CITY SELECTOR MODAL
// ─────────────────────────────────────────
const CITIES_SOON = [
  { name:"Ciudad de México", emoji:"🏙️" },
  { name:"Guadalajara",      emoji:"🌵" },
  { name:"Monterrey",        emoji:"⛰️" },
  { name:"Puebla",           emoji:"🏛️" },
  { name:"Querétaro",        emoji:"🏰" },
  { name:"León",             emoji:"🦁" },
];
function CityModal({ onSelect, onClose }) {
  return (
    <div style={{ position:"fixed",inset:0,background:"rgba(0,0,0,0.45)",zIndex:700,display:"flex",alignItems:"flex-end",justifyContent:"center" }} onClick={onClose}>
      <div onClick={e=>e.stopPropagation()} style={{ background:"#fff",width:"100%",maxWidth:430,borderRadius:"24px 24px 0 0",padding:"20px 24px 32px",maxHeight:"85vh",display:"flex",flexDirection:"column" }}>
        <div style={{ width:40,height:4,background:"#E5E7EB",borderRadius:99,margin:"0 auto 18px" }}/>
        <div style={{ fontSize:17,fontWeight:800,color:"#111",marginBottom:4 }}>📍 Selecciona tu ciudad</div>
        <div style={{ fontSize:13,color:"#6B7280",marginBottom:20 }}>Actualmente disponible en:</div>
        <div onClick={()=>{ onSelect({ name:"Aguascalientes", emoji:"🌶️" }); onClose(); }}
          style={{ display:"flex",alignItems:"center",gap:14,padding:"16px",borderRadius:16,background:"#FFF5F5",border:"2px solid #FF4D4D",cursor:"pointer",marginBottom:24 }}>
          <div style={{ width:46,height:46,borderRadius:14,background:"#FFE4E4",display:"flex",alignItems:"center",justifyContent:"center",fontSize:26,flexShrink:0 }}>🌶️</div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:16,fontWeight:800,color:"#111" }}>Aguascalientes</div>
            <div style={{ fontSize:12,color:"#FF4D4D",fontWeight:600,marginTop:2 }}>● Disponible ahora</div>
          </div>
          <div style={{ width:26,height:26,borderRadius:99,background:"#FF4D4D",display:"flex",alignItems:"center",justifyContent:"center" }}>
            <span style={{ color:"#fff",fontSize:14,fontWeight:800 }}>✓</span>
          </div>
        </div>
        <div style={{ display:"flex",alignItems:"center",gap:10,marginBottom:14 }}>
          <div style={{ flex:1,height:1,background:"#F3F4F6" }}/>
          <span style={{ fontSize:11,fontWeight:700,color:"#9CA3AF",whiteSpace:"nowrap",letterSpacing:0.5 }}>🚀 PRÓXIMAMENTE</span>
          <div style={{ flex:1,height:1,background:"#F3F4F6" }}/>
        </div>
        <div style={{ display:"flex",flexDirection:"column",gap:6,marginBottom:20 }}>
          {CITIES_SOON.map(c=>(
            <div key={c.name} style={{ display:"flex",alignItems:"center",gap:12,padding:"11px 14px",borderRadius:14,background:"#F9FAFB",opacity:0.5 }}>
              <span style={{ fontSize:20 }}>{c.emoji}</span>
              <span style={{ fontSize:14,fontWeight:500,color:"#6B7280" }}>{c.name}</span>
              <div style={{ marginLeft:"auto",background:"#F3F4F6",borderRadius:99,padding:"3px 10px",fontSize:11,fontWeight:600,color:"#9CA3AF" }}>Próximo</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────
// CART DRAWER
// ─────────────────────────────────────────
function CartDrawer({ cart, onClose, onCheckout, onUpdateCart }) {
  const total = cart.reduce((s,i)=>s+i.price*i.qty,0);
  const count = cart.reduce((s,i)=>s+i.qty,0);
  return (
    <div style={{ position:"fixed",inset:0,background:"rgba(0,0,0,0.45)",zIndex:700,display:"flex",alignItems:"flex-end",justifyContent:"center" }} onClick={onClose}>
      <div onClick={e=>e.stopPropagation()} style={{ background:"#fff",width:"100%",maxWidth:430,borderRadius:"24px 24px 0 0",padding:"20px 24px 0",maxHeight:"80vh",display:"flex",flexDirection:"column" }}>
        <div style={{ width:40,height:4,background:"#E5E7EB",borderRadius:99,margin:"0 auto 18px" }}/>
        <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18 }}>
          <div style={{ fontSize:17,fontWeight:800,color:"#111" }}>🛒 Mi carrito</div>
          <div style={{ background:"#F3F4F6",borderRadius:99,padding:"4px 12px",fontSize:13,fontWeight:700,color:"#6B7280" }}>{count} {count===1?"producto":"productos"}</div>
        </div>
        {cart.length===0?(
          <div style={{ textAlign:"center",padding:"40px 0 24px",color:"#9CA3AF" }}>
            <div style={{ fontSize:48,marginBottom:10 }}>🛒</div>
            <div style={{ fontSize:15,fontWeight:700,color:"#374151" }}>Tu carrito está vacío</div>
          </div>
        ):(
          <>
            <div style={{ overflowY:"auto",flex:1,display:"flex",flexDirection:"column",gap:2 }}>
              {cart.map(item=>(
                <div key={item.id} style={{ display:"flex",alignItems:"center",gap:12,padding:"12px 0",borderBottom:"1px solid #F9FAFB" }}>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:14,fontWeight:700,color:"#111" }}>{item.name}</div>
                    <div style={{ fontSize:14,fontWeight:800,color:"#111",marginTop:3 }}>${item.price*item.qty}</div>
                  </div>
                  <div style={{ display:"flex",alignItems:"center",gap:8 }}>
                    <button onClick={()=>onUpdateCart(item,-1)} style={{ width:28,height:28,borderRadius:99,border:"2px solid #E5E7EB",background:"#fff",fontSize:14,cursor:"pointer",fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",color:"#111" }}>−</button>
                    <span style={{ fontSize:14,fontWeight:800,color:"#111",minWidth:16,textAlign:"center" }}>{item.qty}</span>
                    <button onClick={()=>onUpdateCart(item,1)} style={{ width:28,height:28,borderRadius:99,border:"none",background:"#FF4D4D",fontSize:14,cursor:"pointer",fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",color:"#fff" }}>+</button>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ padding:"16px 0 32px" }}>
              <button onClick={()=>{ onClose(); onCheckout(); }}
                style={{ width:"100%",padding:"16px",background:"#FF4D4D",color:"#fff",border:"none",borderRadius:16,fontSize:15,fontWeight:700,cursor:"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",justifyContent:"space-between" }}>
                <span style={{ opacity:0 }}>-</span>
                <span>Ir a checkout</span>
                <span style={{ background:"rgba(255,255,255,0.2)",borderRadius:8,padding:"2px 10px",fontSize:14 }}>${total}</span>
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────
// HOME SCREEN
// ─────────────────────────────────────────
function HomeScreen({ restaurants, loading, onSelectRestaurant, globalCart, onUpdateGlobalCart, onCheckout }) {
  const [activeCat, setActiveCat] = useState(null);
  const [search, setSearch]       = useState("");
  const [liked, setLiked]         = useState({});
  const [showCity, setShowCity]   = useState(false);
  const [showCart, setShowCart]   = useState(false);
  const [city, setCity]           = useState({ name:"Aguascalientes", emoji:"🌶️" });
  const isNewUser = !localStorage.getItem("hasOrdered");
  const cartCount = globalCart.reduce((s,i)=>s+i.qty,0);

  const filtered = restaurants.filter(r => {
    const ms = !search || r.name?.toLowerCase().includes(search.toLowerCase()) || r.cuisine?.toLowerCase().includes(search.toLowerCase());
    const mc = !activeCat || r.cuisine?.toLowerCase().includes(FILTER_CATS.find(c=>c.id===activeCat)?.kw||"");
    return ms && mc;
  });

  return (
    <div style={{ paddingBottom:120, overflowX:"hidden" }}>
      {showCity && <CityModal onSelect={setCity} onClose={()=>setShowCity(false)}/>}
      {showCart && <CartDrawer cart={globalCart} onClose={()=>setShowCart(false)} onCheckout={onCheckout} onUpdateCart={onUpdateGlobalCart}/>}

      <div style={{ background:"#fff", padding:"14px 24px 20px" }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
          <div onClick={()=>setShowCity(true)} style={{ cursor:"pointer" }}>
            <div style={{ fontSize:11, color:"#FF4D4D", fontWeight:700, letterSpacing:0.5 }}>YUMMIGOAPP</div>
            <div style={{ display:"flex",alignItems:"center",gap:6, marginTop:2 }}>
              <span style={{ fontSize:16 }}>{city.emoji}</span>
              <span style={{ fontSize:15, fontWeight:700, color:"#111" }}>{city.name}</span>
              <span style={{ fontSize:13,color:"#111",marginTop:1 }}>▾</span>
            </div>
          </div>
          <div onClick={()=>setShowCart(true)} style={{ position:"relative", cursor:"pointer" }}>
            <div style={{ width:44, height:44, borderRadius:14, background:"#FF4D4D", display:"flex", alignItems:"center", justifyContent:"center", fontSize:20 }}>🛒</div>
            {cartCount>0&&(
              <div style={{ position:"absolute",top:-6,right:-6,background:"#111",color:"#fff",borderRadius:99,width:20,height:20,fontSize:11,fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",border:"2px solid #fff" }}>{cartCount}</div>
            )}
          </div>
        </div>
        <div style={{ marginTop:16, background:"#F9FAFB", border:"1.5px solid #F3F4F6", borderRadius:14, padding:"12px 16px", display:"flex", alignItems:"center", gap:10 }}>
          <span style={{ fontSize:18, opacity:0.35 }}>🔍</span>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Buscar restaurantes, platillos..."
            style={{ border:"none", background:"transparent", fontSize:15, color:"#111", outline:"none", flex:1, fontFamily:"inherit" }} />
          {search && <span onClick={()=>setSearch("")} style={{ cursor:"pointer", fontSize:16, opacity:0.4 }}>✕</span>}
        </div>
      </div>

      <div style={{ padding:"0 24px 20px" }}>
        <div style={{ background:"linear-gradient(120deg,#FF4D4D 60%,#FF6B6B)", borderRadius:20, padding:"20px 22px", display:"flex", justifyContent:"space-between", alignItems:"center", position:"relative", overflow:"hidden" }}>
          <div style={{ position:"absolute", right:-10, top:-20, fontSize:90, opacity:0.15, transform:"rotate(-15deg)" }}>🛵</div>
          <div>
            <div style={{ background:"rgba(255,255,255,0.25)", color:"#fff", fontSize:11, fontWeight:700, padding:"3px 10px", borderRadius:99, marginBottom:8, display:"inline-block" }}>OFERTA DEL DÍA</div>
            <div style={{ color:"#fff", fontSize:20, fontWeight:800, lineHeight:1.2 }}>Envío gratis<br/>en tu primer pedido</div>
            <div style={{ color:"rgba(255,255,255,0.75)", fontSize:13, marginTop:4 }}>Código: <b style={{ color:"#fff" }}>BIENVENIDO</b></div>
          </div>
          <button onClick={()=>{ if(restaurants.length>0) onSelectRestaurant(restaurants[0], isNewUser?"BIENVENIDO":null); }}
            style={{ background:"#fff", color:"#FF4D4D", border:"none", borderRadius:12, padding:"10px 16px", fontSize:13, fontWeight:800, cursor:"pointer", whiteSpace:"nowrap" }}>
            Pedir ya →
          </button>
        </div>
      </div>

      <div style={{ padding:"0 0 20px" }}>
        <div style={{ padding:"0 24px", display:"flex", justifyContent:"space-between", marginBottom:12 }}>
          <span style={{ fontSize:17, fontWeight:800, color:"#111" }}>Categorías</span>
          {activeCat && <span onClick={()=>setActiveCat(null)} style={{ fontSize:13, color:"#FF4D4D", fontWeight:600, cursor:"pointer" }}>Limpiar ✕</span>}
        </div>
        <div style={{ display:"flex", gap:10, overflowX:"auto", padding:"0 24px 4px", scrollbarWidth:"none" }}>
          {FILTER_CATS.map(cat => (
            <div key={cat.id} onClick={()=>setActiveCat(activeCat===cat.id?null:cat.id)} style={{ flexShrink:0, display:"flex", flexDirection:"column", alignItems:"center", gap:6, cursor:"pointer" }}>
              <div style={{ width:60, height:60, borderRadius:18, background:activeCat===cat.id?"#FF4D4D":"#F9FAFB", border:`1.5px solid ${activeCat===cat.id?"#FF4D4D":"#F3F4F6"}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:26, transition:"all 0.2s" }}>{cat.icon}</div>
              <span style={{ fontSize:12, fontWeight:600, color:activeCat===cat.id?"#FF4D4D":"#6B7280" }}>{cat.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding:"0 0 20px" }}>
        <div style={{ padding:"0 24px", display:"flex", justifyContent:"space-between", marginBottom:14 }}>
          <span style={{ fontSize:17, fontWeight:800, color:"#111" }}>🔥 Destacados</span>
          <span style={{ fontSize:13, color:"#9CA3AF" }}>{loading?"":filtered.length+" restaurantes"}</span>
        </div>
        <div style={{ display:"flex", gap:14, overflowX:"auto", padding:"0 24px 8px", scrollbarWidth:"none" }}>
          {loading ? [1,2,3].map(i=>(
            <div key={i} style={{ flexShrink:0, width:220, background:"#fff", borderRadius:20, overflow:"hidden", boxShadow:"0 2px 16px rgba(0,0,0,0.06)" }}>
              <div style={{ height:110, background:"#F3F4F6" }} />
              <div style={{ padding:"12px 14px 14px", display:"flex", flexDirection:"column", gap:8 }}>
                <Skeleton h={14} w="70%" /><Skeleton h={10} w="50%" />
              </div>
            </div>
          )) : filtered.slice(0,5).map((r,idx) => (
            <div key={r.id} onClick={()=>onSelectRestaurant(r)}
              style={{ flexShrink:0, width:220, background:"#fff", borderRadius:20, overflow:"hidden", boxShadow:"0 2px 16px rgba(0,0,0,0.06)", cursor:"pointer", transition:"transform 0.2s", animation:`fadeUp 0.3s ease ${idx*0.08}s both` }}
              onMouseEnter={e=>e.currentTarget.style.transform="translateY(-2px)"}
              onMouseLeave={e=>e.currentTarget.style.transform="translateY(0)"}>
              <div style={{ background:EMOJI_BG[r.emoji]||"#F9FAFB", height:110, display:"flex", alignItems:"center", justifyContent:"center", fontSize:54, position:"relative" }}>
                {r.emoji}
                <div style={{ position:"absolute", top:10, left:10, background:TAG_COLORS[idx%TAG_COLORS.length], color:"#fff", fontSize:10, fontWeight:700, padding:"3px 8px", borderRadius:99 }}>
                  {idx===0?"Más pedido":idx===1?"Nuevo":"Mejor valorado"}
                </div>
                <div onClick={e=>{e.stopPropagation();setLiked(p=>({...p,[r.id]:!p[r.id]}))}} style={{ position:"absolute", top:10, right:10, width:30, height:30, borderRadius:99, background:"#fff", display:"flex", alignItems:"center", justifyContent:"center", fontSize:16, cursor:"pointer" }}>
                  {liked[r.id]?"❤️":"🤍"}
                </div>
              </div>
              <div style={{ padding:"12px 14px 14px" }}>
                <div style={{ fontSize:15, fontWeight:800, color:"#111", marginBottom:2 }}>{r.name}</div>
                <div style={{ fontSize:12, color:"#6B7280", marginBottom:8 }}>{r.cuisine}</div>
                <div style={{ display:"flex", justifyContent:"space-between" }}>
                  <span style={{ fontSize:13, fontWeight:700 }}>⭐ {r.rating}</span>
                  <span style={{ fontSize:12, color:"#6B7280" }}>20–35 min</span>
                </div>
                <div style={{ marginTop:6, fontSize:12, fontWeight:600, color:"#FF4D4D" }}>Envío desde $25</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding:"0 24px" }}>
        <div style={{ fontSize:17, fontWeight:800, color:"#111", marginBottom:14 }}>📍 Todos los restaurantes</div>
        <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
          {loading ? [1,2,3].map(i=>(
            <div key={i} style={{ background:"#fff", borderRadius:18, padding:"14px 16px", display:"flex", alignItems:"center", gap:14, boxShadow:"0 2px 12px rgba(0,0,0,0.05)" }}>
              <div style={{ width:54, height:54, borderRadius:16, background:"#F3F4F6", flexShrink:0 }} />
              <div style={{ flex:1, display:"flex", flexDirection:"column", gap:8 }}><Skeleton h={14} w="60%"/><Skeleton h={10} w="40%"/></div>
            </div>
          )) : filtered.length===0 ? (
            <div style={{ textAlign:"center", padding:"40px 0", color:"#9CA3AF" }}>
              <div style={{ fontSize:40 }}>🔍</div>
              <div style={{ fontSize:14, fontWeight:600, color:"#374151", marginTop:8 }}>Sin resultados</div>
            </div>
          ) : filtered.map((r,idx) => (
            <div key={r.id} onClick={()=>onSelectRestaurant(r)}
              style={{ background:"#fff", borderRadius:18, padding:"14px 16px", display:"flex", alignItems:"center", gap:14, boxShadow:"0 2px 12px rgba(0,0,0,0.05)", cursor:"pointer", animation:`fadeUp 0.3s ease ${idx*0.05}s both` }}>
              <div style={{ width:54, height:54, borderRadius:16, background:EMOJI_BG[r.emoji]||"#F9FAFB", display:"flex", alignItems:"center", justifyContent:"center", fontSize:28, flexShrink:0 }}>{r.emoji}</div>
              <div style={{ flex:1 }}>
                <div style={{ display:"flex", justifyContent:"space-between" }}>
                  <span style={{ fontSize:15, fontWeight:700, color:"#111" }}>{r.name}</span>
                  <span style={{ fontSize:13, fontWeight:700 }}>⭐ {r.rating}</span>
                </div>
                <div style={{ display:"flex", justifyContent:"space-between", marginTop:4 }}>
                  <span style={{ fontSize:12, color:"#6B7280" }}>{r.cuisine}</span>
                  <span style={{ fontSize:12, color:"#6B7280" }}>🕐 {r.hours||"Ver horario"}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────
// ADDRESS MANAGER
// ─────────────────────────────────────────
function AddressManager({ onBack, onSelect, selectedId }) {
  const [addresses, setAddresses] = useState(loadAddresses);
  const [modal, setModal]         = useState(false);
  const [editing, setEditing]     = useState(null);
  const [form, setForm]           = useState({ label:"Casa", icon:"🏠", street:"", number:"", colonia:"", cp:"", refs:"" });
  const [errors, setErrors]       = useState({});
  const ICONS = [{ v:"🏠",l:"Casa" },{ v:"💼",l:"Trabajo" },{ v:"🏢",l:"Edificio" },{ v:"❤️",l:"Favorito" }];
  const set = k => v => setForm(f=>({...f,[k]:v}));

  const validate = () => {
    const e = {};
    if(!form.street.trim())  e.street  = "Requerido";
    if(!form.number.trim())  e.number  = "Requerido";
    if(!form.colonia.trim()) e.colonia = "Requerido";
    if(!form.cp.trim())      e.cp      = "Requerido";
    setErrors(e); return Object.keys(e).length === 0;
  };
  const saveAddr = () => {
    if(!validate()) return;
    const fullAddress = `${form.street} #${form.number}, ${form.colonia}, CP ${form.cp}${form.refs?` (${form.refs})`:""}`;
    let updated = editing
      ? addresses.map(a => a.id===editing.id ? {...form, id:editing.id, address:fullAddress} : a)
      : [...addresses, {...form, id:Date.now(), address:fullAddress}];
    saveAddresses(updated); setAddresses(updated); setModal(false); setEditing(null);
    setForm({ label:"Casa", icon:"🏠", street:"", number:"", colonia:"", cp:"", refs:"" }); setErrors({});
  };
  const deleteAddr = (id) => { const u = addresses.filter(a=>a.id!==id); saveAddresses(u); setAddresses(u); };
  const openEdit = (addr) => {
    setEditing(addr);
    setForm({ label:addr.label, icon:addr.icon, street:addr.street||"", number:addr.number||"", colonia:addr.colonia||"", cp:addr.cp||"", refs:addr.refs||"" });
    setModal(true);
  };

  return (
    <div style={{ background:"#F9FAFB", minHeight:"100vh" }}>
      <ScreenHeader title="Direcciones de entrega" sub={`${addresses.length} guardada${addresses.length!==1?"s":""}`} onBack={onBack}
        rightEl={<button onClick={()=>{ setEditing(null); setForm({label:"Casa",icon:"🏠",street:"",number:"",colonia:"",cp:"",refs:""}); setErrors({}); setModal(true); }} style={{ background:"#FF4D4D",color:"#fff",border:"none",borderRadius:12,padding:"9px 16px",fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>＋ Nueva</button>}/>

      <div style={{ padding:"16px 24px 100px", display:"flex", flexDirection:"column", gap:12 }}>
        {addresses.length===0 ? (
          <div style={{ textAlign:"center", padding:"60px 0" }}>
            <div style={{ fontSize:56, marginBottom:16 }}>📍</div>
            <div style={{ fontSize:16, fontWeight:800, color:"#111", marginBottom:6 }}>Sin direcciones guardadas</div>
            <div style={{ fontSize:13, color:"#9CA3AF", marginBottom:24 }}>Agrega tu primera dirección de entrega</div>
            <button onClick={()=>setModal(true)} style={{ background:"#FF4D4D",color:"#fff",border:"none",borderRadius:14,padding:"14px 28px",fontSize:14,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>＋ Agregar dirección</button>
          </div>
        ) : addresses.map(addr=>(
          <div key={addr.id} onClick={()=>onSelect&&onSelect(addr)}
            style={{ background:"#fff", borderRadius:20, padding:"16px 18px", boxShadow:"0 1px 8px rgba(0,0,0,0.06)", cursor:onSelect?"pointer":"default", border:`2px solid ${selectedId===addr.id?"#FF4D4D":"transparent"}` }}>
            <div style={{ display:"flex", alignItems:"flex-start", gap:12 }}>
              <div style={{ width:46,height:46,borderRadius:14,background:selectedId===addr.id?"#FF4D4D":"#FFF5F5",display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,flexShrink:0 }}>{addr.icon}</div>
              <div style={{ flex:1 }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
                  <span style={{ fontSize:14,fontWeight:800,color:"#111" }}>{addr.label}</span>
                  {selectedId===addr.id && <span style={{ background:"#FF4D4D",color:"#fff",fontSize:10,fontWeight:700,padding:"2px 8px",borderRadius:99 }}>Seleccionada</span>}
                </div>
                <div style={{ fontSize:13, color:"#374151", lineHeight:1.5 }}>
                  {addr.street} #{addr.number}<br/>{addr.colonia}, CP {addr.cp}
                  {addr.refs && <><br/><span style={{ color:"#9CA3AF" }}>📌 {addr.refs}</span></>}
                </div>
              </div>
            </div>
            <div style={{ display:"flex", gap:8, marginTop:12, paddingTop:12, borderTop:"1px solid #F9FAFB" }}>
              <button onClick={e=>{ e.stopPropagation(); openEdit(addr); }} style={{ flex:1,padding:"8px",background:"#F9FAFB",border:"1.5px solid #F3F4F6",borderRadius:10,fontSize:13,fontWeight:600,cursor:"pointer",color:"#374151",fontFamily:"inherit" }}>✏️ Editar</button>
              <button onClick={e=>{ e.stopPropagation(); deleteAddr(addr.id); }} style={{ flex:1,padding:"8px",background:"#FFF5F5",border:"1.5px solid #FFE4E4",borderRadius:10,fontSize:13,fontWeight:600,cursor:"pointer",color:"#FF4D4D",fontFamily:"inherit" }}>🗑️ Eliminar</button>
            </div>
          </div>
        ))}
      </div>

      {modal && (
        <div style={{ position:"fixed",inset:0,background:"rgba(0,0,0,0.45)",zIndex:500,display:"flex",alignItems:"flex-end",justifyContent:"center" }} onClick={()=>setModal(false)}>
          <div onClick={e=>e.stopPropagation()} style={{ background:"#fff",width:"100%",maxWidth:430,borderRadius:"24px 24px 0 0",padding:"20px 24px 36px",maxHeight:"92vh",overflowY:"auto" }}>
            <div style={{ width:40,height:4,background:"#E5E7EB",borderRadius:99,margin:"0 auto 18px" }}/>
            <div style={{ fontSize:17,fontWeight:800,color:"#111",marginBottom:20 }}>{editing?"✏️ Editar dirección":"➕ Nueva dirección"}</div>
            <div style={{ marginBottom:16 }}>
              <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:8 }}>TIPO</div>
              <div style={{ display:"flex", gap:10 }}>
                {ICONS.map(ic=>(
                  <div key={ic.v} onClick={()=>{ set("icon")(ic.v); set("label")(ic.l); }}
                    style={{ flex:1,padding:"10px 0",borderRadius:12,background:form.icon===ic.v?"#FF4D4D":"#F9FAFB",border:`1.5px solid ${form.icon===ic.v?"#FF4D4D":"#F3F4F6"}`,display:"flex",flexDirection:"column",alignItems:"center",gap:4,cursor:"pointer" }}>
                    <span style={{ fontSize:20 }}>{ic.v}</span>
                    <span style={{ fontSize:10,fontWeight:700,color:form.icon===ic.v?"#fff":"#6B7280" }}>{ic.l}</span>
                  </div>
                ))}
              </div>
            </div>
            <div style={{ display:"flex", gap:10 }}>
              <div style={{ flex:2 }}>
                <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>CALLE *</div>
                <input value={form.street} onChange={e=>set("street")(e.target.value)} placeholder="Av. Insurgentes"
                  style={{ width:"100%",padding:"11px 14px",background:"#F9FAFB",border:`2px solid ${errors.street?"#FF4D4D":"#F3F4F6"}`,borderRadius:12,fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}/>
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>NÚMERO *</div>
                <input value={form.number} onChange={e=>set("number")(e.target.value)} placeholder="1234"
                  style={{ width:"100%",padding:"11px 14px",background:"#F9FAFB",border:`2px solid ${errors.number?"#FF4D4D":"#F3F4F6"}`,borderRadius:12,fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}/>
              </div>
            </div>
            <div style={{ height:10 }}/>
            <div style={{ display:"flex", gap:10, marginBottom:12 }}>
              <div style={{ flex:2 }}>
                <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>COLONIA *</div>
                <input value={form.colonia} onChange={e=>set("colonia")(e.target.value)} placeholder="Roma Norte"
                  style={{ width:"100%",padding:"11px 14px",background:"#F9FAFB",border:`2px solid ${errors.colonia?"#FF4D4D":"#F3F4F6"}`,borderRadius:12,fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}/>
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>C.P. *</div>
                <input value={form.cp} onChange={e=>set("cp")(e.target.value.replace(/\D/g,"").slice(0,5))} placeholder="20000" maxLength={5}
                  style={{ width:"100%",padding:"11px 14px",background:"#F9FAFB",border:`2px solid ${errors.cp?"#FF4D4D":"#F3F4F6"}`,borderRadius:12,fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}/>
              </div>
            </div>
            <div style={{ marginBottom:20 }}>
              <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>REFERENCIAS (opcional)</div>
              <input value={form.refs} onChange={e=>set("refs")(e.target.value)} placeholder="Entre calles..."
                style={{ width:"100%",padding:"11px 14px",background:"#F9FAFB",border:"2px solid #F3F4F6",borderRadius:12,fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}/>
            </div>
            <button onClick={saveAddr} style={{ width:"100%",padding:"15px",background:"#FF4D4D",color:"#fff",border:"none",borderRadius:14,fontSize:15,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>
              {editing ? "Guardar cambios ✓" : "Agregar dirección ✓"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────
// PAYMENT MANAGER
// ─────────────────────────────────────────
function PaymentManager({ onBack, onSelect, selectedId }) {
  const [cards, setCards]   = useState(loadPayments);
  const [modal, setModal]   = useState(false);
  const [form, setForm]     = useState({ number:"", name:"", expiry:"", cvv:"" });
  const [errors, setErrors] = useState({});
  const set = k => v => setForm(f=>({...f,[k]:v}));
  const formatCard = v => v.replace(/\D/g,"").slice(0,16).replace(/(.{4})/g,"$1 ").trim();
  const formatExp  = v => { const d=v.replace(/\D/g,"").slice(0,4); return d.length>2?d.slice(0,2)+"/"+d.slice(2):d; };
  const cardBrand = num => {
    const n=num.replace(/\s/g,"");
    if(/^4/.test(n)) return { name:"Visa", color:"#1A1F71" };
    if(/^5[1-5]/.test(n)) return { name:"Mastercard", color:"#EB001B" };
    if(/^3[47]/.test(n)) return { name:"Amex", color:"#007BC1" };
    return { name:"Tarjeta", color:"#374151" };
  };
  const validate = () => {
    const e={};
    if(form.number.replace(/\s/g,"").length<16) e.number="Inválido";
    if(!form.name.trim()) e.name="Requerido";
    if(form.expiry.length<5) e.expiry="Inválida";
    if(form.cvv.length<3) e.cvv="Inválido";
    setErrors(e); return Object.keys(e).length===0;
  };
  const saveCard = () => {
    if(!validate()) return;
    const brand=cardBrand(form.number); const last4=form.number.replace(/\s/g,"").slice(-4);
    const newCard={ id:Date.now(), type:"card", label:`•••• ${last4}`, sub:`${brand.name} · Vence ${form.expiry}`, icon:"💳", brand:brand.color, last4, name:form.name, expiry:form.expiry };
    const updated=[...cards,newCard]; savePayments(updated); setCards(updated); setModal(false);
    setForm({number:"",name:"",expiry:"",cvv:""}); setErrors({});
  };
  const deleteCard = id => { const u=cards.filter(c=>c.id!==id); savePayments(u); setCards(u); };
  const allMethods=[...PAYMENT_STATIC,...cards];

  return (
    <div style={{ background:"#F9FAFB", minHeight:"100vh" }}>
      <ScreenHeader title="Métodos de pago" sub={`${allMethods.length} disponible${allMethods.length!==1?"s":""}`} onBack={onBack}
        rightEl={<button onClick={()=>{ setForm({number:"",name:"",expiry:"",cvv:""}); setErrors({}); setModal(true); }} style={{ background:"#FF4D4D",color:"#fff",border:"none",borderRadius:12,padding:"9px 16px",fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>＋ Tarjeta</button>}/>
      <div style={{ padding:"16px 24px 100px", display:"flex", flexDirection:"column", gap:12 }}>
        <div style={{ fontSize:12,fontWeight:700,color:"#9CA3AF",marginBottom:4,letterSpacing:0.5 }}>PAGO EN EFECTIVO</div>
        <div onClick={()=>onSelect&&onSelect(PAYMENT_STATIC[0])}
          style={{ background:"#fff",borderRadius:20,padding:"18px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)",cursor:"pointer",border:`2px solid ${selectedId==="cash"?"#FF4D4D":"transparent"}` }}>
          <div style={{ display:"flex",alignItems:"center",gap:14 }}>
            <div style={{ width:50,height:50,borderRadius:16,background:selectedId==="cash"?"#FF4D4D":"#FFF5F5",display:"flex",alignItems:"center",justifyContent:"center",fontSize:24 }}>💵</div>
            <div style={{ flex:1 }}><div style={{ fontSize:15,fontWeight:800,color:"#111" }}>Efectivo</div><div style={{ fontSize:12,color:"#9CA3AF",marginTop:2 }}>Paga al repartidor al recibir</div></div>
            <div style={{ width:24,height:24,borderRadius:99,border:`2px solid ${selectedId==="cash"?"#FF4D4D":"#D1D5DB"}`,display:"flex",alignItems:"center",justifyContent:"center" }}>
              {selectedId==="cash"&&<div style={{ width:14,height:14,borderRadius:99,background:"#FF4D4D" }}/>}
            </div>
          </div>
        </div>
        {cards.length>0&&<>
          <div style={{ fontSize:12,fontWeight:700,color:"#9CA3AF",marginTop:8,marginBottom:4,letterSpacing:0.5 }}>TARJETAS GUARDADAS</div>
          {cards.map(card=>(
            <div key={card.id} onClick={()=>onSelect&&onSelect(card)}
              style={{ borderRadius:20,overflow:"hidden",boxShadow:"0 1px 8px rgba(0,0,0,0.06)",cursor:"pointer",border:`2px solid ${selectedId===card.id?"#FF4D4D":"transparent"}` }}>
              <div style={{ background:`linear-gradient(135deg,${card.brand||"#374151"},#111)`,padding:"18px 20px",position:"relative",overflow:"hidden" }}>
                <div style={{ fontSize:16,fontWeight:700,color:"#fff",letterSpacing:2,marginBottom:8 }}>•••• •••• •••• {card.last4}</div>
                <div style={{ display:"flex",justifyContent:"space-between" }}>
                  <div style={{ fontSize:13,fontWeight:600,color:"#fff" }}>{card.name}</div>
                  <div style={{ fontSize:13,fontWeight:600,color:"rgba(255,255,255,0.7)" }}>Vence {card.expiry}</div>
                </div>
              </div>
              <div style={{ background:"#fff",padding:"12px 18px",display:"flex",justifyContent:"space-between",alignItems:"center" }}>
                <span style={{ fontSize:13,color:"#6B7280" }}>{card.sub}</span>
                <button onClick={e=>{e.stopPropagation();deleteCard(card.id);}} style={{ background:"#FFF5F5",border:"none",borderRadius:8,padding:"6px 12px",fontSize:12,fontWeight:600,color:"#FF4D4D",cursor:"pointer",fontFamily:"inherit" }}>Eliminar</button>
              </div>
            </div>
          ))}
        </>}
        <div style={{ fontSize:12,fontWeight:700,color:"#9CA3AF",marginTop:8,marginBottom:4,letterSpacing:0.5 }}>PRÓXIMAMENTE</div>
        {[{icon:"🍎",label:"Apple Pay",sub:"Touch ID / Face ID"},{icon:"🔵",label:"Mercado Pago",sub:"Wallet digital"},{icon:"🏦",label:"SPEI",sub:"Transferencia bancaria"}].map((m,i)=>(
          <div key={i} style={{ background:"#fff",borderRadius:18,padding:"14px 18px",boxShadow:"0 1px 8px rgba(0,0,0,0.04)",opacity:0.5,display:"flex",alignItems:"center",gap:14 }}>
            <div style={{ width:44,height:44,borderRadius:14,background:"#F9FAFB",display:"flex",alignItems:"center",justifyContent:"center",fontSize:22 }}>{m.icon}</div>
            <div style={{ flex:1 }}><div style={{ fontSize:14,fontWeight:700,color:"#111" }}>{m.label}</div><div style={{ fontSize:12,color:"#9CA3AF",marginTop:1 }}>{m.sub}</div></div>
            <div style={{ background:"#F3F4F6",borderRadius:99,padding:"3px 10px",fontSize:11,fontWeight:600,color:"#9CA3AF" }}>Próximo</div>
          </div>
        ))}
      </div>
      {modal && (
        <div style={{ position:"fixed",inset:0,background:"rgba(0,0,0,0.5)",zIndex:500,display:"flex",alignItems:"flex-end",justifyContent:"center" }} onClick={()=>setModal(false)}>
          <div onClick={e=>e.stopPropagation()} style={{ background:"#fff",width:"100%",maxWidth:430,borderRadius:"24px 24px 0 0",padding:"20px 24px 36px",maxHeight:"92vh",overflowY:"auto" }}>
            <div style={{ width:40,height:4,background:"#E5E7EB",borderRadius:99,margin:"0 auto 18px" }}/>
            <div style={{ fontSize:17,fontWeight:800,color:"#111",marginBottom:20 }}>💳 Agregar tarjeta</div>
            <div style={{ background:`linear-gradient(135deg,${cardBrand(form.number).color},#111)`,borderRadius:18,padding:"20px 22px",marginBottom:20,minHeight:120 }}>
              <div style={{ fontSize:24,marginBottom:12 }}>💳</div>
              <div style={{ fontSize:17,fontWeight:700,color:"#fff",letterSpacing:2,marginBottom:10 }}>{form.number||"•••• •••• •••• ••••"}</div>
              <div style={{ display:"flex",justifyContent:"space-between" }}>
                <div style={{ fontSize:13,color:"#fff",fontWeight:600 }}>{form.name||"NOMBRE"}</div>
                <div style={{ fontSize:13,color:"#fff",fontWeight:600 }}>{form.expiry||"MM/AA"}</div>
              </div>
            </div>
            <div style={{ marginBottom:14 }}>
              <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>NÚMERO *</div>
              <input value={form.number} onChange={e=>set("number")(formatCard(e.target.value))} placeholder="0000 0000 0000 0000" maxLength={19}
                style={{ width:"100%",padding:"13px 14px",background:"#F9FAFB",border:`2px solid ${errors.number?"#FF4D4D":"#F3F4F6"}`,borderRadius:12,fontSize:16,fontFamily:"monospace",color:"#111",outline:"none",boxSizing:"border-box",letterSpacing:2 }}/>
            </div>
            <div style={{ marginBottom:14 }}>
              <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>TITULAR *</div>
              <input value={form.name} onChange={e=>set("name")(e.target.value.toUpperCase())} placeholder="NOMBRE APELLIDO"
                style={{ width:"100%",padding:"11px 14px",background:"#F9FAFB",border:`2px solid ${errors.name?"#FF4D4D":"#F3F4F6"}`,borderRadius:12,fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}/>
            </div>
            <div style={{ display:"flex",gap:12,marginBottom:20 }}>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>VENCIMIENTO *</div>
                <input value={form.expiry} onChange={e=>set("expiry")(formatExp(e.target.value))} placeholder="MM/AA" maxLength={5}
                  style={{ width:"100%",padding:"11px 14px",background:"#F9FAFB",border:`2px solid ${errors.expiry?"#FF4D4D":"#F3F4F6"}`,borderRadius:12,fontSize:14,fontFamily:"monospace",color:"#111",outline:"none",boxSizing:"border-box" }}/>
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>CVV *</div>
                <input value={form.cvv} onChange={e=>set("cvv")(e.target.value.replace(/\D/g,"").slice(0,4))} placeholder="•••" maxLength={4} type="password"
                  style={{ width:"100%",padding:"11px 14px",background:"#F9FAFB",border:`2px solid ${errors.cvv?"#FF4D4D":"#F3F4F6"}`,borderRadius:12,fontSize:14,fontFamily:"monospace",color:"#111",outline:"none",boxSizing:"border-box" }}/>
              </div>
            </div>
            <button onClick={saveCard} style={{ width:"100%",padding:"15px",background:"#FF4D4D",color:"#fff",border:"none",borderRadius:14,fontSize:15,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>Agregar tarjeta ✓</button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────
// DISCOUNT CODES SCREEN  ★ NEW
// ─────────────────────────────────────────
const TODAY = new Date();
const fmtDate = (d) => d.toLocaleDateString("es-MX", { day:"numeric", month:"short" });
const PROMOS_DATA = [
  { id:"BIENVENIDO", code:"BIENVENIDO", title:"Bienvenida", desc:"Envío gratis en tu primer pedido", detail:"Solo para usuarios nuevos. Sin monto mínimo. Aplica una vez.", icon:"🎉", color:"#16A34A", bg:"#F0FDF4", badge:"Envío gratis", badgeBg:"#DCFCE7", badgeColor:"#16A34A", permanent:true, newUserOnly:true },
  { id:"PIZZA10",    code:"PIZZA10",    title:"Pizza Fest",   desc:"15% de descuento en tu orden",   detail:"Aplica en cualquier restaurante. Descuento sobre el subtotal.", icon:"🍕", color:"#FF4D4D", bg:"#FFF5F5", badge:"15% OFF", badgeBg:"#FEE2E2", badgeColor:"#FF4D4D", permanent:false, newUserOnly:false, validFrom:new Date(TODAY.getFullYear(),TODAY.getMonth(),1), validTo:new Date(TODAY.getFullYear(),TODAY.getMonth()+1,0) },
  { id:"VERANO25",   code:"VERANO25",   title:"Promo Verano", desc:"15% de descuento toda la temporada", detail:"Descuento especial de verano durante el período de vigencia.", icon:"☀️", color:"#F59E0B", bg:"#FFFBEB", badge:"15% OFF", badgeBg:"#FEF3C7", badgeColor:"#D97706", permanent:false, newUserOnly:false, validFrom:new Date(2025,5,1), validTo:new Date(2025,7,31) },
];

function DiscountCodesScreen({ onBack }) {
  const isNewUser = !localStorage.getItem("hasOrdered");
  const [copied, setCopied]   = useState(null);
  const [expanded, setExpanded] = useState(null);
  const [manualCode, setManualCode] = useState("");
  const [manualMsg, setManualMsg]   = useState(null);

  const isValid = (p) => {
    if(p.newUserOnly && !isNewUser) return false;
    if(p.permanent) return true;
    const now=new Date(); return now>=p.validFrom && now<=p.validTo;
  };
  const isExpired = (p) => !p.permanent && new Date()>p.validTo;

  const copyCode = (code) => {
    navigator.clipboard?.writeText(code).catch(()=>{});
    setCopied(code); setTimeout(()=>setCopied(null),2000);
  };

  const checkManual = () => {
    const c = manualCode.trim().toUpperCase();
    const found = PROMOS_DATA.find(p=>p.code===c);
    if(!found) { setManualMsg({ ok:false, text:"Código no encontrado ✗" }); return; }
    if(!isValid(found)) { setManualMsg({ ok:false, text: found.newUserOnly?"Solo para nuevos usuarios ✗":"Código expirado ✗" }); return; }
    setManualMsg({ ok:true, text:`✓ ${found.badge} — ${found.desc}` });
  };

  const valid   = PROMOS_DATA.filter(p=>isValid(p));
  const invalid = PROMOS_DATA.filter(p=>!isValid(p));

  const Card = ({ promo, locked }) => (
    <div style={{ background:locked?"#F9FAFB":"#fff", borderRadius:20, overflow:"hidden", boxShadow:"0 1px 8px rgba(0,0,0,0.06)", opacity:locked?0.55:1, marginBottom:12, border:`1.5px solid ${locked?"#F3F4F6":"#F0F0F0"}` }}
      onClick={()=>setExpanded(expanded===promo.id?null:promo.id)}>
      <div style={{ padding:"16px 18px" }}>
        <div style={{ display:"flex", alignItems:"flex-start", gap:14 }}>
          <div style={{ width:52,height:52,borderRadius:16,background:locked?"#F3F4F6":promo.bg,display:"flex",alignItems:"center",justifyContent:"center",fontSize:26,flexShrink:0 }}>{promo.icon}</div>
          <div style={{ flex:1 }}>
            <div style={{ display:"flex",alignItems:"center",gap:8,flexWrap:"wrap",marginBottom:4 }}>
              <span style={{ fontSize:15,fontWeight:800,color:locked?"#9CA3AF":"#111" }}>{promo.title}</span>
              <span style={{ background:locked?"#F3F4F6":promo.badgeBg,color:locked?"#9CA3AF":promo.badgeColor,fontSize:10,fontWeight:700,padding:"2px 8px",borderRadius:99 }}>
                {locked&&isExpired(promo)?"Vencida":locked?"No disponible":promo.badge}
              </span>
            </div>
            <div style={{ fontSize:13,color:locked?"#9CA3AF":"#374151",marginBottom:4 }}>{promo.desc}</div>
            {!promo.permanent&&<div style={{ fontSize:11,color:"#9CA3AF" }}>{isExpired(promo)?`Venció ${fmtDate(promo.validTo)}`:`Válido hasta ${fmtDate(promo.validTo)}`}</div>}
            {promo.permanent&&promo.newUserOnly&&<div style={{ fontSize:11,color:isNewUser?"#16A34A":"#FF4D4D",fontWeight:600 }}>{isNewUser?"✓ Disponible para ti":"✗ Solo nuevos usuarios"}</div>}
          </div>
          <span style={{ fontSize:14,color:"#D1D5DB",marginTop:4 }}>{expanded===promo.id?"∧":"∨"}</span>
        </div>
      </div>
      {expanded===promo.id&&(
        <div style={{ padding:"0 18px 18px",borderTop:"1px solid #F3F4F6" }}>
          <div style={{ fontSize:13,color:"#6B7280",lineHeight:1.7,marginBottom:14,paddingTop:14 }}>{promo.detail}</div>
          {!locked?(
            <div style={{ background:promo.bg,borderRadius:12,padding:"12px 16px",display:"flex",alignItems:"center",justifyContent:"space-between" }}>
              <span style={{ fontSize:17,fontWeight:900,color:"#111",letterSpacing:1.5 }}>{promo.code}</span>
              <button onClick={e=>{e.stopPropagation();copyCode(promo.code);}}
                style={{ background:copied===promo.code?"#16A34A":"#FF4D4D",color:"#fff",border:"none",borderRadius:8,padding:"8px 16px",fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit",transition:"background 0.2s" }}>
                {copied===promo.code?"✓ Copiado":"Copiar"}
              </button>
            </div>
          ):(
            <div style={{ background:"#FFF5F5",borderRadius:12,padding:"10px 14px",fontSize:12,color:"#FF4D4D",fontWeight:600 }}>
              {promo.newUserOnly&&!isNewUser?"Este código es exclusivo para nuevos usuarios.":"Este código ya no está disponible."}
            </div>
          )}
        </div>
      )}
    </div>
  );

  return (
    <div style={{ background:"#F9FAFB", minHeight:"100vh", paddingBottom:100 }}>
      <ScreenHeader title="Códigos de descuento" sub={`${valid.length} disponible${valid.length!==1?"s":""}`} onBack={onBack}/>
      <div style={{ padding:"20px 24px" }}>
        {/* Verificador manual */}
        <div style={{ background:"#fff",borderRadius:20,padding:"18px 20px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)",marginBottom:24 }}>
          <div style={{ fontSize:14,fontWeight:800,color:"#111",marginBottom:12 }}>🔍 Verificar código</div>
          <div style={{ display:"flex",gap:10,marginBottom:manualMsg?10:0 }}>
            <input value={manualCode} onChange={e=>{setManualCode(e.target.value);setManualMsg(null);}} placeholder="Ej: PIZZA10"
              style={{ flex:1,border:"2px solid #F3F4F6",borderRadius:12,padding:"11px 14px",fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",background:"#F9FAFB",textTransform:"uppercase" }}
              onFocus={e=>e.target.style.borderColor="#FF4D4D"} onBlur={e=>e.target.style.borderColor="#F3F4F6"}/>
            <button onClick={checkManual} style={{ padding:"11px 20px",background:"#FF4D4D",color:"#fff",border:"none",borderRadius:12,fontSize:14,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>Verificar</button>
          </div>
          {manualMsg&&<div style={{ fontSize:13,fontWeight:700,color:manualMsg.ok?"#16A34A":"#FF4D4D",marginTop:8,padding:"8px 12px",background:manualMsg.ok?"#F0FDF4":"#FFF5F5",borderRadius:10 }}>{manualMsg.text}</div>}
        </div>

        {valid.length>0&&<>
          <div style={{ fontSize:12,fontWeight:700,color:"#9CA3AF",letterSpacing:0.5,marginBottom:12 }}>✅ DISPONIBLES PARA TI</div>
          {valid.map(p=><Card key={p.id} promo={p} locked={false}/>)}
        </>}
        {invalid.length>0&&<>
          <div style={{ fontSize:12,fontWeight:700,color:"#9CA3AF",letterSpacing:0.5,marginBottom:12,marginTop:8 }}>🔒 NO DISPONIBLES</div>
          {invalid.map(p=><Card key={p.id} promo={p} locked={true}/>)}
        </>}

        <div style={{ background:"#fff",borderRadius:18,padding:"16px 18px",boxShadow:"0 1px 8px rgba(0,0,0,0.05)",marginTop:8 }}>
          <div style={{ fontSize:13,fontWeight:800,color:"#111",marginBottom:12 }}>💡 ¿Cómo usar un código?</div>
          {["Elige tu restaurante y agrega platillos al carrito","En el carrito, ingresa o pega el código de descuento","El descuento se aplica automáticamente al total"].map((s,i)=>(
            <div key={i} style={{ display:"flex",gap:12,alignItems:"flex-start",marginBottom:i<2?10:0 }}>
              <div style={{ width:24,height:24,borderRadius:99,background:"#FF4D4D",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800,color:"#fff",flexShrink:0 }}>{i+1}</div>
              <div style={{ fontSize:13,color:"#374151",paddingTop:4,lineHeight:1.5 }}>{s}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────
// SHIPPING CALCULATOR SCREEN  ★ NEW
// ─────────────────────────────────────────
// ─────────────────────────────────────────
// TARIFA DE ENVÍO POR KM
// ─────────────────────────────────────────
const SHIPPING_RATES = [
  { label:"0 – 1.5 km",  min:0,   max:1.5,  price:35, emoji:"🟢", time:"10–20 min" },
  { label:"1.6 – 3 km",  min:1.6, max:3,    price:40, emoji:"🟡", time:"15–25 min" },
  { label:"3.1 – 5.5 km",min:3.1, max:5.5,  price:50, emoji:"🟠", time:"20–35 min" },
  { label:"5.6 – 8 km",  min:5.6, max:8,    price:60, emoji:"🔴", time:"30–45 min" },
  { label:"8.1 – 10 km", min:8.1, max:10,   price:70, emoji:"🔴", time:"40–55 min" },
];
const EXTRA_KM_COST    = 5;   // por km adicional fuera de rango
const COVERAGE_COST    = 10;  // por km fuera de cobertura (>10km)
const RAIN_SURCHARGE   = 20;  // tarifa lluvia
const HOLIDAY_SURCHARGE= 20;  // día festivo

function getShippingRate(km) {
  const rate = SHIPPING_RATES.find(r => km >= r.min && km <= r.max);
  if(rate) return { price: rate.price, time: rate.time, label: rate.label, outOfCoverage: false };
  if(km > 10) {
    const extra = Math.ceil(km - 10);
    return { price: 70 + (extra * COVERAGE_COST), time:"55+ min", label:`${km} km (fuera de cobertura)`, outOfCoverage: true };
  }
  return { price: 35, time:"10–20 min", label:"< 1 km", outOfCoverage: false };
}

function ShippingCalculatorScreen({ onBack }) {
  const [km, setKm]               = useState("");
  const [subtotal, setSubtotal]   = useState("");
  const [promo, setPromo]         = useState("");
  const [rain, setRain]           = useState(false);
  const [holiday, setHoliday]     = useState(false);
  const [result, setResult]       = useState(null);
  const [showRates, setShowRates] = useState(false);

  const calculate = () => {
    const d = parseFloat(km);
    if(!d || d <= 0) return;
    const sub      = parseFloat(subtotal) || 0;
    const code     = promo.trim().toUpperCase();
    const freeShip = PROMOS_FREE_SHIPPING.includes(code) && !localStorage.getItem("hasOrdered");
    const pct15    = PROMOS_DISCOUNT.includes(code);
    const discount = pct15 ? Math.round(sub * 0.15) : 0;
    const rateInfo = getShippingRate(d);
    const rainAmt  = rain    ? RAIN_SURCHARGE    : 0;
    const holAmt   = holiday ? HOLIDAY_SURCHARGE : 0;
    const baseShip = freeShip ? 0 : rateInfo.price;
    const surcharge= freeShip ? 0 : rainAmt + holAmt;
    const delivery = baseShip + surcharge;
    setResult({ sub, discount, delivery, baseShip, rainAmt, holAmt, surcharge, total: sub - discount + delivery, freeShip, pct15, rateInfo, km: d });
  };

  const kmVal = parseFloat(km);
  const currentRate = km && kmVal > 0 ? getShippingRate(kmVal) : null;

  return (
    <div style={{ background:"#F9FAFB", minHeight:"100vh", paddingBottom:100 }}>
      <ScreenHeader title="Calculadora de Envío" sub="Tarifa real por kilómetro recorrido" onBack={onBack}/>
      <div style={{ padding:"20px 24px", display:"flex", flexDirection:"column", gap:14 }}>

        {/* Tabla de tarifas */}
        <div style={{ background:"#fff",borderRadius:20,padding:"18px 20px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
          <div onClick={()=>setShowRates(r=>!r)} style={{ display:"flex",justifyContent:"space-between",alignItems:"center",cursor:"pointer" }}>
            <div style={{ fontSize:14,fontWeight:800,color:"#111" }}>🚚 Tarifas por distancia</div>
            <span style={{ fontSize:13,color:"#FF4D4D",fontWeight:700 }}>{showRates?"Ocultar ▲":"Ver tarifas ▼"}</span>
          </div>
          {showRates&&(
            <div style={{ marginTop:14 }}>
              <div style={{ display:"grid",gridTemplateColumns:"1fr auto",gap:0 }}>
                {/* Header */}
                <div style={{ fontSize:11,fontWeight:700,color:"#9CA3AF",padding:"5px 0",borderBottom:"2px solid #F3F4F6" }}>DISTANCIA</div>
                <div style={{ fontSize:11,fontWeight:700,color:"#9CA3AF",padding:"5px 0",borderBottom:"2px solid #F3F4F6",textAlign:"right" }}>TARIFA</div>
                {SHIPPING_RATES.map((r,i)=>(
                  <>
                    <div key={`l${i}`} style={{ fontSize:13,color:"#374151",padding:"9px 0",borderBottom:"1px solid #F9FAFB",display:"flex",alignItems:"center",gap:6 }}>
                      <span style={{ fontSize:10 }}>{r.emoji}</span>{r.label}
                    </div>
                    <div key={`p${i}`} style={{ fontSize:14,fontWeight:800,color:"#FF4D4D",padding:"9px 0",borderBottom:"1px solid #F9FAFB",textAlign:"right" }}>${r.price}</div>
                  </>
                ))}
              </div>
              <div style={{ marginTop:12,background:"#FFF5F5",borderRadius:12,padding:"12px 14px" }}>
                <div style={{ fontSize:12,fontWeight:700,color:"#FF4D4D",marginBottom:8 }}>⚡ CARGOS ADICIONALES</div>
                {[
                  { label:"Km extra (dentro del rango)", value:`+$${EXTRA_KM_COST}/km` },
                  { label:"Km fuera de cobertura (>10 km)", value:`+$${COVERAGE_COST}/km` },
                  { label:"Tarifa en lluvia", value:`+$${RAIN_SURCHARGE}` },
                  { label:"Día festivo", value:`+$${HOLIDAY_SURCHARGE}` },
                ].map((item,i)=>(
                  <div key={i} style={{ display:"flex",justifyContent:"space-between",padding:"5px 0",borderBottom:i<3?"1px solid #FFE4E4":"none" }}>
                    <span style={{ fontSize:12,color:"#374151" }}>{item.label}</span>
                    <span style={{ fontSize:12,fontWeight:700,color:"#FF4D4D" }}>{item.value}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Distancia */}
        <div style={{ background:"#fff",borderRadius:20,padding:"18px 20px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
          <div style={{ fontSize:14,fontWeight:800,color:"#111",marginBottom:12 }}>📏 Distancia del restaurante al domicilio</div>
          <div style={{ position:"relative" }}>
            <input type="number" value={km} onChange={e=>{ setKm(e.target.value); setResult(null); }} placeholder="0.0" min="0" step="0.1"
              style={{ width:"100%",padding:"13px 50px 13px 14px",background:"#F9FAFB",border:"2px solid #F3F4F6",borderRadius:12,fontSize:20,fontWeight:700,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}
              onFocus={e=>e.target.style.borderColor="#FF4D4D"} onBlur={e=>e.target.style.borderColor="#F3F4F6"}/>
            <span style={{ position:"absolute",right:14,top:"50%",transform:"translateY(-50%)",fontSize:14,fontWeight:700,color:"#9CA3AF" }}>km</span>
          </div>
          {/* Live rate preview */}
          {currentRate&&(
            <div style={{ marginTop:10,padding:"10px 14px",background:currentRate.outOfCoverage?"#FFF5F5":"#F0FDF4",borderRadius:10,display:"flex",justifyContent:"space-between",alignItems:"center",animation:"fadeUp 0.2s ease" }}>
              <div>
                <div style={{ fontSize:11,fontWeight:700,color:currentRate.outOfCoverage?"#FF4D4D":"#16A34A" }}>{currentRate.outOfCoverage?"⚠️ Fuera de cobertura":"✓ Tarifa aplicable"}</div>
                <div style={{ fontSize:12,color:"#374151",marginTop:2 }}>{currentRate.label} · 🕐 {currentRate.time}</div>
              </div>
              <div style={{ fontSize:20,fontWeight:900,color:currentRate.outOfCoverage?"#FF4D4D":"#16A34A" }}>${currentRate.price}</div>
            </div>
          )}
        </div>

        {/* Condiciones especiales */}
        <div style={{ background:"#fff",borderRadius:20,padding:"18px 20px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
          <div style={{ fontSize:14,fontWeight:800,color:"#111",marginBottom:14 }}>⚡ Condiciones especiales</div>
          <div style={{ display:"flex",flexDirection:"column",gap:0 }}>
            {[
              { icon:"🌧️", label:"Tarifa en lluvia", sub:`+$${RAIN_SURCHARGE} al costo de envío`, key:"rain", val:rain, set:setRain },
              { icon:"🎉", label:"Día festivo",      sub:`+$${HOLIDAY_SURCHARGE} al costo de envío`, key:"hol",  val:holiday, set:setHoliday },
            ].map((item,i)=>(
              <div key={item.key} style={{ display:"flex",alignItems:"center",gap:14,padding:"12px 0",borderBottom:i<1?"1px solid #F9FAFB":"none" }}>
                <div style={{ width:40,height:40,borderRadius:12,background:item.val?"#FFF5F5":"#F9FAFB",display:"flex",alignItems:"center",justifyContent:"center",fontSize:20 }}>{item.icon}</div>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:14,fontWeight:600,color:"#111" }}>{item.label}</div>
                  <div style={{ fontSize:12,color:"#9CA3AF",marginTop:1 }}>{item.sub}</div>
                </div>
                <Toggle value={item.val} onChange={()=>{ item.set(v=>!v); setResult(null); }}/>
              </div>
            ))}
          </div>
        </div>

        {/* Monto del pedido */}
        <div style={{ background:"#fff",borderRadius:20,padding:"18px 20px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
          <div style={{ fontSize:14,fontWeight:800,color:"#111",marginBottom:12 }}>🛒 Monto del pedido (opcional)</div>
          <div style={{ position:"relative" }}>
            <span style={{ position:"absolute",left:14,top:"50%",transform:"translateY(-50%)",fontSize:16,fontWeight:700,color:"#374151" }}>$</span>
            <input type="number" value={subtotal} onChange={e=>{ setSubtotal(e.target.value); setResult(null); }} placeholder="0.00"
              style={{ width:"100%",padding:"13px 14px 13px 28px",background:"#F9FAFB",border:"2px solid #F3F4F6",borderRadius:12,fontSize:18,fontWeight:700,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}
              onFocus={e=>e.target.style.borderColor="#FF4D4D"} onBlur={e=>e.target.style.borderColor="#F3F4F6"}/>
          </div>
        </div>

        {/* Código promo */}
        <div style={{ background:"#fff",borderRadius:20,padding:"18px 20px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
          <div style={{ fontSize:14,fontWeight:800,color:"#111",marginBottom:12 }}>🎟 Código de descuento (opcional)</div>
          <input value={promo} onChange={e=>{ setPromo(e.target.value); setResult(null); }} placeholder="Ej: BIENVENIDO, PIZZA10"
            style={{ width:"100%",padding:"11px 14px",background:"#F9FAFB",border:"2px solid #F3F4F6",borderRadius:12,fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box",textTransform:"uppercase" }}
            onFocus={e=>e.target.style.borderColor="#FF4D4D"} onBlur={e=>e.target.style.borderColor="#F3F4F6"}/>
        </div>

        {/* Calcular */}
        <button onClick={calculate} disabled={!km || parseFloat(km) <= 0}
          style={{ width:"100%",padding:"16px",background:(km&&parseFloat(km)>0)?"#FF4D4D":"#E5E7EB",color:(km&&parseFloat(km)>0)?"#fff":"#9CA3AF",border:"none",borderRadius:16,fontSize:15,fontWeight:700,cursor:(km&&parseFloat(km)>0)?"pointer":"not-allowed",fontFamily:"inherit",boxShadow:(km&&parseFloat(km)>0)?"0 4px 14px rgba(255,77,77,0.3)":"none" }}>
          Calcular costo de envío 🧮
        </button>

        {/* Resultado */}
        {result&&(
          <div style={{ background:"#fff",borderRadius:20,padding:"20px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)",animation:"fadeUp 0.3s ease" }}>
            {/* Header resultado */}
            <div style={{ display:"flex",alignItems:"center",gap:12,marginBottom:16,padding:"12px 14px",background:result.rateInfo.outOfCoverage?"#FFF5F5":"#F0FDF4",borderRadius:14 }}>
              <div style={{ fontSize:28 }}>{result.rateInfo.outOfCoverage?"⚠️":"✅"}</div>
              <div>
                <div style={{ fontSize:14,fontWeight:800,color:result.rateInfo.outOfCoverage?"#FF4D4D":"#16A34A" }}>
                  {result.rateInfo.outOfCoverage?"Fuera de cobertura":"Dentro de cobertura"}
                </div>
                <div style={{ fontSize:12,color:"#6B7280",marginTop:2 }}>{result.km} km · {result.rateInfo.label} · 🕐 {result.rateInfo.time}</div>
              </div>
            </div>

            {/* Desglose */}
            <div style={{ display:"flex",flexDirection:"column",gap:0 }}>
              {result.sub > 0 && (
                <div style={{ display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:"1px solid #F9FAFB" }}>
                  <span style={{ fontSize:14,color:"#6B7280" }}>Subtotal pedido</span>
                  <span style={{ fontSize:14,fontWeight:700,color:"#111" }}>${result.sub}</span>
                </div>
              )}
              {result.pct15 && (
                <div style={{ display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:"1px solid #F9FAFB" }}>
                  <span style={{ fontSize:14,color:"#16A34A" }}>Descuento 15%</span>
                  <span style={{ fontSize:14,fontWeight:700,color:"#16A34A" }}>-${result.discount}</span>
                </div>
              )}
              <div style={{ display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:result.surcharge>0||result.freeShip?"1px solid #F9FAFB":"none" }}>
                <span style={{ fontSize:14,color:"#6B7280" }}>Tarifa base ({result.rateInfo.label})</span>
                <span style={{ fontSize:14,fontWeight:700,color:result.freeShip?"#16A34A":"#111" }}>{result.freeShip?"GRATIS":`$${result.rateInfo.price}`}</span>
              </div>
              {result.rainAmt > 0 && (
                <div style={{ display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:"1px solid #F9FAFB" }}>
                  <span style={{ fontSize:14,color:"#6B7280" }}>🌧️ Recargo lluvia</span>
                  <span style={{ fontSize:14,fontWeight:700,color:"#374151" }}>+${result.rainAmt}</span>
                </div>
              )}
              {result.holAmt > 0 && (
                <div style={{ display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:"1px solid #F9FAFB" }}>
                  <span style={{ fontSize:14,color:"#6B7280" }}>🎉 Recargo festivo</span>
                  <span style={{ fontSize:14,fontWeight:700,color:"#374151" }}>+${result.holAmt}</span>
                </div>
              )}
              <div style={{ display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:"1px solid #F9FAFB" }}>
                <span style={{ fontSize:14,fontWeight:600,color:"#374151" }}>Total envío</span>
                <span style={{ fontSize:15,fontWeight:800,color:"#FF4D4D" }}>${result.delivery}</span>
              </div>
            </div>

            {/* TOTAL */}
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",paddingTop:14,marginTop:4,borderTop:"2.5px solid #111" }}>
              <span style={{ fontSize:17,fontWeight:900,color:"#111" }}>Total estimado</span>
              <span style={{ fontSize:22,fontWeight:900,color:"#FF4D4D" }}>${result.total}</span>
            </div>

            {result.freeShip&&<div style={{ marginTop:12,padding:"10px 14px",background:"#F0FDF4",borderRadius:10,fontSize:13,color:"#16A34A",fontWeight:600 }}>🎉 ¡Código BIENVENIDO aplicado — envío gratis!</div>}
            {result.rateInfo.outOfCoverage&&<div style={{ marginTop:10,padding:"10px 14px",background:"#FFF5F5",borderRadius:10,fontSize:12,color:"#FF4D4D",fontWeight:600 }}>⚠️ Esta dirección está fuera del área de cobertura estándar (10 km). Se aplica tarifa de $10 por km adicional.</div>}
          </div>
        )}
      </div>
    </div>
  );
}


// ─────────────────────────────────────────
// HELP CENTER SCREEN  ★ NEW
// ─────────────────────────────────────────
const FAQ = [
  { q:"¿Cuánto tarda mi pedido?",         a:"El tiempo estimado es de 20 a 40 minutos dependiendo de tu zona y el restaurante. Puedes rastrear tu pedido en tiempo real desde la sección Pedidos." },
  { q:"¿Cómo cancelo un pedido?",          a:"Puedes cancelar dentro de los primeros 2 minutos de realizar tu pedido. Después de ese tiempo, el restaurante ya comenzó a prepararlo y no es posible cancelar." },
  { q:"¿Qué hago si mi pedido llegó frío o incompleto?", a:"Contáctanos por WhatsApp o por chat en la app dentro de las 2 horas después de recibir tu pedido. Haremos lo posible por resolver tu caso." },
  { q:"¿Cómo funciona el código BIENVENIDO?", a:"El código BIENVENIDO te da envío gratis en tu primer pedido. Solo aplica una vez y es exclusivo para usuarios nuevos." },
  { q:"¿Puedo cambiar mi dirección de entrega?", a:"Sí, puedes gestionar tus direcciones desde Perfil → Direcciones de entrega. También puedes agregar una nueva dirección durante el proceso de pago." },
  { q:"¿Cuáles son los métodos de pago aceptados?", a:"Actualmente aceptamos efectivo al momento de la entrega y tarjetas de crédito/débito. Próximamente habilitaremos Apple Pay y Mercado Pago." },
];

const CONTACT_OPTIONS = [
  { icon:"💬", label:"Chat en vivo",    sub:"Disponible 8am – 10pm",       color:"#F0F4FF", iconBg:"#6366F1", action:"chat" },
  { icon:"📞", label:"Llamar soporte",  sub:"473 118 8765",                 color:"#F0FDF4", iconBg:"#16A34A", action:"call" },
  { icon:"📧", label:"Enviar email",    sub:"soporte@yummigo.mx",           color:"#FFF5F5", iconBg:"#FF4D4D", action:"email" },
  { icon:"🤝", label:"WhatsApp",        sub:"+52 473 118 8765",             color:"#F0FDF4", iconBg:"#25D366", action:"whatsapp" },
  { icon:"🌐", label:"Sitio web",       sub:"www.yummigo.pro",              color:"#FFFBEB", iconBg:"#F59E0B", action:"website" },
];

function HelpCenterScreen({ onBack, showToast }) {
  const [openFaq, setOpenFaq]   = useState(null);
  const [search, setSearch]     = useState("");
  const [tab, setTab]           = useState("faq"); // faq | contact

  const filteredFaq = FAQ.filter(f => f.q.toLowerCase().includes(search.toLowerCase()) || f.a.toLowerCase().includes(search.toLowerCase()));

  const handleContact = (action) => {
    if(action==="call")      { window.open("tel:4731188765","_self"); return; }
    if(action==="whatsapp")  { window.open("https://wa.me/524731188765?text=Hola%2C%20necesito%20ayuda%20con%20YummiGoApp","_blank"); return; }
    if(action==="email")     { window.open("mailto:soporte@yummigo.mx?subject=Soporte%20YummiGoApp","_blank"); return; }
    if(action==="website")   { window.open("https://www.yummigo.pro","_blank"); return; }
    if(action==="chat")      { showToast("Iniciando chat en vivo..."); return; }
    showToast("Conectando...");
  };

  return (
    <div style={{ background:"#F9FAFB", minHeight:"100vh", paddingBottom:100 }}>
      <ScreenHeader title="Centro de Ayuda" sub="¿En qué podemos ayudarte?" onBack={onBack}/>
      <div style={{ padding:"16px 24px 0" }}>
        <div style={{ background:"#fff",border:"1.5px solid #F3F4F6",borderRadius:14,padding:"11px 16px",display:"flex",alignItems:"center",gap:10,marginBottom:16 }}>
          <span style={{ fontSize:16,opacity:0.4 }}>🔍</span>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Buscar en ayuda..."
            style={{ border:"none",background:"transparent",fontSize:14,color:"#111",outline:"none",flex:1,fontFamily:"inherit" }}/>
          {search&&<span onClick={()=>setSearch("")} style={{ cursor:"pointer",fontSize:14,opacity:0.4 }}>✕</span>}
        </div>
        <div style={{ display:"flex",gap:8,marginBottom:20 }}>
          {[{id:"faq",label:"Preguntas frecuentes"},{id:"contact",label:"Contacto"}].map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)} style={{ flex:1,padding:"11px 0",background:tab===t.id?"#FF4D4D":"#fff",color:tab===t.id?"#fff":"#6B7280",border:`1.5px solid ${tab===t.id?"#FF4D4D":"#F3F4F6"}`,borderRadius:12,fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {tab==="faq"&&(
        <div style={{ padding:"0 24px", display:"flex", flexDirection:"column", gap:10 }}>
          {filteredFaq.length===0?(
            <div style={{ textAlign:"center",padding:"40px 0",color:"#9CA3AF" }}>
              <div style={{ fontSize:40 }}>🔍</div>
              <div style={{ fontSize:14,fontWeight:600,color:"#374151",marginTop:8 }}>Sin resultados</div>
            </div>
          ):filteredFaq.map((faq,i)=>(
            <div key={i} style={{ background:"#fff",borderRadius:18,overflow:"hidden",boxShadow:"0 1px 8px rgba(0,0,0,0.05)" }}
              onClick={()=>setOpenFaq(openFaq===i?null:i)}>
              <div style={{ padding:"16px 18px",display:"flex",alignItems:"center",gap:12 }}>
                <div style={{ width:32,height:32,borderRadius:10,background:"#FFF5F5",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0 }}>❓</div>
                <div style={{ flex:1,fontSize:14,fontWeight:700,color:"#111",lineHeight:1.4 }}>{faq.q}</div>
                <span style={{ fontSize:14,color:"#D1D5DB",flexShrink:0 }}>{openFaq===i?"∧":"∨"}</span>
              </div>
              {openFaq===i&&(
                <div style={{ padding:"0 18px 16px 62px",fontSize:13,color:"#6B7280",lineHeight:1.7,borderTop:"1px solid #F9FAFB" }}>
                  <div style={{ paddingTop:12 }}>{faq.a}</div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {tab==="contact"&&(
        <div style={{ padding:"0 24px",display:"flex",flexDirection:"column",gap:12 }}>
          <div style={{ background:"linear-gradient(120deg,#FF4D4D,#FF6B6B)",borderRadius:20,padding:"20px 22px",marginBottom:4 }}>
            <div style={{ fontSize:22,marginBottom:8 }}>👋</div>
            <div style={{ fontSize:16,fontWeight:800,color:"#fff",marginBottom:4 }}>Estamos aquí para ayudarte</div>
            <div style={{ fontSize:13,color:"rgba(255,255,255,0.8)" }}>Nuestro equipo responde en menos de 5 minutos en horario de atención.</div>
          </div>
          {CONTACT_OPTIONS.map((opt,i)=>(
            <div key={i} onClick={()=>handleContact(opt.action)}
              style={{ background:"#fff",borderRadius:18,padding:"16px 18px",boxShadow:"0 1px 8px rgba(0,0,0,0.05)",cursor:"pointer",display:"flex",alignItems:"center",gap:14,transition:"transform 0.15s" }}
              onMouseEnter={e=>e.currentTarget.style.transform="translateX(4px)"}
              onMouseLeave={e=>e.currentTarget.style.transform="translateX(0)"}>
              <div style={{ width:50,height:50,borderRadius:16,background:opt.color,display:"flex",alignItems:"center",justifyContent:"center",fontSize:24,flexShrink:0 }}>{opt.icon}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:15,fontWeight:700,color:"#111" }}>{opt.label}</div>
                <div style={{ fontSize:12,color:"#9CA3AF",marginTop:2 }}>{opt.sub}</div>
              </div>
              <span style={{ fontSize:18,color:"#D1D5DB" }}>›</span>
            </div>
          ))}
          <div style={{ background:"#fff",borderRadius:18,padding:"16px 18px",boxShadow:"0 1px 8px rgba(0,0,0,0.05)",marginTop:4 }}>
            <div style={{ fontSize:13,fontWeight:800,color:"#111",marginBottom:12 }}>⏰ Horario de atención</div>
            {[["Lunes – Sábado","9:00 am – 10:00 pm"],["Domingos","9:00 am – 9:00 pm"]].map(([d,h],i)=>(
              <div key={i} style={{ display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:i<1?"1px solid #F9FAFB":"none" }}>
                <span style={{ fontSize:13,color:"#374151" }}>{d}</span>
                <span style={{ fontSize:13,fontWeight:700,color:"#111" }}>{h}</span>
              </div>
            ))}
            <div style={{ marginTop:14,padding:"12px 14px",background:"#FFF5F5",borderRadius:12,display:"flex",alignItems:"center",gap:10 }}>
              <span style={{ fontSize:20 }}>📞</span>
              <div>
                <div style={{ fontSize:12,color:"#9CA3AF",fontWeight:600 }}>TELÉFONO DE SOPORTE</div>
                <div style={{ fontSize:15,fontWeight:800,color:"#FF4D4D",marginTop:2,letterSpacing:0.5 }}>473 118 8765</div>
              </div>
            </div>
            <div style={{ marginTop:10,padding:"12px 14px",background:"#FFFBEB",borderRadius:12,display:"flex",alignItems:"center",gap:10 }}>
              <span style={{ fontSize:20 }}>🌐</span>
              <div>
                <div style={{ fontSize:12,color:"#9CA3AF",fontWeight:600 }}>SITIO WEB</div>
                <div onClick={()=>window.open("https://www.yummigo.pro","_blank")} style={{ fontSize:14,fontWeight:700,color:"#F59E0B",marginTop:2,cursor:"pointer",textDecoration:"underline" }}>www.yummigo.pro</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────
// NOTIFICATIONS SCREEN
// ─────────────────────────────────────────
const NOTIF_KEY = "notifSettings";
const loadNotifSettings = () => {
  try { return JSON.parse(localStorage.getItem(NOTIF_KEY)||"null")||{ orderConfirmed:true, orderPreparing:true, orderOnWay:true, orderDelivered:true, promos:true, weeklyOffers:true, flashSales:true, newRestaurants:false }; } catch { return {}; }
};
function NotificationsScreen({ onBack }) {
  const [settings, setSettings] = useState(loadNotifSettings);
  const [saved, setSaved]       = useState(false);
  const toggle = (key) => {
    setSettings(prev=>{ const next={...prev,[key]:!prev[key]}; localStorage.setItem(NOTIF_KEY,JSON.stringify(next)); return next; });
    setSaved(true); setTimeout(()=>setSaved(false),1500);
  };
  const Section = ({ title, children }) => (
    <div style={{ marginBottom:20 }}>
      <div style={{ fontSize:12,fontWeight:700,color:"#9CA3AF",letterSpacing:0.5,marginBottom:10,paddingLeft:4 }}>{title}</div>
      <div style={{ background:"#fff",borderRadius:20,boxShadow:"0 1px 8px rgba(0,0,0,0.06)",overflow:"hidden" }}>{children}</div>
    </div>
  );
  const Row = ({ icon, bg, label, sub, k, last }) => (
    <div style={{ display:"flex",alignItems:"center",gap:14,padding:"16px 18px",borderBottom:last?"none":"1px solid #F9FAFB" }}>
      <div style={{ width:42,height:42,borderRadius:12,background:bg,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0 }}>{icon}</div>
      <div style={{ flex:1 }}><div style={{ fontSize:14,fontWeight:700,color:"#111" }}>{label}</div>{sub&&<div style={{ fontSize:12,color:"#9CA3AF",marginTop:2 }}>{sub}</div>}</div>
      <Toggle value={settings[k]} onChange={()=>toggle(k)}/>
    </div>
  );
  return (
    <div style={{ background:"#F9FAFB",minHeight:"100vh",paddingBottom:100 }}>
      <ScreenHeader title="Notificaciones" sub="Personaliza tus alertas" onBack={onBack}
        rightEl={saved?<div style={{ background:"#F0FDF4",color:"#16A34A",fontSize:12,fontWeight:700,padding:"4px 12px",borderRadius:99 }}>✓ Guardado</div>:null}/>
      <div style={{ padding:"20px 24px" }}>
        <Section title="📦 ESTADO DE PEDIDOS">
          <Row icon="✅" bg="#ECFDF5" label="Pedido confirmado" sub="Cuando el restaurante acepta tu orden" k="orderConfirmed"/>
          <Row icon="👨‍🍳" bg="#FFF7ED" label="En preparación" sub="Cuando empiezan a cocinar" k="orderPreparing"/>
          <Row icon="🛵" bg="#F0F4FF" label="Repartidor en camino" sub="Cuando tu pedido va en ruta" k="orderOnWay"/>
          <Row icon="🎉" bg="#FDF4FF" label="Pedido entregado" sub="Confirmación de entrega" k="orderDelivered" last/>
        </Section>
        <Section title="🎁 PROMOCIONES">
          <Row icon="🏷️" bg="#FEF2F2" label="Nuevas promociones" sub="Descuentos y cupones" k="promos"/>
          <Row icon="📅" bg="#FFFBEB" label="Ofertas semanales" sub="Resumen cada semana" k="weeklyOffers"/>
          <Row icon="⚡" bg="#FFF5F5" label="Ventas relámpago" sub="Ofertas por tiempo limitado" k="flashSales"/>
          <Row icon="🏪" bg="#F0FDF4" label="Nuevos restaurantes" sub="Cuando lleguen a tu zona" k="newRestaurants" last/>
        </Section>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────
// CUSTOMER AUTH SYSTEM
// ─────────────────────────────────────────
const CUSTOMER_KEY = "yg_customers";
const CUSTOMER_SESSION_KEY = "yg_customer_session";

const loadCustomers   = () => { try { return JSON.parse(localStorage.getItem(CUSTOMER_KEY)||"[]"); } catch { return []; } };
const saveCustomers   = (l) => localStorage.setItem(CUSTOMER_KEY, JSON.stringify(l));
const getCustomerSession  = () => { try { return JSON.parse(localStorage.getItem(CUSTOMER_SESSION_KEY)||"null"); } catch { return null; } };
const setCustomerSession  = (s) => localStorage.setItem(CUSTOMER_SESSION_KEY, JSON.stringify(s));
const clearCustomerSession= ()  => localStorage.removeItem(CUSTOMER_SESSION_KEY);

// ─────────────────────────────────────────
// CUSTOMER REGISTER SCREEN
// ─────────────────────────────────────────
function CustomerRegisterScreen({ onSuccess, onBack, onGoLogin }) {
  const [step, setStep] = useState(1); // 1=personal, 2=address, 3=password
  const [form, setForm] = useState({ name:"", phone:"", email:"", street:"", number:"", colonia:"", cp:"", refs:"", pass:"", pass2:"" });
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const set = k => v => setForm(f=>({...f,[k]:v}));

  const validate1 = () => {
    const e={};
    if(!form.name.trim())            e.name="Tu nombre es requerido";
    if(!/^\d{10}$/.test(form.phone.replace(/\D/g,""))) e.phone="Número de 10 dígitos";
    if(form.email && !/\S+@\S+\.\S+/.test(form.email)) e.email="Correo inválido";
    setErrors(e); return Object.keys(e).length===0;
  };
  const validate2 = () => {
    const e={};
    if(!form.street.trim())  e.street="Requerido";
    if(!form.number.trim())  e.number="Requerido";
    if(!form.colonia.trim()) e.colonia="Requerido";
    if(form.cp && form.cp.length<5) e.cp="CP de 5 dígitos";
    setErrors(e); return Object.keys(e).length===0;
  };
  const validate3 = () => {
    const e={};
    if(form.pass.length<6)       e.pass="Mínimo 6 caracteres";
    if(form.pass!==form.pass2)   e.pass2="Las contraseñas no coinciden";
    setErrors(e); return Object.keys(e).length===0;
  };

  const next = () => {
    if(step===1 && !validate1()) return;
    if(step===2 && !validate2()) return;
    if(step===3) { doRegister(); return; }
    setStep(s=>s+1); setErrors({});
  };

  const doRegister = () => {
    if(!validate3()) return;
    setSaving(true);
    setTimeout(() => {
      const customers = loadCustomers();
      const phoneClean = form.phone.replace(/\D/g,"");
      if(customers.find(c=>c.phone===phoneClean)) {
        setErrors({phone:"Este número ya está registrado"}); setStep(1); setSaving(false); return;
      }
      const newCustomer = {
        id: Date.now(),
        name: form.name.trim(),
        phone: phoneClean,
        email: form.email.trim().toLowerCase()||"",
        address: { street:form.street.trim(), number:form.number.trim(), colonia:form.colonia.trim(), cp:form.cp.trim(), refs:form.refs.trim() },
        pass: form.pass,
        createdAt: new Date().toISOString(),
        totalOrders: 0,
        totalSpent: 0,
        active: true,
      };
      const updated = [...customers, newCustomer];
      saveCustomers(updated);
      const session = { id:newCustomer.id, name:newCustomer.name, phone:newCustomer.phone, email:newCustomer.email, role:"customer" };
      setCustomerSession(session);
      onSuccess(session);
      setSaving(false);
    }, 600);
  };

  const InputStyle = (hasErr) => ({ width:"100%",padding:"13px 14px",background:"#fff",border:`2px solid ${hasErr?"#FF4D4D":"#F3F4F6"}`,borderRadius:13,fontSize:15,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box",transition:"border-color 0.2s" });
  const FocusOn  = (e) => e.target.style.borderColor="#FF4D4D";
  const FocusOff = (k,e) => e.target.style.borderColor=errors[k]?"#FF4D4D":"#F3F4F6";

  return (
    <div style={{ background:"#F9FAFB",minHeight:"100vh",display:"flex",flexDirection:"column" }}>
      <style>{`@keyframes slideIn{from{opacity:0;transform:translateX(30px)}to{opacity:1;transform:translateX(0)}}`}</style>

      {/* Header */}
      <div style={{ background:"#fff",padding:"14px 24px 18px",borderBottom:"1px solid #F3F4F6" }}>
        <div style={{ display:"flex",alignItems:"center",gap:12 }}>
          <div onClick={step===1?onBack:()=>{setStep(s=>s-1);setErrors({});}} style={{ width:38,height:38,borderRadius:12,background:"#F9FAFB",border:"1.5px solid #F3F4F6",fontSize:18,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center" }}>←</div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:17,fontWeight:800,color:"#111" }}>Crear cuenta</div>
            <div style={{ fontSize:12,color:"#9CA3AF" }}>Paso {step} de 3 · {step===1?"Tus datos":step===2?"Tu dirección":"Contraseña"}</div>
          </div>
        </div>
        {/* Progress bar */}
        <div style={{ display:"flex",gap:6,marginTop:14 }}>
          {[1,2,3].map(s=><div key={s} style={{ flex:1,height:4,borderRadius:99,background:s<=step?"#FF4D4D":"#F3F4F6",transition:"background 0.3s" }}/>)}
        </div>
      </div>

      <div style={{ flex:1,padding:"24px",display:"flex",flexDirection:"column",gap:14,animation:"slideIn 0.3s ease" }}>

        {/* STEP 1: Personal */}
        {step===1&&<>
          <div style={{ fontSize:22,fontWeight:900,color:"#111",marginBottom:4 }}>👋 ¡Hola! ¿Cómo te llamas?</div>
          <div style={{ fontSize:14,color:"#9CA3AF",marginBottom:8 }}>Ingresa tus datos para crear tu cuenta gratuita.</div>

          <div>
            <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>NOMBRE COMPLETO *</div>
            <input value={form.name} onChange={e=>set("name")(e.target.value)} placeholder="Ej: María García"
              style={InputStyle(errors.name)} onFocus={FocusOn} onBlur={e=>FocusOff("name",e)}/>
            {errors.name&&<div style={{ fontSize:12,color:"#FF4D4D",marginTop:4 }}>⚠️ {errors.name}</div>}
          </div>
          <div>
            <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>NÚMERO DE TELÉFONO *</div>
            <input value={form.phone} onChange={e=>set("phone")(e.target.value.replace(/\D/g,"").slice(0,10))} placeholder="4731234567" type="tel" maxLength={10}
              style={InputStyle(errors.phone)} onFocus={FocusOn} onBlur={e=>FocusOff("phone",e)}/>
            {errors.phone&&<div style={{ fontSize:12,color:"#FF4D4D",marginTop:4 }}>⚠️ {errors.phone}</div>}
            <div style={{ fontSize:11,color:"#9CA3AF",marginTop:4 }}>Se usará para contactarte con tu pedido</div>
          </div>
          <div>
            <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>CORREO ELECTRÓNICO (opcional)</div>
            <input value={form.email} onChange={e=>set("email")(e.target.value)} placeholder="tu@correo.com" type="email" autoCapitalize="none"
              style={InputStyle(errors.email)} onFocus={FocusOn} onBlur={e=>FocusOff("email",e)}/>
            {errors.email&&<div style={{ fontSize:12,color:"#FF4D4D",marginTop:4 }}>⚠️ {errors.email}</div>}
          </div>
        </>}

        {/* STEP 2: Address */}
        {step===2&&<>
          <div style={{ fontSize:22,fontWeight:900,color:"#111",marginBottom:4 }}>📍 ¿A dónde enviamos?</div>
          <div style={{ fontSize:14,color:"#9CA3AF",marginBottom:8 }}>Ingresa tu dirección principal de entrega.</div>

          <div style={{ display:"flex",gap:10 }}>
            <div style={{ flex:2 }}>
              <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>CALLE *</div>
              <input value={form.street} onChange={e=>set("street")(e.target.value)} placeholder="Av. López Mateos"
                style={InputStyle(errors.street)} onFocus={FocusOn} onBlur={e=>FocusOff("street",e)}/>
              {errors.street&&<div style={{ fontSize:11,color:"#FF4D4D",marginTop:3 }}>⚠️ {errors.street}</div>}
            </div>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>NÚMERO *</div>
              <input value={form.number} onChange={e=>set("number")(e.target.value)} placeholder="123"
                style={InputStyle(errors.number)} onFocus={FocusOn} onBlur={e=>FocusOff("number",e)}/>
              {errors.number&&<div style={{ fontSize:11,color:"#FF4D4D",marginTop:3 }}>⚠️ {errors.number}</div>}
            </div>
          </div>
          <div style={{ display:"flex",gap:10 }}>
            <div style={{ flex:2 }}>
              <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>COLONIA *</div>
              <input value={form.colonia} onChange={e=>set("colonia")(e.target.value)} placeholder="Centro"
                style={InputStyle(errors.colonia)} onFocus={FocusOn} onBlur={e=>FocusOff("colonia",e)}/>
              {errors.colonia&&<div style={{ fontSize:11,color:"#FF4D4D",marginTop:3 }}>⚠️ {errors.colonia}</div>}
            </div>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>C.P.</div>
              <input value={form.cp} onChange={e=>set("cp")(e.target.value.replace(/\D/g,"").slice(0,5))} placeholder="20000" maxLength={5}
                style={InputStyle(errors.cp)} onFocus={FocusOn} onBlur={e=>FocusOff("cp",e)}/>
              {errors.cp&&<div style={{ fontSize:11,color:"#FF4D4D",marginTop:3 }}>⚠️ {errors.cp}</div>}
            </div>
          </div>
          <div>
            <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>REFERENCIAS (opcional)</div>
            <input value={form.refs} onChange={e=>set("refs")(e.target.value)} placeholder="Portón azul, frente al parque..."
              style={InputStyle(false)} onFocus={FocusOn} onBlur={e=>FocusOff("refs",e)}/>
          </div>
        </>}

        {/* STEP 3: Password */}
        {step===3&&<>
          <div style={{ fontSize:22,fontWeight:900,color:"#111",marginBottom:4 }}>🔒 Crea tu contraseña</div>
          <div style={{ fontSize:14,color:"#9CA3AF",marginBottom:8 }}>Para proteger tu cuenta y tus pedidos.</div>

          <div>
            <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>CONTRASEÑA *</div>
            <input value={form.pass} onChange={e=>set("pass")(e.target.value)} type="password" placeholder="Mínimo 6 caracteres"
              style={InputStyle(errors.pass)} onFocus={FocusOn} onBlur={e=>FocusOff("pass",e)}/>
            {errors.pass&&<div style={{ fontSize:12,color:"#FF4D4D",marginTop:4 }}>⚠️ {errors.pass}</div>}
          </div>
          <div>
            <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>CONFIRMAR CONTRASEÑA *</div>
            <input value={form.pass2} onChange={e=>set("pass2")(e.target.value)} type="password" placeholder="Repite la contraseña"
              style={InputStyle(errors.pass2)} onFocus={FocusOn} onBlur={e=>FocusOff("pass2",e)}/>
            {errors.pass2&&<div style={{ fontSize:12,color:"#FF4D4D",marginTop:4 }}>⚠️ {errors.pass2}</div>}
          </div>

          <div style={{ background:"#F0FDF4",borderRadius:13,padding:"12px 14px",display:"flex",gap:8,alignItems:"flex-start" }}>
            <span style={{ fontSize:16 }}>✅</span>
            <div style={{ fontSize:12,color:"#15803D",lineHeight:1.6 }}>Al registrarte aceptas que tus datos sean usados para gestionar tus pedidos en YummiGoApp. No compartimos tu información con terceros.</div>
          </div>
        </>}
      </div>

      {/* Bottom CTA */}
      <div style={{ padding:"16px 24px 36px",background:"#fff",borderTop:"1px solid #F3F4F6" }}>
        <button onClick={next} disabled={saving}
          style={{ width:"100%",padding:"16px",background:saving?"#E5E7EB":"#FF4D4D",color:saving?"#9CA3AF":"#fff",border:"none",borderRadius:16,fontSize:15,fontWeight:700,cursor:saving?"not-allowed":"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",justifyContent:"center",gap:10,boxShadow:saving?"none":"0 4px 16px rgba(255,77,77,0.3)" }}>
          {saving?<><div style={{ width:18,height:18,borderRadius:99,border:"2px solid rgba(255,255,255,0.3)",borderTopColor:"#FF4D4D",animation:"spin 0.7s linear infinite" }}/> Creando cuenta...</>
            :step===3?"🎉 Crear mi cuenta":step===2?"Continuar →":"Siguiente →"}
        </button>
        {step===1&&(
          <div style={{ textAlign:"center",marginTop:14,fontSize:13,color:"#9CA3AF" }}>
            ¿Ya tienes cuenta? <span onClick={onGoLogin} style={{ color:"#FF4D4D",fontWeight:700,cursor:"pointer" }}>Inicia sesión</span>
          </div>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────
// CUSTOMER LOGIN SCREEN
// ─────────────────────────────────────────
function CustomerLoginScreen({ onSuccess, onBack, onGoRegister }) {
  const [phone, setPhone] = useState("");
  const [pass, setPass]   = useState("");
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [shake, setShake] = useState(false);

  const doLogin = () => {
    setError(""); setLoading(true);
    setTimeout(() => {
      const customers = loadCustomers();
      const phoneClean = phone.replace(/\D/g,"");
      const found = customers.find(c => c.phone===phoneClean && c.pass===pass && c.active!==false);
      if(found) {
        const session = { id:found.id, name:found.name, phone:found.phone, email:found.email, role:"customer" };
        setCustomerSession(session);
        onSuccess(session);
      } else {
        setError("Número o contraseña incorrectos"); setShake(true); setTimeout(()=>setShake(false),600);
      }
      setLoading(false);
    }, 600);
  };

  return (
    <div style={{ background:"#F9FAFB",minHeight:"100vh",display:"flex",flexDirection:"column" }}>
      <style>{`@keyframes shake{0%,100%{transform:translateX(0)}20%,60%{transform:translateX(-8px)}40%,80%{transform:translateX(8px)}}`}</style>
      <div style={{ background:"#fff",padding:"14px 24px 18px",borderBottom:"1px solid #F3F4F6" }}>
        <div style={{ display:"flex",alignItems:"center",gap:12 }}>
          <div onClick={onBack} style={{ width:38,height:38,borderRadius:12,background:"#F9FAFB",border:"1.5px solid #F3F4F6",fontSize:18,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center" }}>←</div>
          <div style={{ flex:1 }}><div style={{ fontSize:17,fontWeight:800,color:"#111" }}>Iniciar sesión</div><div style={{ fontSize:12,color:"#9CA3AF" }}>Bienvenido de vuelta</div></div>
        </div>
      </div>

      <div style={{ flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"32px 24px" }}>
        <div style={{ width:80,height:80,borderRadius:24,background:"linear-gradient(135deg,#FF4D4D,#FF6B6B)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:36,marginBottom:20,boxShadow:"0 8px 32px rgba(255,77,77,0.35)" }}>🛵</div>
        <div style={{ fontSize:22,fontWeight:900,color:"#111",marginBottom:6 }}>¡Hola de nuevo!</div>
        <div style={{ fontSize:14,color:"#9CA3AF",marginBottom:32,textAlign:"center" }}>Ingresa con tu número de teléfono</div>

        <div style={{ width:"100%",maxWidth:360,animation:shake?"shake 0.5s ease":"none" }}>
          <div style={{ marginBottom:14 }}>
            <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>NÚMERO DE TELÉFONO</div>
            <div style={{ position:"relative" }}>
              <span style={{ position:"absolute",left:14,top:"50%",transform:"translateY(-50%)",fontSize:16,opacity:0.4 }}>📱</span>
              <input value={phone} onChange={e=>{setPhone(e.target.value.replace(/\D/g,"").slice(0,10));setError("");}}
                onKeyDown={e=>e.key==="Enter"&&doLogin()} placeholder="4731234567" type="tel" maxLength={10}
                style={{ width:"100%",padding:"13px 14px 13px 44px",background:"#fff",border:`2px solid ${error?"#FF4D4D":"#F3F4F6"}`,borderRadius:14,fontSize:15,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}
                onFocus={e=>e.target.style.borderColor="#FF4D4D"} onBlur={e=>e.target.style.borderColor=error?"#FF4D4D":"#F3F4F6"}/>
            </div>
          </div>
          <div style={{ marginBottom:error?8:24 }}>
            <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:6 }}>CONTRASEÑA</div>
            <div style={{ position:"relative" }}>
              <span style={{ position:"absolute",left:14,top:"50%",transform:"translateY(-50%)",fontSize:16,opacity:0.4 }}>🔒</span>
              <input value={pass} onChange={e=>{setPass(e.target.value);setError("");}}
                onKeyDown={e=>e.key==="Enter"&&doLogin()}
                type={showPass?"text":"password"} placeholder="Tu contraseña"
                style={{ width:"100%",padding:"13px 48px 13px 44px",background:"#fff",border:`2px solid ${error?"#FF4D4D":"#F3F4F6"}`,borderRadius:14,fontSize:15,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}
                onFocus={e=>e.target.style.borderColor="#FF4D4D"} onBlur={e=>e.target.style.borderColor=error?"#FF4D4D":"#F3F4F6"}/>
              <span onClick={()=>setShowPass(p=>!p)} style={{ position:"absolute",right:14,top:"50%",transform:"translateY(-50%)",fontSize:18,cursor:"pointer",opacity:0.4 }}>{showPass?"🙈":"👁️"}</span>
            </div>
          </div>
          {error&&<div style={{ display:"flex",alignItems:"center",gap:8,background:"#FFF5F5",border:"1.5px solid #FFE4E4",borderRadius:10,padding:"10px 14px",marginBottom:20,animation:"fadeUp 0.2s ease" }}><span style={{ fontSize:16 }}>⚠️</span><span style={{ fontSize:13,color:"#FF4D4D",fontWeight:600 }}>{error}</span></div>}
          <button onClick={doLogin} disabled={loading||!phone||!pass}
            style={{ width:"100%",padding:"16px",background:(!phone||!pass)?"#E5E7EB":"#FF4D4D",color:(!phone||!pass)?"#9CA3AF":"#fff",border:"none",borderRadius:16,fontSize:15,fontWeight:700,cursor:(!phone||!pass)?"not-allowed":"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",justifyContent:"center",gap:10,boxShadow:(!phone||!pass)?"none":"0 4px 16px rgba(255,77,77,0.3)" }}>
            {loading?<><div style={{ width:18,height:18,borderRadius:99,border:"2px solid rgba(255,255,255,0.3)",borderTopColor:"#FF4D4D",animation:"spin 0.7s linear infinite" }}/> Verificando...</>:"Entrar →"}
          </button>
          <div style={{ textAlign:"center",marginTop:16,fontSize:13,color:"#9CA3AF" }}>
            ¿No tienes cuenta? <span onClick={onGoRegister} style={{ color:"#FF4D4D",fontWeight:700,cursor:"pointer" }}>Regístrate gratis</span>
          </div>
        </div>
      </div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}

// ─────────────────────────────────────────
// CHECKOUT AUTH GATE — shown when guest tries to order
// ─────────────────────────────────────────
function CheckoutAuthGate({ onSuccess, onClose }) {
  const [screen, setScreen] = useState("choose"); // choose | login | register

  if(screen==="login")    return <CustomerLoginScreen    onSuccess={onSuccess} onBack={()=>setScreen("choose")} onGoRegister={()=>setScreen("register")}/>;
  if(screen==="register") return <CustomerRegisterScreen onSuccess={onSuccess} onBack={()=>setScreen("choose")} onGoLogin={()=>setScreen("login")}/>;

  return (
    <div style={{ position:"fixed",inset:0,background:"rgba(0,0,0,0.55)",zIndex:800,display:"flex",alignItems:"flex-end",justifyContent:"center" }} onClick={onClose}>
      <div onClick={e=>e.stopPropagation()} style={{ background:"#fff",width:"100%",maxWidth:430,borderRadius:"28px 28px 0 0",padding:"24px 24px 44px",animation:"fadeUp 0.3s ease" }}>
        <div style={{ width:44,height:4,background:"#E5E7EB",borderRadius:99,margin:"0 auto 24px" }}/>
        {/* Icon */}
        <div style={{ textAlign:"center",marginBottom:20 }}>
          <div style={{ width:72,height:72,borderRadius:22,background:"linear-gradient(135deg,#FF4D4D,#FF6B6B)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:32,margin:"0 auto 14px",boxShadow:"0 6px 24px rgba(255,77,77,0.3)" }}>🛵</div>
          <div style={{ fontSize:20,fontWeight:900,color:"#111",marginBottom:6 }}>¡Casi listo para ordenar!</div>
          <div style={{ fontSize:14,color:"#9CA3AF",lineHeight:1.6 }}>Necesitas una cuenta para hacer tu pedido.<br/>Es gratis y toma menos de 2 minutos. 🎉</div>
        </div>

        <button onClick={()=>setScreen("register")}
          style={{ width:"100%",padding:"16px",background:"#FF4D4D",color:"#fff",border:"none",borderRadius:16,fontSize:15,fontWeight:700,cursor:"pointer",fontFamily:"inherit",marginBottom:12,boxShadow:"0 4px 16px rgba(255,77,77,0.3)" }}>
          ✨ Crear cuenta gratis
        </button>
        <button onClick={()=>setScreen("login")}
          style={{ width:"100%",padding:"16px",background:"#F9FAFB",color:"#111",border:"1.5px solid #F3F4F6",borderRadius:16,fontSize:15,fontWeight:700,cursor:"pointer",fontFamily:"inherit",marginBottom:16 }}>
          Ya tengo cuenta — Iniciar sesión
        </button>
        <div style={{ textAlign:"center",fontSize:13,color:"#D1D5DB" }}>
          Continuarás como invitado si cierras
        </div>
      </div>
    </div>
  );
}

function CheckoutScreen({ restaurant, onBack, onOrderPlaced, initialPromo=null }) {
  const [menuItems, setMenuItems] = useState([]);
  const [loadingMenu, setLoadingMenu] = useState(true);
  const [cart, setCart]           = useState([]);
  const [step, setStep]           = useState("menu");
  const [addresses, setAddresses] = useState(()=>loadAddresses());
  const [payments]                = useState(()=>[...PAYMENT_STATIC,...loadPayments()]);
  const [selAddr, setSelAddr]     = useState(null);
  const [selPay, setSelPay]       = useState("cash");
  const [showAddrMgr, setShowAddrMgr] = useState(false);
  const [showPayMgr, setShowPayMgr]   = useState(false);
  const [promoInput, setPromoInput] = useState(initialPromo||"");
  const [promo, setPromo]         = useState(initialPromo);
  const [promoErr, setPromoErr]   = useState(false);
  const [placing, setPlacing]     = useState(false);
  const [isNewUser]               = useState(()=>!localStorage.getItem("hasOrdered"));
  const STEPS = ["menu","cart","address","payment","confirm"];
  const si = STEPS.indexOf(step);

  useEffect(()=>{
    sbGet("menu_items",`restaurant_id=eq.${restaurant.id}&available=eq.true&order=category.asc,name.asc`)
      .then(d=>{
        const items = Array.isArray(d) && d.length > 0 ? d
          : DEMO_MENU_ITEMS.filter(i=>i.restaurant_id===restaurant.id);
        setMenuItems(items);
        setLoadingMenu(false);
      }).catch(()=>{
        setMenuItems(DEMO_MENU_ITEMS.filter(i=>i.restaurant_id===restaurant.id));
        setLoadingMenu(false);
      });
  },[restaurant.id]);

  const grouped  = menuItems.reduce((a,i)=>{ (a[i.category]=a[i.category]||[]).push(i); return a; },{});
  const getQty   = id => cart.find(i=>i.id===id)?.qty||0;
  const updateCart = (item,delta) => setCart(prev=>{
    const ex=prev.find(i=>i.id===item.id);
    if(!ex&&delta>0) return [...prev,{...item,qty:1}];
    return prev.map(i=>i.id===item.id?{...i,qty:i.qty+delta}:i).filter(i=>i.qty>0);
  });
  const cartCount  = cart.reduce((s,i)=>s+i.qty,0);
  const subtotal   = cart.reduce((s,i)=>s+i.price*i.qty,0);
  const isFreeShip = promo && PROMOS_FREE_SHIPPING.includes(promo);
  const discount   = promo && !isFreeShip ? Math.round(subtotal*0.15) : 0;
  const deliveryBase=25; const delivery=isFreeShip?0:deliveryBase;
  const total = subtotal - discount + delivery;

  const applyPromo = () => {
    const code=promoInput.toUpperCase();
    if(PROMOS_FREE_SHIPPING.includes(code)){ if(!isNewUser){setPromoErr(true);setPromo(null);return;} setPromo(code);setPromoErr(false); }
    else if(PROMOS_DISCOUNT.includes(code)){ setPromo(code);setPromoErr(false); }
    else{ setPromoErr(true);setPromo(null); }
  };

  const placeOrder = async () => {
    setPlacing(true);
    try {
      const res = await sbPost("orders",{ restaurant_id:restaurant.id, restaurant_name:restaurant.name,
        delivery_address:(()=>{ const a=addresses.find(x=>x.id===selAddr); return a?`${a.street} #${a.number}, ${a.colonia}, CP ${a.cp}`:"—"; })(),
        payment_method:payments.find(p=>p.id===selPay)?.label||"—",
        subtotal, discount, delivery_fee:delivery, total, promo_code:promo, status:"pending",
        items:cart.map(i=>({id:i.id,name:i.name,price:i.price,qty:i.qty})),
      });
      localStorage.setItem("hasOrdered","true");
      onOrderPlaced(res?.[0]?.id||Math.floor(8000+Math.random()*999));
    } catch {
      localStorage.setItem("hasOrdered","true");
      onOrderPlaced(Math.floor(8000+Math.random()*999));
    }
    setPlacing(false);
  };

  return (
    <div style={{ minHeight:"100vh", background:"#F9FAFB" }}>
      <div style={{ background:"#fff", padding:"14px 24px 16px", borderBottom:"1px solid #F3F4F6", position:"sticky", top:0, zIndex:100 }}>
        <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:step!=="menu"?16:0 }}>
          <div onClick={()=>step==="menu"?onBack():step==="cart"?setStep("menu"):setStep(STEPS[si-1])}
            style={{ width:38,height:38,borderRadius:12,background:"#F9FAFB",border:"1.5px solid #F3F4F6",fontSize:18,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center" }}>←</div>
          <span style={{ fontSize:24 }}>{restaurant.emoji}</span>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:16,fontWeight:800,color:"#111" }}>{step==="menu"?restaurant.name:step==="cart"?"Tu carrito":step==="address"?"Dirección":step==="payment"?"Pago":"Confirmar"}</div>
            <div style={{ fontSize:12,color:"#9CA3AF" }}>{step==="menu"?restaurant.cuisine:`${cartCount} producto${cartCount!==1?"s":""}`}</div>
          </div>
          {step==="menu"&&cartCount>0&&(
            <div onClick={()=>setStep("cart")} style={{ position:"relative",cursor:"pointer" }}>
              <div style={{ width:44,height:44,borderRadius:14,background:"#FF4D4D",display:"flex",alignItems:"center",justifyContent:"center",fontSize:20 }}>🛒</div>
              <div style={{ position:"absolute",top:-6,right:-6,background:"#111",color:"#fff",borderRadius:99,width:20,height:20,fontSize:11,fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",border:"2px solid #fff" }}>{cartCount}</div>
            </div>
          )}
        </div>
        {step!=="menu"&&(
          <div style={{ display:"flex",gap:6 }}>
            {["cart","address","payment","confirm"].map((s,i)=>(
              <div key={s} style={{ flex:1,height:4,borderRadius:99,background:i<=(si-1)?"#FF4D4D":"#F3F4F6",transition:"background 0.3s" }}/>
            ))}
          </div>
        )}
      </div>

      <div style={{ padding:"20px 24px 140px",display:"flex",flexDirection:"column",gap:14 }}>
        {step==="menu"&&(
          loadingMenu?[1,2,3].map(i=>(<div key={i} style={{ background:"#fff",borderRadius:16,padding:16,boxShadow:"0 1px 8px rgba(0,0,0,0.05)",display:"flex",flexDirection:"column",gap:8 }}><Skeleton h={14} w="50%"/><Skeleton h={10} w="70%"/></div>))
          :Object.entries(grouped).map(([cat,items])=>(
            <div key={cat}>
              <div style={{ display:"flex",alignItems:"center",gap:8,marginBottom:10 }}>
                <div style={{ width:8,height:8,borderRadius:99,background:CAT_COLORS[cat]||"#6B7280" }}/>
                <span style={{ fontSize:14,fontWeight:800,color:"#374151" }}>{cat}</span>
              </div>
              <div style={{ display:"flex",flexDirection:"column",gap:8 }}>
                {items.map(item=>{
                  const qty=getQty(item.id);
                  return (
                    <div key={item.id} style={{ background:"#fff",borderRadius:16,padding:"14px 16px",boxShadow:"0 1px 8px rgba(0,0,0,0.05)",display:"flex",alignItems:"center",gap:12 }}>
                      <div style={{ flex:1 }}>
                        <div style={{ fontSize:14,fontWeight:700,color:"#111" }}>{item.name}</div>
                        {item.description&&<div style={{ fontSize:12,color:"#9CA3AF",marginTop:2 }}>{item.description}</div>}
                        <div style={{ fontSize:15,fontWeight:900,color:"#FF4D4D",marginTop:4 }}>${item.price}</div>
                      </div>
                      <div style={{ display:"flex",alignItems:"center",gap:8 }}>
                        {qty>0&&<><button onClick={()=>updateCart(item,-1)} style={{ width:30,height:30,borderRadius:99,border:"2px solid #F3F4F6",background:"#fff",fontSize:16,cursor:"pointer",fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",color:"#111" }}>−</button>
                        <span style={{ fontSize:15,fontWeight:800,color:"#111",minWidth:16,textAlign:"center" }}>{qty}</span></>}
                        <button onClick={()=>updateCart(item,1)} style={{ width:30,height:30,borderRadius:99,border:"none",background:"#FF4D4D",fontSize:16,cursor:"pointer",fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",color:"#fff" }}>+</button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))
        )}

        {step==="cart"&&<>
          <div style={{ background:"#fff",borderRadius:20,overflow:"hidden",boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
            {cart.map((item,i)=>(
              <div key={item.id} style={{ display:"flex",alignItems:"center",gap:14,padding:"16px 18px",borderBottom:i<cart.length-1?"1px solid #F9FAFB":"none" }}>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:14,fontWeight:700,color:"#111" }}>{item.name}</div>
                  <div style={{ fontSize:14,fontWeight:800,color:"#FF4D4D",marginTop:4 }}>${item.price*item.qty}</div>
                </div>
                <div style={{ display:"flex",alignItems:"center",gap:10 }}>
                  <button onClick={()=>updateCart(item,-1)} style={{ width:30,height:30,borderRadius:99,border:"2px solid #F3F4F6",background:"#fff",fontSize:16,cursor:"pointer",fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",color:"#111" }}>−</button>
                  <span style={{ fontSize:15,fontWeight:800,color:"#111",minWidth:16,textAlign:"center" }}>{item.qty}</span>
                  <button onClick={()=>updateCart(item,1)} style={{ width:30,height:30,borderRadius:99,border:"none",background:"#FF4D4D",fontSize:16,cursor:"pointer",fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",color:"#fff" }}>+</button>
                </div>
              </div>
            ))}
          </div>
          <div style={{ background:"#fff",borderRadius:20,padding:"16px 18px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
            <div style={{ fontSize:14,fontWeight:700,marginBottom:10 }}>🎟 Código de descuento</div>
            <div style={{ display:"flex",gap:10 }}>
              <input value={promoInput} onChange={e=>{setPromoInput(e.target.value);setPromoErr(false);}} placeholder="Ej: BIENVENIDO"
                style={{ flex:1,border:`2px solid ${promoErr?"#FF4D4D":promo?"#16A34A":"#F3F4F6"}`,borderRadius:12,padding:"10px 14px",fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",background:"#F9FAFB" }}/>
              <button onClick={applyPromo} style={{ padding:"10px 18px",background:"#FF4D4D",color:"#fff",border:"none",borderRadius:12,fontSize:14,fontWeight:700,cursor:"pointer" }}>Aplicar</button>
            </div>
            {promo&&isFreeShip&&<div style={{ fontSize:12,color:"#16A34A",fontWeight:700,marginTop:6 }}>🎉 ¡Envío gratis aplicado!</div>}
            {promo&&!isFreeShip&&<div style={{ fontSize:12,color:"#16A34A",fontWeight:600,marginTop:6 }}>✓ 15% de descuento aplicado</div>}
            {promoErr&&<div style={{ fontSize:12,color:"#FF4D4D",fontWeight:600,marginTop:6 }}>✗ Código inválido o no disponible</div>}
          </div>
          <div style={{ background:"#fff",borderRadius:20,padding:"16px 18px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
            {[{label:"Subtotal",value:`$${subtotal}`},...(discount?[{label:"Descuento (15%)",value:`-$${discount}`,color:"#16A34A"}]:[]),{label:"Envío",value:isFreeShip?"GRATIS":`$${deliveryBase}`,color:isFreeShip?"#16A34A":undefined}].map((row,i)=>(
              <div key={i} style={{ display:"flex",justifyContent:"space-between",padding:"6px 0" }}>
                <span style={{ fontSize:14,color:"#6B7280" }}>{row.label}</span>
                <span style={{ fontSize:14,fontWeight:700,color:row.color||"#111" }}>{row.value}</span>
              </div>
            ))}
            <div style={{ display:"flex",justifyContent:"space-between",paddingTop:12,marginTop:6,borderTop:"2px solid #F3F4F6" }}>
              <span style={{ fontSize:16,fontWeight:900 }}>Total</span><span style={{ fontSize:16,fontWeight:900,color:"#FF4D4D" }}>${total}</span>
            </div>
          </div>
        </>}

        {step==="address"&&(
          showAddrMgr?(
            <AddressManager onBack={()=>setShowAddrMgr(false)} selectedId={selAddr}
              onSelect={addr=>{ setSelAddr(addr.id); setAddresses(loadAddresses()); setShowAddrMgr(false); }}/>
          ):(
            <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
              {addresses.length===0?(
                <div style={{ background:"#fff",borderRadius:20,padding:"30px 18px",textAlign:"center" }}>
                  <div style={{ fontSize:40,marginBottom:10 }}>📍</div>
                  <div style={{ fontSize:15,fontWeight:700,color:"#111",marginBottom:6 }}>Sin direcciones guardadas</div>
                  <button onClick={()=>setShowAddrMgr(true)} style={{ background:"#FF4D4D",color:"#fff",border:"none",borderRadius:12,padding:"11px 20px",fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"inherit",marginTop:8 }}>＋ Agregar dirección</button>
                </div>
              ):addresses.map(addr=>(
                <div key={addr.id} onClick={()=>setSelAddr(addr.id)}
                  style={{ background:"#fff",borderRadius:18,padding:"16px 18px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)",cursor:"pointer",border:`2px solid ${selAddr===addr.id?"#FF4D4D":"transparent"}` }}>
                  <div style={{ display:"flex",alignItems:"flex-start",gap:12 }}>
                    <div style={{ width:44,height:44,borderRadius:14,background:selAddr===addr.id?"#FF4D4D":"#FFF5F5",display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,flexShrink:0 }}>{addr.icon}</div>
                    <div style={{ flex:1 }}>
                      <div style={{ fontSize:14,fontWeight:800,color:"#111" }}>{addr.label}</div>
                      <div style={{ fontSize:12,color:"#6B7280",marginTop:2,lineHeight:1.5 }}>{addr.street} #{addr.number}, {addr.colonia}, CP {addr.cp}</div>
                    </div>
                    <div style={{ width:22,height:22,borderRadius:99,border:`2px solid ${selAddr===addr.id?"#FF4D4D":"#D1D5DB"}`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0 }}>
                      {selAddr===addr.id&&<div style={{ width:12,height:12,borderRadius:99,background:"#FF4D4D" }}/>}
                    </div>
                  </div>
                </div>
              ))}
              <button onClick={()=>setShowAddrMgr(true)} style={{ width:"100%",padding:"13px",background:"#F9FAFB",border:"2px dashed #E5E7EB",borderRadius:16,fontSize:14,fontWeight:700,color:"#9CA3AF",cursor:"pointer",fontFamily:"inherit" }}>＋ Agregar nueva dirección</button>
            </div>
          )
        )}

        {step==="payment"&&(
          showPayMgr?(
            <PaymentManager onBack={()=>setShowPayMgr(false)} selectedId={selPay} onSelect={pay=>{ setSelPay(pay.id); setShowPayMgr(false); }}/>
          ):(
            <div style={{ display:"flex",flexDirection:"column",gap:10 }}>
              {payments.map(pay=>(
                <div key={pay.id} onClick={()=>setSelPay(pay.id)}
                  style={{ background:"#fff",borderRadius:18,padding:"16px 18px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)",cursor:"pointer",border:`2px solid ${selPay===pay.id?"#FF4D4D":"transparent"}` }}>
                  <div style={{ display:"flex",alignItems:"center",gap:14 }}>
                    <div style={{ width:44,height:44,borderRadius:14,background:selPay===pay.id?"#FF4D4D":"#FFF5F5",display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,flexShrink:0 }}>{pay.icon}</div>
                    <div style={{ flex:1 }}><div style={{ fontSize:14,fontWeight:700,color:"#111" }}>{pay.label}</div><div style={{ fontSize:12,color:"#9CA3AF",marginTop:2 }}>{pay.sub}</div></div>
                    <div style={{ width:22,height:22,borderRadius:99,border:`2px solid ${selPay===pay.id?"#FF4D4D":"#D1D5DB"}`,display:"flex",alignItems:"center",justifyContent:"center" }}>
                      {selPay===pay.id&&<div style={{ width:12,height:12,borderRadius:99,background:"#FF4D4D" }}/>}
                    </div>
                  </div>
                </div>
              ))}
              <button onClick={()=>setShowPayMgr(true)} style={{ width:"100%",padding:"13px",background:"#F9FAFB",border:"2px dashed #E5E7EB",borderRadius:16,fontSize:14,fontWeight:700,color:"#9CA3AF",cursor:"pointer",fontFamily:"inherit" }}>＋ Agregar tarjeta</button>
            </div>
          )
        )}

        {step==="confirm"&&<>
          <div style={{ background:"#fff",borderRadius:20,padding:18,boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
            <div style={{ fontSize:13,fontWeight:800,marginBottom:10 }}>🍽️ Restaurante</div>
            <div style={{ display:"flex",gap:10,alignItems:"center" }}>
              <span style={{ fontSize:30 }}>{restaurant.emoji}</span>
              <div><div style={{ fontSize:15,fontWeight:700 }}>{restaurant.name}</div><div style={{ fontSize:12,color:"#9CA3AF" }}>⭐ {restaurant.rating} · 20–35 min</div></div>
            </div>
          </div>
          <div style={{ background:"#fff",borderRadius:20,padding:18,boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
            <div style={{ fontSize:13,fontWeight:800,marginBottom:10 }}>📦 Productos</div>
            {cart.map(item=>(
              <div key={item.id} style={{ display:"flex",justifyContent:"space-between",padding:"6px 0" }}>
                <span style={{ fontSize:14,color:"#374151" }}>{item.name} x{item.qty}</span>
                <span style={{ fontSize:14,fontWeight:600 }}>${item.price*item.qty}</span>
              </div>
            ))}
          </div>
          <div style={{ background:"#fff",borderRadius:20,padding:18,boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
            {[{label:"Subtotal",value:`$${subtotal}`},...(discount?[{label:"Descuento",value:`-$${discount}`,color:"#16A34A"}]:[]),{label:"Envío",value:isFreeShip?"GRATIS":`$${deliveryBase}`,color:isFreeShip?"#16A34A":undefined}].map((row,i)=>(
              <div key={i} style={{ display:"flex",justifyContent:"space-between",padding:"5px 0" }}>
                <span style={{ fontSize:14,color:"#6B7280" }}>{row.label}</span>
                <span style={{ fontSize:14,fontWeight:600,color:row.color||"#111" }}>{row.value}</span>
              </div>
            ))}
            <div style={{ display:"flex",justifyContent:"space-between",paddingTop:12,marginTop:6,borderTop:"2px solid #F3F4F6" }}>
              <span style={{ fontSize:16,fontWeight:900 }}>Total</span><span style={{ fontSize:16,fontWeight:900,color:"#FF4D4D" }}>${total}</span>
            </div>
          </div>
        </>}
      </div>

      <div style={{ position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:430,background:"#fff",borderTop:"1px solid #F3F4F6",padding:"14px 24px 28px",zIndex:10 }}>
        <button onClick={()=>{ if(step==="confirm") placeOrder(); else if(step==="menu") setStep("cart"); else setStep(STEPS[si+1]); }}
          disabled={cartCount===0||placing||(step==="address"&&!selAddr&&!showAddrMgr)}
          style={{ width:"100%",padding:"16px",background:cartCount===0?"#E5E7EB":"#FF4D4D",color:cartCount===0?"#9CA3AF":"#fff",border:"none",borderRadius:16,fontSize:15,fontWeight:700,cursor:cartCount===0?"not-allowed":"pointer",display:"flex",alignItems:"center",justifyContent:"space-between",fontFamily:"inherit" }}>
          <span style={{ opacity:0 }}>-</span>
          <span>{placing?"Procesando...":step==="menu"?"Ver carrito":step==="cart"?"Continuar":step==="address"?"Elegir pago":step==="payment"?"Revisar pedido":`Pagar $${total}`}</span>
          <span style={{ background:"rgba(255,255,255,0.2)",borderRadius:8,padding:"2px 10px",fontSize:14 }}>{step==="menu"&&cartCount>0?`${cartCount} · $${subtotal}`:step==="confirm"?"✓":"→"}</span>
        </button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────
// ORDER PLACED SCREEN
// ─────────────────────────────────────────
function OrderPlacedScreen({ orderNumber, restaurant, onTrack }) {
  return (
    <div style={{ background:"#F9FAFB",minHeight:"100vh",maxWidth:430,margin:"0 auto",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"40px 32px",textAlign:"center" }}>
      <div style={{ fontSize:80,marginBottom:24,animation:"bounce 0.6s ease" }}>🎉</div>
      <div style={{ fontSize:26,fontWeight:900,color:"#111",marginBottom:8 }}>¡Pedido realizado!</div>
      <div style={{ fontSize:15,color:"#9CA3AF",marginBottom:32,lineHeight:1.6 }}>Tu pedido está confirmado.<br/>El restaurante comenzará a prepararlo.</div>
      <div style={{ background:"#fff",borderRadius:20,padding:"20px 24px",width:"100%",boxShadow:"0 1px 8px rgba(0,0,0,0.06)",marginBottom:24 }}>
        {[{label:"Pedido",value:`#${orderNumber}`},{label:"Restaurante",value:restaurant?.name},{label:"Tiempo estimado",value:"25–35 min"}].map((row,i,arr)=>(
          <div key={i} style={{ display:"flex",justifyContent:"space-between",padding:"10px 0",borderBottom:i<arr.length-1?"1px solid #F3F4F6":"none" }}>
            <span style={{ fontSize:14,color:"#9CA3AF" }}>{row.label}</span>
            <span style={{ fontSize:14,fontWeight:700,color:"#111" }}>{row.value}</span>
          </div>
        ))}
      </div>
      <button onClick={onTrack} style={{ width:"100%",padding:"16px",background:"#FF4D4D",color:"#fff",border:"none",borderRadius:16,fontSize:15,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>Seguir pedido 🛵</button>
    </div>
  );
}

// ─────────────────────────────────────────
// TRACKING SCREEN
// ─────────────────────────────────────────
function TrackingScreen({ orderNumber, restaurant, onBack }) {
  const [progress, setProgress] = useState(55);
  const [currentStep]           = useState(3);
  const [pulse, setPulse]       = useState(false);
  const TRACK_STEPS = [
    { id:1, label:"Pedido confirmado", sub:"Tu pedido fue recibido",       icon:"✅", time:"Ahora" },
    { id:2, label:"En preparación",    sub:"El restaurante está cocinando", icon:"👨‍🍳", time:"+2 min" },
    { id:3, label:"En camino",         sub:"Tu repartidor está en ruta",    icon:"🛵", time:"+8 min" },
    { id:4, label:"Entregado",         sub:"¡Buen provecho!",               icon:"🎉", time:"" },
  ];
  useEffect(()=>{ const t=setInterval(()=>{ setProgress(p=>p>=95?95:p+0.4); setPulse(p=>!p); },800); return()=>clearInterval(t); },[]);
  return (
    <div style={{ background:"#F9FAFB",minHeight:"100vh",paddingBottom:100 }}>
      <div style={{ background:"#fff",padding:"14px 24px 18px",borderBottom:"1px solid #F3F4F6" }}>
        <div style={{ display:"flex",alignItems:"center",gap:12 }}>
          <div onClick={onBack} style={{ width:38,height:38,borderRadius:12,background:"#F9FAFB",border:"1.5px solid #F3F4F6",fontSize:18,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center" }}>←</div>
          <div style={{ flex:1 }}><div style={{ fontSize:17,fontWeight:800,color:"#111" }}>Seguimiento</div><div style={{ fontSize:12,color:"#9CA3AF" }}>Pedido #{orderNumber} · {restaurant?.name}</div></div>
          <div style={{ background:"#FFF5F5",color:"#FF4D4D",fontSize:12,fontWeight:700,padding:"5px 12px",borderRadius:99 }}>En camino</div>
        </div>
      </div>
      <div style={{ background:"#F0F4FF",height:200,margin:"16px 24px",borderRadius:20,position:"relative",overflow:"hidden" }}>
        <svg style={{ position:"absolute",inset:0 }} width="100%" height="100%">
          <path d="M 60 160 Q 130 80 210 100 Q 290 120 350 40" stroke="#E5E7EB" strokeWidth="3" strokeDasharray="6 4" fill="none" strokeLinecap="round"/>
          <path d="M 60 160 Q 130 80 210 100 Q 290 120 350 40" stroke="#FF4D4D" strokeWidth="3" fill="none" strokeLinecap="round" strokeDasharray={`${progress*3.2} 999`}/>
        </svg>
        <div style={{ position:"absolute",right:38,top:24 }}>
          <div style={{ width:34,height:34,borderRadius:99,background:"#111",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16 }}>🏠</div>
        </div>
        <div style={{ position:"absolute",left:36,bottom:24 }}>
          <div style={{ width:30,height:30,borderRadius:99,background:"#FF4D4D",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16 }}>{restaurant?.emoji||"🍽️"}</div>
        </div>
        <div style={{ position:"absolute",left:`${28+progress*0.52}%`,top:`${62-Math.sin(progress*0.05)*18}%`,transform:"translate(-50%,-50%)",transition:"all 0.8s ease" }}>
          <div style={{ width:36,height:36,borderRadius:99,background:"#FF4D4D",display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,boxShadow:"0 0 0 4px rgba(255,77,77,0.2)" }}>🛵</div>
        </div>
        <div style={{ position:"absolute",top:12,left:12,background:"#fff",borderRadius:10,padding:"6px 12px",display:"flex",alignItems:"center",gap:6,boxShadow:"0 2px 10px rgba(0,0,0,0.1)" }}>
          <span style={{ fontSize:14 }}>🕐</span><span style={{ fontSize:13,fontWeight:700,color:"#111" }}>~8 min</span>
        </div>
      </div>
      <div style={{ padding:"0 24px",display:"flex",flexDirection:"column",gap:14 }}>
        <div style={{ background:"#fff",borderRadius:20,padding:"16px 18px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)",display:"flex",alignItems:"center",gap:14 }}>
          <div style={{ position:"relative" }}>
            <div style={{ width:52,height:52,borderRadius:99,background:"linear-gradient(135deg,#FF4D4D,#FF6B6B)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:26 }}>👨‍🦱</div>
            <div style={{ position:"absolute",bottom:0,right:0,width:14,height:14,borderRadius:99,background:"#16A34A",border:"2px solid #fff" }}/>
          </div>
          <div style={{ flex:1 }}><div style={{ fontSize:15,fontWeight:800,color:"#111" }}>Carlos Mendoza</div><div style={{ fontSize:12,color:"#9CA3AF",marginTop:2 }}>⭐ 4.9 · Honda CB125 · MXZ-4821</div></div>
          <div style={{ display:"flex",gap:8 }}>
            <div style={{ width:44,height:44,borderRadius:14,background:"#F9FAFB",border:"1.5px solid #F3F4F6",display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,cursor:"pointer" }}>💬</div>
            <div style={{ width:44,height:44,borderRadius:14,background:"#FF4D4D",display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,cursor:"pointer" }}>📞</div>
          </div>
        </div>
        <div style={{ background:"#fff",borderRadius:20,padding:"6px 18px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
          {TRACK_STEPS.map((ts,i)=>{
            const done=ts.id<currentStep, active=ts.id===currentStep, pending=ts.id>currentStep;
            return (
              <div key={ts.id} style={{ display:"flex",gap:14,padding:"14px 0",position:"relative" }}>
                {i<TRACK_STEPS.length-1&&<div style={{ position:"absolute",left:19,top:46,bottom:-14,width:2,background:done?"#FF4D4D":"#F3F4F6",zIndex:0 }}/>}
                <div style={{ width:40,height:40,borderRadius:99,flexShrink:0,background:done?"#FF4D4D":active?"#FF4D4D":"#F9FAFB",border:`2px solid ${done||active?"#FF4D4D":"#F3F4F6"}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,zIndex:1,transition:"all 0.3s",transform:active?"scale(1.1)":"scale(1)" }}>
                  {done?<span style={{ fontSize:16,color:"#fff" }}>✓</span>:ts.icon}
                </div>
                <div style={{ flex:1,paddingTop:8 }}>
                  <div style={{ fontSize:14,fontWeight:active?800:done?600:500,color:pending?"#D1D5DB":"#111" }}>{ts.label}</div>
                  <div style={{ fontSize:12,color:pending?"#E5E7EB":"#9CA3AF",marginTop:2 }}>{ts.sub}</div>
                </div>
                {ts.time&&<div style={{ fontSize:12,fontWeight:600,color:pending?"#E5E7EB":"#9CA3AF",paddingTop:10 }}>{ts.time}</div>}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────
// ORDERS SCREEN
// ─────────────────────────────────────────
function OrdersScreen({ onTrack }) {
  const [orders, setOrders]   = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(()=>{ sbGet("orders","order=created_at.desc&limit=20").then(d=>{ setOrders(Array.isArray(d)?d:[]); setLoading(false); }).catch(()=>setLoading(false)); },[]);
  const statusColor = { pending:"#F59E0B",confirmed:"#6366F1",delivering:"#2563EB",delivered:"#16A34A",cancelled:"#EF4444" };
  const statusLabel = { pending:"Pendiente",confirmed:"Confirmado",delivering:"En camino",delivered:"Entregado",cancelled:"Cancelado" };
  return (
    <div style={{ paddingBottom:100 }}>
      <div style={{ background:"#fff",padding:"14px 24px 18px",borderBottom:"1px solid #F3F4F6" }}>
        <div style={{ fontSize:13,color:"#9CA3AF",fontWeight:500 }}>Historial</div>
        <div style={{ fontSize:20,fontWeight:900,color:"#111" }}>Mis Pedidos</div>
      </div>
      <div style={{ padding:"16px 24px",display:"flex",flexDirection:"column",gap:12 }}>
        {loading?[1,2,3].map(i=>(
          <div key={i} style={{ background:"#fff",borderRadius:18,padding:"16px",boxShadow:"0 1px 8px rgba(0,0,0,0.05)",display:"flex",flexDirection:"column",gap:8 }}>
            <Skeleton h={14} w="60%"/><Skeleton h={10} w="40%"/>
          </div>
        )):orders.length===0?(
          <div style={{ textAlign:"center",padding:"60px 0",color:"#9CA3AF" }}>
            <div style={{ fontSize:48 }}>📋</div>
            <div style={{ fontSize:15,fontWeight:700,color:"#374151",marginTop:10 }}>Sin pedidos aún</div>
          </div>
        ):orders.map(order=>(
          <div key={order.id} style={{ background:"#fff",borderRadius:18,padding:"16px",boxShadow:"0 1px 8px rgba(0,0,0,0.05)",cursor:"pointer" }} onClick={()=>onTrack(order.id,order.restaurant_name)}>
            <div style={{ display:"flex",justifyContent:"space-between",marginBottom:8 }}>
              <div style={{ fontSize:15,fontWeight:800,color:"#111" }}>{order.restaurant_name}</div>
              <div style={{ background:`${statusColor[order.status]||"#6B7280"}18`,color:statusColor[order.status]||"#6B7280",fontSize:11,fontWeight:700,padding:"3px 10px",borderRadius:99 }}>{statusLabel[order.status]||order.status}</div>
            </div>
            <div style={{ fontSize:12,color:"#9CA3AF",marginBottom:6 }}>{Array.isArray(order.items)?order.items.map(i=>`${i.name} x${i.qty}`).join(", "):"—"}</div>
            <div style={{ display:"flex",justifyContent:"space-between" }}>
              <span style={{ fontSize:12,color:"#D1D5DB" }}>#{order.id}</span>
              <span style={{ fontSize:14,fontWeight:800,color:"#FF4D4D" }}>${order.total}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────
// DRIVER SCREEN
// ─────────────────────────────────────────
function DriverScreen() {
  const [online, setOnline]     = useState(true);
  const [pulse, setPulse]       = useState(false);
  const [orders, setOrders]     = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading]   = useState(true);
  const [earnings, setEarnings] = useState(0);
  useEffect(()=>{
    const t=setInterval(()=>setPulse(p=>!p),900);
    sbGet("orders","status=in.(pending,confirmed,delivering)&order=created_at.desc").then(d=>{
      const data=Array.isArray(d)?d:[];
      setOrders(data); setEarnings(data.filter(o=>o.status==="delivered").reduce((s,o)=>s+(o.delivery_fee||0),0)); setLoading(false);
    });
    return()=>clearInterval(t);
  },[]);
  const updateStatus = async (order,newStatus) => {
    await sbPatch("orders",order.id,{status:newStatus});
    setOrders(p=>p.map(o=>o.id===order.id?{...o,status:newStatus}:o));
    if(newStatus==="delivered"){ setEarnings(e=>e+(order.delivery_fee||0)); setSelected(null); }
  };
  const statusColor = { pending:"#F59E0B",confirmed:"#6366F1",delivering:"#2563EB" };
  const statusLabel = { pending:"Pendiente",confirmed:"Confirmado",delivering:"En camino" };
  return (
    <div style={{ paddingBottom:100 }}>
      <div style={{ background:"#fff",padding:"14px 24px 18px",borderBottom:"1px solid #F3F4F6" }}>
        {selected?(
          <div style={{ display:"flex",alignItems:"center",gap:12 }}>
            <div onClick={()=>setSelected(null)} style={{ width:38,height:38,borderRadius:12,background:"#F9FAFB",border:"1.5px solid #F3F4F6",fontSize:18,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center" }}>←</div>
            <div style={{ flex:1 }}><div style={{ fontSize:16,fontWeight:800 }}>Pedido #{selected.id}</div><div style={{ fontSize:12,color:"#9CA3AF" }}>{selected.restaurant_name}</div></div>
          </div>
        ):(
          <>
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16 }}>
              <div><div style={{ fontSize:13,color:"#9CA3AF",fontWeight:500 }}>Bienvenido 👋</div><div style={{ fontSize:20,fontWeight:900,color:"#111" }}>Carlos Mendoza</div></div>
              <div onClick={()=>setOnline(o=>!o)} style={{ display:"flex",alignItems:"center",gap:8,background:online?"#F0FDF4":"#F9FAFB",border:`1.5px solid ${online?"#16A34A":"#E5E7EB"}`,borderRadius:99,padding:"6px 14px",cursor:"pointer" }}>
                <div style={{ width:8,height:8,borderRadius:99,background:online?"#16A34A":"#D1D5DB",boxShadow:online&&pulse?"0 0 0 3px rgba(22,163,74,0.3)":"none" }}/>
                <span style={{ fontSize:13,fontWeight:700,color:online?"#16A34A":"#9CA3AF" }}>{online?"En línea":"Desconectado"}</span>
              </div>
            </div>
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8 }}>
              {[{icon:"📦",label:"Activos",value:orders.length},{icon:"💰",label:"Ganancias",value:`$${earnings}`},{icon:"⭐",label:"Rating",value:"4.9"}].map((s,i)=>(
                <div key={i} style={{ background:"#F9FAFB",borderRadius:14,padding:"10px 8px",textAlign:"center",border:"1.5px solid #F3F4F6" }}>
                  <div style={{ fontSize:18 }}>{s.icon}</div><div style={{ fontSize:15,fontWeight:900,color:"#111" }}>{s.value}</div><div style={{ fontSize:10,color:"#9CA3AF",marginTop:2 }}>{s.label}</div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
      <div style={{ padding:"16px 24px",display:"flex",flexDirection:"column",gap:12 }}>
        {selected?(
          <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
            <div style={{ background:"#fff",borderRadius:20,padding:18,boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
              {[{icon:"🏪",label:"Restaurante",value:selected.restaurant_name},{icon:"📍",label:"Entregar en",value:selected.delivery_address},{icon:"💳",label:"Pago",value:selected.payment_method},{icon:"💰",label:"Ganancia",value:`$${selected.delivery_fee||25}`}].map((row,i)=>(
                <div key={i} style={{ display:"flex",gap:10,padding:"8px 0",borderBottom:i<3?"1px solid #F9FAFB":"none" }}>
                  <span style={{ fontSize:18 }}>{row.icon}</span>
                  <div><div style={{ fontSize:11,color:"#9CA3AF",fontWeight:600 }}>{row.label}</div><div style={{ fontSize:14,fontWeight:600,color:"#111",marginTop:2 }}>{row.value}</div></div>
                </div>
              ))}
            </div>
            <div style={{ position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:430,background:"#fff",borderTop:"1px solid #F3F4F6",padding:"14px 24px 28px",zIndex:10 }}>
              {selected.status==="pending"&&<button onClick={()=>updateStatus(selected,"delivering")} style={{ width:"100%",padding:"16px",background:"#6366F1",color:"#fff",border:"none",borderRadius:16,fontSize:15,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>Recoger pedido 📦</button>}
              {selected.status==="delivering"&&<button onClick={()=>updateStatus(selected,"delivered")} style={{ width:"100%",padding:"16px",background:"#16A34A",color:"#fff",border:"none",borderRadius:16,fontSize:15,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>Confirmar entrega ✅</button>}
            </div>
          </div>
        ):loading?[1,2].map(i=>(<div key={i} style={{ background:"#fff",borderRadius:18,padding:"16px",boxShadow:"0 1px 8px rgba(0,0,0,0.05)",display:"flex",flexDirection:"column",gap:8 }}><Skeleton h={14} w="60%"/><Skeleton h={10} w="80%"/></div>))
        :orders.length===0?(
          <div style={{ textAlign:"center",padding:"60px 0",color:"#9CA3AF" }}><div style={{ fontSize:48 }}>🛵</div><div style={{ fontSize:15,fontWeight:700,color:"#374151",marginTop:10 }}>{online?"Sin pedidos activos":"Estás desconectado"}</div></div>
        ):orders.map(order=>(
          <div key={order.id} onClick={()=>setSelected(order)} style={{ background:"#fff",borderRadius:18,padding:"16px",boxShadow:"0 1px 8px rgba(0,0,0,0.05)",cursor:"pointer" }}>
            <div style={{ display:"flex",justifyContent:"space-between",marginBottom:8 }}>
              <div style={{ fontSize:15,fontWeight:800 }}>{order.restaurant_name}</div>
              <div style={{ background:`${statusColor[order.status]||"#6B7280"}18`,color:statusColor[order.status]||"#6B7280",fontSize:11,fontWeight:700,padding:"3px 10px",borderRadius:99 }}>{statusLabel[order.status]||order.status}</div>
            </div>
            <div style={{ fontSize:12,color:"#9CA3AF",marginBottom:6 }}>{order.delivery_address}</div>
            <div style={{ display:"flex",justifyContent:"space-between" }}>
              <span style={{ fontSize:12,color:"#D1D5DB" }}>#{order.id}</span>
              <span style={{ fontSize:13,fontWeight:800,color:"#16A34A" }}>+${order.delivery_fee||25}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────
// MINI BAR CHART (pure CSS — no lib needed)
// ─────────────────────────────────────────
function MiniBar({ data, color="#6366F1", height=60 }) {
  const max = Math.max(...data.map(d=>d.v), 1);
  return (
    <div style={{ display:"flex", alignItems:"flex-end", gap:4, height }}>
      {data.map((d,i)=>(
        <div key={i} style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", gap:3 }}>
          <div style={{ width:"100%", background:`${color}22`, borderRadius:4, height:height-16, display:"flex", alignItems:"flex-end" }}>
            <div style={{ width:"100%", background:color, borderRadius:4, height:`${(d.v/max)*100}%`, transition:"height 0.6s ease", minHeight:d.v>0?3:0 }}/>
          </div>
          <span style={{ fontSize:8, color:"#9CA3AF", whiteSpace:"nowrap" }}>{d.l}</span>
        </div>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────
// ADMIN SCREEN — 4 tabs
// ─────────────────────────────────────────
function AdminScreen({ restaurants, menuItems, setRestaurants, setMenuItems, showToast }) {
  // ── Nav tab (top-level) ──
  const [adminTab, setAdminTab] = useState("restaurantes"); // restaurantes | pedidos | estadisticas | config

  // ── Restaurantes sub-state ──
  const [view, setView]         = useState("list");
  const [activeRest, setActiveRest] = useState(null);
  const [modal, setModal]       = useState(null);
  const [editTarget, setEditTarget] = useState(null);
  const [search, setSearch]     = useState("");
  const [restTab, setRestTab]   = useState("restaurantes"); // restaurantes | repartidores within the panel
  const [detailTab, setDetailTab] = useState("menu");

  const restItems = activeRest ? menuItems.filter(i=>i.restaurant_id===activeRest.id) : [];
  const grouped   = restItems.reduce((a,i)=>{ (a[i.category]=a[i.category]||[]).push(i); return a; },{});
  const filtered  = restaurants.filter(r=>r.name?.toLowerCase().includes(search.toLowerCase())||r.cuisine?.toLowerCase().includes(search.toLowerCase()));

  // ── Pedidos state ──
  const [orders, setOrders]       = useState([]);
  const [ordersLoading, setOrdersLoading] = useState(false);
  const [orderSearch, setOrderSearch] = useState("");
  const [orderFilter, setOrderFilter] = useState("all"); // all | pending | delivering | delivered | cancelled
  const [selectedOrder, setSelectedOrder] = useState(null);

  // ── Config state ──
  const [cfgForm, setCfgForm] = useState(()=>{
    try { return JSON.parse(localStorage.getItem("yg_config")||"null")||{ appName:"YummiGoApp", city:"Aguascalientes", deliveryBase:25, deliveryMax:55, minOrder:0, commissionPct:15, openTime:"08:00", closeTime:"23:00", maintenanceMode:false, allowNewOrders:true, showRatings:true }; } catch { return { appName:"YummiGoApp", city:"Aguascalientes", deliveryBase:25, deliveryMax:55, minOrder:0, commissionPct:15, openTime:"08:00", closeTime:"23:00", maintenanceMode:false, allowNewOrders:true, showRatings:true }; }
  });
  const saveCfg = () => { localStorage.setItem("yg_config", JSON.stringify(cfgForm)); showToast("Configuración guardada ✓"); };
  const setCF = k => v => setCfgForm(f=>({...f,[k]:v}));

  // ── Load orders when tab changes ──
  useEffect(()=>{
    if(adminTab==="pedidos"||adminTab==="estadisticas"||adminTab==="clientes") {
      setOrdersLoading(true);
      sbGet("orders","order=created_at.desc&limit=100").then(d=>{ setOrders(Array.isArray(d)?d:[]); setOrdersLoading(false); });
    }
  },[adminTab]);

  // ── Stats computed ──
  const totalRevenue   = orders.filter(o=>o.status==="delivered").reduce((s,o)=>s+(o.total||0),0);
  const totalDelivered = orders.filter(o=>o.status==="delivered").length;
  const totalPending   = orders.filter(o=>["pending","confirmed","delivering"].includes(o.status)).length;
  const avgOrder       = totalDelivered>0 ? Math.round(totalRevenue/totalDelivered) : 0;
  const cancelledCount = orders.filter(o=>o.status==="cancelled").length;

  // Revenue by restaurant
  const revenueByRest = restaurants.map(r=>({
    name: r.name, emoji: r.emoji,
    revenue: orders.filter(o=>o.status==="delivered"&&o.restaurant_name===r.name).reduce((s,o)=>s+(o.total||0),0),
    orders:  orders.filter(o=>o.restaurant_name===r.name).length,
  })).sort((a,b)=>b.revenue-a.revenue);

  // Orders by day (last 7)
  const last7 = Array.from({length:7},(_,i)=>{ const d=new Date(); d.setDate(d.getDate()-6+i); return d; });
  const ordersByDay = last7.map(d=>({
    l: d.toLocaleDateString("es-MX",{weekday:"short"}),
    v: orders.filter(o=>{ const od=new Date(o.created_at); return od.toDateString()===d.toDateString(); }).length,
  }));
  const revenueByDay = last7.map(d=>({
    l: d.toLocaleDateString("es-MX",{weekday:"short"}),
    v: orders.filter(o=>o.status==="delivered"&&new Date(o.created_at).toDateString()===d.toDateString()).reduce((s,o)=>s+(o.total||0),0),
  }));

  // Status distribution
  const statusDist = [
    { label:"Entregados", count:totalDelivered, color:"#16A34A" },
    { label:"Activos",    count:totalPending,   color:"#6366F1" },
    { label:"Cancelados", count:cancelledCount,  color:"#FF4D4D" },
  ];

  const addRestaurant    = async f => { const res=await sbPost("restaurants",f); if(res?.[0]){setRestaurants(p=>[...p,res[0]]);showToast("Restaurante agregado ✓");}else showToast("Error","error"); };
  const updateRestaurant = async f => { const res=await sbPatch("restaurants",activeRest.id,f); if(res?.[0]){setRestaurants(p=>p.map(r=>r.id===activeRest.id?res[0]:r));setActiveRest(res[0]);showToast("Guardado ✓");}else showToast("Error","error"); };
  const deleteRestaurant = async id => { await sbDel("restaurants",id); setRestaurants(p=>p.filter(r=>r.id!==id)); setMenuItems(p=>p.filter(i=>i.restaurant_id!==id)); setView("list"); setActiveRest(null); showToast("Eliminado"); };
  const toggleRest       = async r  => { const res=await sbPatch("restaurants",r.id,{active:!r.active}); if(res?.[0]){setRestaurants(p=>p.map(x=>x.id===r.id?res[0]:x));if(activeRest?.id===r.id)setActiveRest(res[0]);} };
  const addItem          = async f  => { const res=await sbPost("menu_items",{...f,restaurant_id:activeRest.id}); if(res?.[0]){setMenuItems(p=>[...p,res[0]]);showToast("Platillo agregado ✓");}else showToast("Error","error"); };
  const updateItem       = async f  => { const res=await sbPatch("menu_items",editTarget.id,f); if(res?.[0]){setMenuItems(p=>p.map(i=>i.id===editTarget.id?res[0]:i));showToast("Guardado ✓");}else showToast("Error","error"); };
  const deleteItem       = async id => { await sbDel("menu_items",id); setMenuItems(p=>p.filter(i=>i.id!==id)); showToast("Platillo eliminado"); };
  const toggleItem       = async item=> { const res=await sbPatch("menu_items",item.id,{available:!item.available}); if(res?.[0])setMenuItems(p=>p.map(i=>i.id===item.id?res[0]:i)); };
  const totalItems = restaurants.reduce((s,r)=>s+menuItems.filter(i=>i.restaurant_id===r.id).length,0);

  // ── Drivers ──
  const [drivers, setDrivers]         = useState(loadDrivers);
  const [driverModal, setDriverModal] = useState(false);
  const [editDriver, setEditDriver]   = useState(null);
  const [driverForm, setDriverForm]   = useState({ name:"", user:"", pass:"", phone:"", vehicle:"", plate:"", active:true });
  const [driverFormErr, setDriverFormErr] = useState({});
  const setDF = k => v => setDriverForm(f=>({...f,[k]:v}));
  const openAddDriver  = () => { setEditDriver(null); setDriverForm({name:"",user:"",pass:"",phone:"",vehicle:"",plate:"",active:true}); setDriverFormErr({}); setDriverModal(true); };
  const openEditDriver = (d) => { setEditDriver(d); setDriverForm({name:d.name,user:d.user,pass:d.pass,phone:d.phone||"",vehicle:d.vehicle||"",plate:d.plate||"",active:d.active}); setDriverFormErr({}); setDriverModal(true); };
  const validateDriver = () => { const e={}; if(!driverForm.name.trim())e.name="Requerido"; if(!driverForm.user.includes("@"))e.user="Correo inválido"; if(driverForm.pass.length<6)e.pass="Mínimo 6 caracteres"; setDriverFormErr(e); return Object.keys(e).length===0; };
  const saveDriver  = () => { if(!validateDriver())return; const u=editDriver?drivers.map(d=>d.id===editDriver.id?{...d,...driverForm}:d):[...drivers,{id:Date.now(),...driverForm,createdAt:new Date().toISOString().split("T")[0]}]; saveDrivers(u); setDrivers(u); setDriverModal(false); setEditDriver(null); showToast(editDriver?"Repartidor actualizado ✓":"Repartidor agregado ✓"); };
  const deleteDriver= (id) => { const u=drivers.filter(d=>d.id!==id); saveDrivers(u); setDrivers(u); showToast("Repartidor eliminado"); };
  const toggleDriver= (d)  => { const u=drivers.map(x=>x.id===d.id?{...x,active:!x.active}:x); saveDrivers(u); setDrivers(u); };

  // ── Restaurant Accounts ──
  const [restAccounts, setRestAccounts]       = useState(()=>loadRestaurantAccounts());
  const [restAccountModal, setRestAccountModal] = useState(false);
  const [editRestAccount, setEditRestAccount]   = useState(null);
  const [restAccountForm, setRestAccountForm]   = useState({ restaurantName:"", restaurantId:"", emoji:"🍽️", user:"", pass:"", phone:"", active:true });
  const [restAccountErr, setRestAccountErr]     = useState({});
  const setRA = k => v => setRestAccountForm(f=>({...f,[k]:v}));

  const openAddRestAccount = () => {
    setEditRestAccount(null);
    setRestAccountForm({ restaurantName:"", restaurantId:"", emoji:"🍽️", user:"", pass:"", phone:"", active:true });
    setRestAccountErr({});
    setRestAccountModal(true);
  };
  const openEditRestAccount = (a) => {
    setEditRestAccount(a);
    setRestAccountForm({ restaurantName:a.restaurantName, restaurantId:a.restaurantId||"", emoji:a.emoji||"🍽️", user:a.user, pass:a.pass, phone:a.phone||"", active:a.active });
    setRestAccountErr({});
    setRestAccountModal(true);
  };
  const validateRestAccount = () => {
    const e={};
    if(!restAccountForm.restaurantName.trim()) e.restaurantName="Requerido";
    if(!restAccountForm.user.includes("@"))    e.user="Correo inválido";
    if(restAccountForm.pass.length<6)          e.pass="Mínimo 6 caracteres";
    setRestAccountErr(e); return Object.keys(e).length===0;
  };
  const saveRestAccount = () => {
    if(!validateRestAccount()) return;
    const payload = { ...restAccountForm, restaurantId: restAccountForm.restaurantId || restAccountForm.restaurantName.toLowerCase().replace(/\s+/g,"-") };
    let updated;
    if(editRestAccount) { updated=restAccounts.map(a=>a.id===editRestAccount.id?{...a,...payload}:a); showToast("Cuenta actualizada ✓"); }
    else { updated=[...restAccounts,{id:Date.now(),...payload,createdAt:new Date().toISOString().split("T")[0]}]; showToast("Cuenta de restaurante creada ✓"); }
    saveRestaurantAccounts(updated); setRestAccounts(updated); setRestAccountModal(false); setEditRestAccount(null);
  };
  const deleteRestAccount = (id) => { const u=restAccounts.filter(a=>a.id!==id); saveRestaurantAccounts(u); setRestAccounts(u); showToast("Cuenta eliminada"); };
  const toggleRestAccount = (a)  => { const u=restAccounts.map(x=>x.id===a.id?{...x,active:!x.active}:x); saveRestaurantAccounts(u); setRestAccounts(u); };

  const STATUS_COLOR = { pending:"#F59E0B",confirmed:"#6366F1",delivering:"#2563EB",delivered:"#16A34A",cancelled:"#EF4444" };
  const STATUS_LABEL = { pending:"Pendiente",confirmed:"Confirmado",delivering:"En camino",delivered:"Entregado",cancelled:"Cancelado" };
  const updateOrderStatus = async (order, ns) => { await sbPatch("orders",order.id,{status:ns}); setOrders(p=>p.map(o=>o.id===order.id?{...o,status:ns}:o)); if(selectedOrder?.id===order.id)setSelectedOrder({...order,status:ns}); showToast(`Estado: ${STATUS_LABEL[ns]}`); };
  const filteredOrders = orders.filter(o=>{ const ms=orderFilter==="all"||o.status===orderFilter; const mq=!orderSearch||o.restaurant_name?.toLowerCase().includes(orderSearch.toLowerCase())||String(o.id).includes(orderSearch); return ms&&mq; });

  const ADMIN_NAV = [{id:"restaurantes",emoji:"🏪",label:"Restaurantes"},{id:"pedidos",emoji:"📋",label:"Pedidos"},{id:"clientes",emoji:"👥",label:"Clientes"},{id:"estadisticas",emoji:"📊",label:"Stats"},{id:"config",emoji:"⚙️",label:"Config"}];

  return (
    <div style={{ paddingBottom:80 }}>
      {/* TOP HEADER */}
      <div style={{ background:"#fff",padding:"14px 24px 0",borderBottom:"1px solid #F3F4F6",position:"sticky",top:0,zIndex:90 }}>
        <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14 }}>
          <div>
            <div style={{ fontSize:12,color:"#9CA3AF",fontWeight:600,letterSpacing:0.4 }}>PANEL DE ADMIN</div>
            <div style={{ fontSize:19,fontWeight:900,color:"#111" }}>
              {adminTab==="restaurantes"?"Restaurantes":adminTab==="pedidos"?"Pedidos":adminTab==="clientes"?"Clientes":adminTab==="estadisticas"?"Estadísticas":"Configuración"}
            </div>
          </div>
          {adminTab==="restaurantes"&&view==="list"&&(
            <button onClick={restTab==="repartidores"?openAddDriver:restTab==="cuentas"?openAddRestAccount:()=>setModal("addRest")}
              style={{ background:"#F97316",color:"#fff",border:"none",borderRadius:12,padding:"9px 16px",fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>
              ＋ {restTab==="repartidores"?"Repartidor":restTab==="cuentas"?"Cuenta":"Restaurante"}
            </button>
          )}
          {adminTab==="pedidos"&&<div style={{ background:"#EEF2FF",borderRadius:10,padding:"4px 10px",fontSize:12,fontWeight:700,color:"#6366F1" }}>{totalPending} activos</div>}
        </div>
        {/* Nav tabs */}
        <div style={{ display:"flex",marginLeft:-24,marginRight:-24,paddingLeft:24,paddingRight:24,borderTop:"1px solid #F3F4F6" }}>
          {ADMIN_NAV.map(t=>(
            <div key={t.id} onClick={()=>{ setAdminTab(t.id); if(t.id==="restaurantes"){setView("list");setSearch("");} }}
              style={{ flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:3,padding:"10px 0",cursor:"pointer",borderBottom:`2.5px solid ${adminTab===t.id?"#6366F1":"transparent"}`,transition:"border 0.2s" }}>
              <span style={{ fontSize:18 }}>{t.emoji}</span>
              <span style={{ fontSize:10,fontWeight:adminTab===t.id?800:500,color:adminTab===t.id?"#6366F1":"#9CA3AF" }}>{t.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* ── TAB: RESTAURANTES ── */}
      {adminTab==="restaurantes"&&(
        <div>
          {view==="list"&&(
            <div style={{ padding:"16px 24px",display:"flex",flexDirection:"column",gap:12 }}>
              <div style={{ display:"flex",gap:8 }}>
                {[{id:"restaurantes",label:"🏪 Locales"},{id:"cuentas",label:"🔑 Cuentas"},{id:"repartidores",label:"🛵 Repartidores"}].map(t=>(
                  <button key={t.id} onClick={()=>setRestTab(t.id)} style={{ flex:1,padding:"9px 0",background:restTab===t.id?"#F97316":"#F9FAFB",color:restTab===t.id?"#fff":"#6B7280",border:`1.5px solid ${restTab===t.id?"#F97316":"#F3F4F6"}`,borderRadius:11,fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>{t.label}</button>
                ))}
              </div>
              {restTab==="restaurantes"&&<div style={{ display:"flex",gap:8 }}>
                {[{icon:"🏪",l:"Total",v:restaurants.length},{icon:"✅",l:"Activos",v:restaurants.filter(r=>r.active).length},{icon:"🍽️",l:"Platillos",v:totalItems}].map((s,i)=>(
                  <div key={i} style={{ flex:1,background:"#F9FAFB",borderRadius:12,padding:"10px 8px",textAlign:"center",border:"1.5px solid #F3F4F6" }}><div style={{ fontSize:15 }}>{s.icon}</div><div style={{ fontSize:15,fontWeight:900,color:"#111" }}>{s.v}</div><div style={{ fontSize:10,color:"#9CA3AF" }}>{s.l}</div></div>
                ))}
              </div>}
              {restTab==="cuentas"&&<div style={{ display:"flex",gap:8 }}>
                {[{icon:"🔑",l:"Cuentas",v:restAccounts.length},{icon:"🟢",l:"Activas",v:restAccounts.filter(a=>a.active).length},{icon:"🔴",l:"Inactivas",v:restAccounts.filter(a=>!a.active).length}].map((s,i)=>(
                  <div key={i} style={{ flex:1,background:"#FFF7ED",borderRadius:12,padding:"10px 8px",textAlign:"center",border:"1.5px solid #FED7AA" }}><div style={{ fontSize:15 }}>{s.icon}</div><div style={{ fontSize:15,fontWeight:900,color:"#F97316" }}>{s.v}</div><div style={{ fontSize:10,color:"#9CA3AF" }}>{s.l}</div></div>
                ))}
              </div>}
              {restTab==="repartidores"&&<div style={{ display:"flex",gap:8 }}>
                {[{icon:"🛵",l:"Total",v:drivers.length},{icon:"🟢",l:"Activos",v:drivers.filter(d=>d.active).length},{icon:"🔴",l:"Inactivos",v:drivers.filter(d=>!d.active).length}].map((s,i)=>(
                  <div key={i} style={{ flex:1,background:"#F9FAFB",borderRadius:12,padding:"10px 8px",textAlign:"center",border:"1.5px solid #F3F4F6" }}><div style={{ fontSize:15 }}>{s.icon}</div><div style={{ fontSize:15,fontWeight:900,color:"#111" }}>{s.v}</div><div style={{ fontSize:10,color:"#9CA3AF" }}>{s.l}</div></div>
                ))}
              </div>}
              <div style={{ background:"#F9FAFB",border:"1.5px solid #F3F4F6",borderRadius:12,padding:"10px 14px",display:"flex",alignItems:"center",gap:8 }}>
                <span style={{ fontSize:15,opacity:0.4 }}>🔍</span>
                <input value={search} onChange={e=>setSearch(e.target.value)} placeholder={restTab==="repartidores"?"Buscar repartidor…":"Buscar restaurante…"} style={{ border:"none",background:"transparent",fontSize:14,color:"#111",outline:"none",flex:1,fontFamily:"inherit" }}/>
              </div>
              {restTab==="restaurantes"&&filtered.map(r=>(
                <div key={r.id} onClick={()=>{setActiveRest(r);setView("detail");setDetailTab("menu");}} style={{ background:"#fff",borderRadius:20,padding:"16px 18px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)",cursor:"pointer",opacity:r.active?1:0.6 }}>
                  <div style={{ display:"flex",alignItems:"center",gap:12,marginBottom:8 }}>
                    <div style={{ width:48,height:48,borderRadius:14,background:"#F9FAFB",display:"flex",alignItems:"center",justifyContent:"center",fontSize:24 }}>{r.emoji}</div>
                    <div style={{ flex:1 }}><div style={{ fontSize:15,fontWeight:800,color:"#111" }}>{r.name}</div><div style={{ fontSize:12,color:"#9CA3AF" }}>{r.cuisine}</div></div>
                    <div style={{ background:r.active?"#F0FDF4":"#F9FAFB",color:r.active?"#16A34A":"#9CA3AF",fontSize:10,fontWeight:700,padding:"3px 10px",borderRadius:99 }}>{r.active?"Activo":"Inactivo"}</div>
                  </div>
                  <div style={{ display:"flex",gap:12,fontSize:11,color:"#9CA3AF" }}>
                    <span>⭐ {r.rating}</span><span>🍽️ {menuItems.filter(i=>i.restaurant_id===r.id).length} platillos</span><span>📦 {orders.filter(o=>o.restaurant_name===r.name).length} pedidos</span>
                  </div>
                </div>
              ))}
              {restTab==="repartidores"&&drivers.filter(d=>!search||d.name.toLowerCase().includes(search.toLowerCase())||d.user.toLowerCase().includes(search.toLowerCase())).map(d=>(
                <div key={d.id} style={{ background:"#fff",borderRadius:20,padding:"16px 18px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)",opacity:d.active?1:0.65 }}>
                  <div style={{ display:"flex",alignItems:"center",gap:12,marginBottom:10 }}>
                    <div style={{ width:46,height:46,borderRadius:99,background:"linear-gradient(135deg,#6366F1,#8B5CF6)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,flexShrink:0 }}>🛵</div>
                    <div style={{ flex:1 }}><div style={{ display:"flex",alignItems:"center",gap:7 }}><span style={{ fontSize:14,fontWeight:800,color:"#111" }}>{d.name}</span><span style={{ background:d.active?"#F0FDF4":"#FFF5F5",color:d.active?"#16A34A":"#FF4D4D",fontSize:10,fontWeight:700,padding:"2px 7px",borderRadius:99 }}>{d.active?"Activo":"Inactivo"}</span></div><div style={{ fontSize:12,color:"#9CA3AF" }}>{d.user}</div>{d.vehicle&&<div style={{ fontSize:11,color:"#9CA3AF" }}>🏍️ {d.vehicle} · {d.plate}</div>}</div>
                    <Toggle value={d.active} onChange={()=>toggleDriver(d)}/>
                  </div>
                  <div style={{ background:"#F5F3FF",borderRadius:11,padding:"9px 13px",marginBottom:9 }}>
                    <div style={{ fontSize:10,fontWeight:700,color:"#6366F1",marginBottom:5,letterSpacing:0.4 }}>🔑 CREDENCIALES</div>
                    <div style={{ display:"flex",justifyContent:"space-between",marginBottom:2 }}><span style={{ fontSize:11,color:"#6B7280" }}>Usuario</span><span style={{ fontSize:11,fontWeight:700,fontFamily:"monospace",color:"#111" }}>{d.user}</span></div>
                    <div style={{ display:"flex",justifyContent:"space-between" }}><span style={{ fontSize:11,color:"#6B7280" }}>Contraseña</span><span style={{ fontSize:11,fontWeight:700,fontFamily:"monospace",color:"#111" }}>{d.pass}</span></div>
                  </div>
                  <div style={{ display:"flex",gap:8 }}>
                    <button onClick={()=>openEditDriver(d)} style={{ flex:1,padding:"8px",background:"#F9FAFB",border:"1.5px solid #F3F4F6",borderRadius:10,fontSize:12,fontWeight:600,cursor:"pointer",color:"#374151",fontFamily:"inherit" }}>✏️ Editar</button>
                    <button onClick={()=>deleteDriver(d.id)} style={{ flex:1,padding:"8px",background:"#FFF5F5",border:"1.5px solid #FFE4E4",borderRadius:10,fontSize:12,fontWeight:600,cursor:"pointer",color:"#FF4D4D",fontFamily:"inherit" }}>🗑️ Eliminar</button>
                  </div>
                </div>
              ))}
              {restTab==="repartidores"&&drivers.length===0&&<div style={{ textAlign:"center",padding:"40px 0",color:"#9CA3AF" }}><div style={{ fontSize:44 }}>🛵</div><div style={{ fontSize:14,fontWeight:700,color:"#374151",marginTop:8 }}>Sin repartidores</div></div>}

              {/* ── RESTAURANT ACCOUNTS ── */}
              {restTab==="cuentas"&&restAccounts.filter(a=>!search||a.restaurantName.toLowerCase().includes(search.toLowerCase())||a.user.toLowerCase().includes(search.toLowerCase())).map(a=>(
                <div key={a.id} style={{ background:"#fff",borderRadius:20,padding:"16px 18px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)",opacity:a.active?1:0.65 }}>
                  <div style={{ display:"flex",alignItems:"center",gap:12,marginBottom:10 }}>
                    <div style={{ width:46,height:46,borderRadius:14,background:"linear-gradient(135deg,#F97316,#FB923C)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:24,flexShrink:0 }}>{a.emoji||"🍽️"}</div>
                    <div style={{ flex:1 }}>
                      <div style={{ display:"flex",alignItems:"center",gap:7 }}>
                        <span style={{ fontSize:14,fontWeight:800,color:"#111" }}>{a.restaurantName}</span>
                        <span style={{ background:a.active?"#F0FDF4":"#FFF5F5",color:a.active?"#16A34A":"#FF4D4D",fontSize:10,fontWeight:700,padding:"2px 7px",borderRadius:99 }}>{a.active?"Activa":"Inactiva"}</span>
                      </div>
                      <div style={{ fontSize:12,color:"#9CA3AF" }}>📧 {a.user}</div>
                      {a.phone&&<div style={{ fontSize:12,color:"#9CA3AF" }}>📞 {a.phone}</div>}
                    </div>
                    <Toggle value={a.active} onChange={()=>toggleRestAccount(a)}/>
                  </div>
                  {/* Credentials box */}
                  <div style={{ background:"#FFF7ED",borderRadius:11,padding:"9px 13px",marginBottom:9,border:"1.5px solid #FED7AA" }}>
                    <div style={{ fontSize:10,fontWeight:700,color:"#F97316",marginBottom:5,letterSpacing:0.4 }}>🔑 CREDENCIALES DE ACCESO — PANEL DE RESTAURANTE</div>
                    <div style={{ display:"flex",justifyContent:"space-between",marginBottom:2 }}><span style={{ fontSize:11,color:"#6B7280" }}>Usuario</span><span style={{ fontSize:11,fontWeight:700,fontFamily:"monospace",color:"#111" }}>{a.user}</span></div>
                    <div style={{ display:"flex",justifyContent:"space-between" }}><span style={{ fontSize:11,color:"#6B7280" }}>Contraseña</span><span style={{ fontSize:11,fontWeight:700,fontFamily:"monospace",color:"#111" }}>{a.pass}</span></div>
                  </div>
                  <div style={{ display:"flex",gap:8 }}>
                    <button onClick={()=>openEditRestAccount(a)} style={{ flex:1,padding:"8px",background:"#F9FAFB",border:"1.5px solid #F3F4F6",borderRadius:10,fontSize:12,fontWeight:600,cursor:"pointer",color:"#374151",fontFamily:"inherit" }}>✏️ Editar</button>
                    <button onClick={()=>deleteRestAccount(a.id)} style={{ flex:1,padding:"8px",background:"#FFF5F5",border:"1.5px solid #FFE4E4",borderRadius:10,fontSize:12,fontWeight:600,cursor:"pointer",color:"#FF4D4D",fontFamily:"inherit" }}>🗑️ Eliminar</button>
                  </div>
                </div>
              ))}
              {restTab==="cuentas"&&restAccounts.length===0&&(
                <div style={{ textAlign:"center",padding:"40px 0",color:"#9CA3AF" }}>
                  <div style={{ fontSize:44 }}>🍽️</div>
                  <div style={{ fontSize:14,fontWeight:700,color:"#374151",marginTop:8 }}>Sin cuentas de restaurante</div>
                  <div style={{ fontSize:12,color:"#9CA3AF",marginTop:4 }}>Crea cuentas para que los restaurantes gestionen sus pedidos</div>
                </div>
              )}
            </div>
          )}
          {view==="detail"&&activeRest&&(
            <div>
              <div style={{ padding:"10px 24px",display:"flex",alignItems:"center",gap:10,borderBottom:"1px solid #F3F4F6",background:"#fff" }}>
                <div onClick={()=>{setView("list");setActiveRest(null);}} style={{ width:34,height:34,borderRadius:10,background:"#F9FAFB",border:"1.5px solid #F3F4F6",fontSize:16,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center" }}>←</div>
                <span style={{ fontSize:20 }}>{activeRest.emoji}</span>
                <div style={{ flex:1 }}><div style={{ fontSize:14,fontWeight:800 }}>{activeRest.name}</div><div style={{ fontSize:11,color:"#9CA3AF" }}>{activeRest.cuisine}</div></div>
                <Toggle value={activeRest.active} onChange={()=>toggleRest(activeRest)}/>
              </div>
              <div style={{ padding:"10px 24px 0",display:"flex",gap:8 }}>
                {["menu","stats","info"].map(t=>(
                  <button key={t} onClick={()=>setDetailTab(t)} style={{ flex:1,padding:"8px 0",background:detailTab===t?"#6366F1":"#F9FAFB",color:detailTab===t?"#fff":"#6B7280",border:`1.5px solid ${detailTab===t?"#6366F1":"#F3F4F6"}`,borderRadius:10,fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>
                    {t==="menu"?"🍽️ Menú":t==="stats"?"📊 Stats":"ℹ️ Info"}
                  </button>
                ))}
              </div>
              {detailTab==="menu"&&(
                <div style={{ padding:"14px 24px",display:"flex",flexDirection:"column",gap:12 }}>
                  <button onClick={()=>setModal("addItem")} style={{ width:"100%",padding:"13px",background:"#F9FAFB",border:"2px dashed #E5E7EB",borderRadius:14,fontSize:14,fontWeight:700,color:"#9CA3AF",cursor:"pointer",fontFamily:"inherit" }}>＋ Agregar platillo</button>
                  {Object.entries(grouped).map(([cat,items])=>(
                    <div key={cat}>
                      <div style={{ display:"flex",alignItems:"center",gap:7,marginBottom:8 }}><div style={{ width:7,height:7,borderRadius:99,background:CAT_COLORS[cat]||"#6B7280" }}/><span style={{ fontSize:13,fontWeight:800,color:"#374151" }}>{cat}</span></div>
                      <div style={{ display:"flex",flexDirection:"column",gap:7 }}>
                        {items.map(item=>(
                          <div key={item.id} style={{ background:"#fff",borderRadius:14,padding:"12px 14px",boxShadow:"0 1px 6px rgba(0,0,0,0.05)",opacity:item.available?1:0.5,display:"flex",alignItems:"center",gap:10 }}>
                            <div style={{ flex:1 }}><div style={{ fontSize:13,fontWeight:700,color:"#111" }}>{item.name}</div>{item.description&&<div style={{ fontSize:11,color:"#9CA3AF",marginTop:1 }}>{item.description}</div>}<div style={{ fontSize:14,fontWeight:900,color:"#FF4D4D",marginTop:3 }}>${item.price}</div></div>
                            <div style={{ display:"flex",flexDirection:"column",gap:5,alignItems:"flex-end" }}>
                              <Toggle value={item.available} onChange={()=>toggleItem(item)}/>
                              <div style={{ display:"flex",gap:5 }}>
                                <button onClick={()=>{setEditTarget(item);setModal("editItem");}} style={{ width:30,height:30,borderRadius:8,background:"#F9FAFB",border:"1.5px solid #F3F4F6",fontSize:13,cursor:"pointer" }}>✏️</button>
                                <button onClick={()=>deleteItem(item.id)} style={{ width:30,height:30,borderRadius:8,background:"#FFF5F5",border:"1.5px solid #FFE4E4",fontSize:13,cursor:"pointer" }}>🗑️</button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
              {detailTab==="stats"&&(()=>{
                const rOrders=orders.filter(o=>o.restaurant_name===activeRest.name);
                const rDel=rOrders.filter(o=>o.status==="delivered");
                const rRev=rDel.reduce((s,o)=>s+(o.total||0),0);
                const rAvg=rDel.length>0?Math.round(rRev/rDel.length):0;
                const rByDay=last7.map(d=>({l:d.toLocaleDateString("es-MX",{weekday:"short"}),v:rOrders.filter(o=>new Date(o.created_at).toDateString()===d.toDateString()).length}));
                return (
                  <div style={{ padding:"14px 24px",display:"flex",flexDirection:"column",gap:12 }}>
                    <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:10 }}>
                      {[{icon:"💰",l:"Ingresos",v:`$${rRev}`,c:"#16A34A",bg:"#F0FDF4"},{icon:"📦",l:"Pedidos",v:rOrders.length,c:"#6366F1",bg:"#EEF2FF"},{icon:"✅",l:"Entregados",v:rDel.length,c:"#16A34A",bg:"#F0FDF4"},{icon:"💵",l:"Ticket prom.",v:`$${rAvg}`,c:"#F59E0B",bg:"#FFFBEB"}].map((s,i)=>(
                        <div key={i} style={{ background:s.bg,borderRadius:14,padding:"12px 14px" }}><div style={{ fontSize:20 }}>{s.icon}</div><div style={{ fontSize:17,fontWeight:900,color:s.c,marginTop:4 }}>{s.v}</div><div style={{ fontSize:11,color:"#6B7280",marginTop:2 }}>{s.l}</div></div>
                      ))}
                    </div>
                    <div style={{ background:"#fff",borderRadius:14,padding:"14px",boxShadow:"0 1px 6px rgba(0,0,0,0.06)" }}>
                      <div style={{ fontSize:13,fontWeight:800,color:"#111",marginBottom:12 }}>📅 Pedidos últimos 7 días</div>
                      <MiniBar data={rByDay} color="#6366F1" height={70}/>
                    </div>
                    <div style={{ background:"#fff",borderRadius:14,padding:"14px",boxShadow:"0 1px 6px rgba(0,0,0,0.06)" }}>
                      <div style={{ fontSize:13,fontWeight:800,color:"#111",marginBottom:10 }}>🍽️ Platillos disponibles</div>
                      {menuItems.filter(i=>i.restaurant_id===activeRest.id).slice(0,6).map((item,i,arr)=>(
                        <div key={item.id} style={{ display:"flex",justifyContent:"space-between",alignItems:"center",padding:"7px 0",borderBottom:i<arr.length-1?"1px solid #F9FAFB":"none" }}>
                          <div style={{ display:"flex",alignItems:"center",gap:7 }}><span style={{ width:20,height:20,borderRadius:99,background:"#EEF2FF",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:800,color:"#6366F1",flexShrink:0 }}>{i+1}</span><span style={{ fontSize:13,fontWeight:600,color:"#111" }}>{item.name}</span></div>
                          <span style={{ fontSize:13,fontWeight:700,color:"#FF4D4D" }}>${item.price}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })()}
              {detailTab==="info"&&(
                <div style={{ padding:"14px 24px",display:"flex",flexDirection:"column",gap:10 }}>
                  <div style={{ background:"#fff",borderRadius:18,padding:16,boxShadow:"0 1px 6px rgba(0,0,0,0.06)" }}>
                    {[{icon:"🏪",label:"Nombre",value:activeRest.name},{icon:"🍽️",label:"Cocina",value:activeRest.cuisine},{icon:"📍",label:"Dirección",value:activeRest.address},{icon:"📞",label:"Teléfono",value:activeRest.phone},{icon:"🕐",label:"Horario",value:activeRest.hours},{icon:"⭐",label:"Rating",value:activeRest.rating}].map((row,i,arr)=>(
                      <div key={i} style={{ display:"flex",alignItems:"flex-start",gap:10,padding:"9px 0",borderBottom:i<arr.length-1?"1px solid #F9FAFB":"none" }}>
                        <span style={{ fontSize:16 }}>{row.icon}</span>
                        <div><div style={{ fontSize:10,color:"#9CA3AF",fontWeight:600 }}>{row.label}</div><div style={{ fontSize:13,fontWeight:600,color:row.value?"#111":"#D1D5DB",marginTop:1 }}>{row.value||"—"}</div></div>
                      </div>
                    ))}
                  </div>
                  <button onClick={()=>{setEditTarget(activeRest);setModal("editRest");}} style={{ width:"100%",padding:"13px",background:"#6366F1",color:"#fff",border:"none",borderRadius:13,fontSize:14,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>✏️ Editar restaurante</button>
                  <button onClick={()=>deleteRestaurant(activeRest.id)} style={{ width:"100%",padding:"13px",background:"#FFF5F5",color:"#FF4D4D",border:"1.5px solid #FFE4E4",borderRadius:13,fontSize:14,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>🗑️ Eliminar restaurante</button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ── TAB: PEDIDOS ── */}
      {adminTab==="pedidos"&&(
        <div style={{ padding:"16px 24px",display:"flex",flexDirection:"column",gap:12 }}>
          <div style={{ background:"#F9FAFB",border:"1.5px solid #F3F4F6",borderRadius:12,padding:"10px 14px",display:"flex",alignItems:"center",gap:8 }}>
            <span style={{ fontSize:15,opacity:0.4 }}>🔍</span>
            <input value={orderSearch} onChange={e=>setOrderSearch(e.target.value)} placeholder="Buscar por restaurante o #pedido…" style={{ border:"none",background:"transparent",fontSize:14,color:"#111",outline:"none",flex:1,fontFamily:"inherit" }}/>
          </div>
          <div style={{ display:"flex",gap:7,overflowX:"auto",scrollbarWidth:"none" }}>
            {[{id:"all",label:"Todos",n:orders.length},{id:"pending",label:"Pendientes",n:orders.filter(o=>o.status==="pending").length},{id:"delivering",label:"En camino",n:orders.filter(o=>o.status==="delivering").length},{id:"delivered",label:"Entregados",n:orders.filter(o=>o.status==="delivered").length},{id:"cancelled",label:"Cancelados",n:orders.filter(o=>o.status==="cancelled").length}].map(f=>(
              <button key={f.id} onClick={()=>setOrderFilter(f.id)} style={{ flexShrink:0,padding:"6px 12px",borderRadius:99,border:`1.5px solid ${orderFilter===f.id?"#6366F1":"#F3F4F6"}`,background:orderFilter===f.id?"#6366F1":"#fff",color:orderFilter===f.id?"#fff":"#6B7280",fontSize:11,fontWeight:700,cursor:"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",gap:4 }}>
                {f.label}<span style={{ background:orderFilter===f.id?"rgba(255,255,255,0.2)":"#F3F4F6",borderRadius:99,padding:"1px 5px",fontSize:10,color:orderFilter===f.id?"#fff":"#9CA3AF" }}>{f.n}</span>
              </button>
            ))}
          </div>
          <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:9 }}>
            {[{icon:"💰",l:"Ingresos",v:`$${totalRevenue}`,c:"#16A34A",bg:"#F0FDF4"},{icon:"📦",l:"Total",v:orders.length,c:"#6366F1",bg:"#EEF2FF"},{icon:"🔄",l:"Activos",v:totalPending,c:"#F59E0B",bg:"#FFFBEB"},{icon:"✅",l:"Entregados",v:totalDelivered,c:"#16A34A",bg:"#F0FDF4"}].map((s,i)=>(
              <div key={i} style={{ background:s.bg,borderRadius:13,padding:"11px 13px" }}><div style={{ fontSize:18 }}>{s.icon}</div><div style={{ fontSize:17,fontWeight:900,color:s.c,marginTop:3 }}>{s.v}</div><div style={{ fontSize:10,color:"#6B7280",marginTop:1 }}>{s.l}</div></div>
            ))}
          </div>
          {selectedOrder?(
            <div style={{ background:"#fff",borderRadius:18,padding:16,boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
              <div style={{ display:"flex",alignItems:"center",gap:8,marginBottom:14 }}>
                <button onClick={()=>setSelectedOrder(null)} style={{ background:"#F9FAFB",border:"1.5px solid #F3F4F6",borderRadius:9,padding:"5px 11px",fontSize:12,fontWeight:700,cursor:"pointer",color:"#374151",fontFamily:"inherit" }}>← Volver</button>
                <span style={{ flex:1,fontSize:14,fontWeight:800 }}>Pedido #{selectedOrder.id}</span>
                <div style={{ background:`${STATUS_COLOR[selectedOrder.status]||"#6B7280"}18`,color:STATUS_COLOR[selectedOrder.status]||"#6B7280",fontSize:10,fontWeight:700,padding:"3px 9px",borderRadius:99 }}>{STATUS_LABEL[selectedOrder.status]}</div>
              </div>
              {[{icon:"🏪",l:"Restaurante",v:selectedOrder.restaurant_name},{icon:"📍",l:"Dirección",v:selectedOrder.delivery_address},{icon:"💳",l:"Pago",v:selectedOrder.payment_method},{icon:"📅",l:"Fecha",v:selectedOrder.created_at?new Date(selectedOrder.created_at).toLocaleString("es-MX"):"—"}].map((row,i)=>(
                <div key={i} style={{ display:"flex",gap:9,padding:"7px 0",borderBottom:i<3?"1px solid #F9FAFB":"none" }}>
                  <span style={{ fontSize:15 }}>{row.icon}</span><div><div style={{ fontSize:10,color:"#9CA3AF",fontWeight:600 }}>{row.l}</div><div style={{ fontSize:12,fontWeight:600,color:"#111",marginTop:1 }}>{row.v||"—"}</div></div>
                </div>
              ))}
              {Array.isArray(selectedOrder.items)&&(
                <div style={{ marginTop:10,padding:"10px 12px",background:"#F9FAFB",borderRadius:10 }}>
                  <div style={{ fontSize:10,fontWeight:700,color:"#9CA3AF",marginBottom:6 }}>ARTÍCULOS</div>
                  {selectedOrder.items.map((item,i)=>(
                    <div key={i} style={{ display:"flex",justifyContent:"space-between",padding:"4px 0" }}><span style={{ fontSize:12,color:"#374151" }}>{item.name} ×{item.qty}</span><span style={{ fontSize:12,fontWeight:700 }}>${item.price*item.qty}</span></div>
                  ))}
                  <div style={{ display:"flex",justifyContent:"space-between",paddingTop:8,marginTop:6,borderTop:"1.5px solid #E5E7EB" }}><span style={{ fontSize:13,fontWeight:800 }}>Total</span><span style={{ fontSize:13,fontWeight:900,color:"#FF4D4D" }}>${selectedOrder.total}</span></div>
                </div>
              )}
              <div style={{ marginTop:12 }}>
                <div style={{ fontSize:10,fontWeight:700,color:"#9CA3AF",marginBottom:6 }}>CAMBIAR ESTADO</div>
                <div style={{ display:"flex",flexWrap:"wrap",gap:6 }}>
                  {["pending","confirmed","delivering","delivered","cancelled"].map(s=>(
                    <button key={s} onClick={()=>updateOrderStatus(selectedOrder,s)} disabled={selectedOrder.status===s}
                      style={{ padding:"6px 12px",borderRadius:9,border:`1.5px solid ${STATUS_COLOR[s]}`,background:selectedOrder.status===s?STATUS_COLOR[s]:"#fff",color:selectedOrder.status===s?"#fff":STATUS_COLOR[s],fontSize:11,fontWeight:700,cursor:selectedOrder.status===s?"default":"pointer",fontFamily:"inherit",opacity:selectedOrder.status===s?1:0.8 }}>
                      {STATUS_LABEL[s]}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ):(
            ordersLoading?[1,2,3].map(i=>(<div key={i} style={{ background:"#fff",borderRadius:14,padding:"14px",display:"flex",flexDirection:"column",gap:7 }}><Skeleton h={13} w="55%"/><Skeleton h={10} w="70%"/></div>))
            :filteredOrders.length===0?<div style={{ textAlign:"center",padding:"44px 0",color:"#9CA3AF" }}><div style={{ fontSize:44 }}>📋</div><div style={{ fontSize:13,fontWeight:600,color:"#374151",marginTop:8 }}>Sin pedidos</div></div>
            :filteredOrders.map(order=>(
              <div key={order.id} onClick={()=>setSelectedOrder(order)} style={{ background:"#fff",borderRadius:16,padding:"13px 15px",boxShadow:"0 1px 6px rgba(0,0,0,0.05)",cursor:"pointer" }}>
                <div style={{ display:"flex",justifyContent:"space-between",marginBottom:5 }}><span style={{ fontSize:14,fontWeight:800,color:"#111" }}>{order.restaurant_name}</span><div style={{ background:`${STATUS_COLOR[order.status]||"#6B7280"}18`,color:STATUS_COLOR[order.status]||"#6B7280",fontSize:10,fontWeight:700,padding:"2px 9px",borderRadius:99 }}>{STATUS_LABEL[order.status]||order.status}</div></div>
                <div style={{ fontSize:11,color:"#9CA3AF",marginBottom:5 }}>{Array.isArray(order.items)?order.items.map(i=>`${i.name} ×${i.qty}`).join(", "):"—"}</div>
                <div style={{ display:"flex",justifyContent:"space-between" }}><span style={{ fontSize:10,color:"#D1D5DB" }}>#{order.id}</span><span style={{ fontSize:13,fontWeight:900,color:"#FF4D4D" }}>${order.total}</span></div>
              </div>
            ))
          )}
        </div>
      )}

      {/* ── TAB: CLIENTES ── */}
      {adminTab==="clientes"&&(()=>{
        const allCustomers = loadCustomers();
        const [custSearch, setCustSearch] = useState("");
        const [selectedCust, setSelectedCust] = useState(null);

        const filtered = allCustomers.filter(c =>
          !custSearch ||
          c.name?.toLowerCase().includes(custSearch.toLowerCase()) ||
          c.phone?.includes(custSearch) ||
          c.email?.toLowerCase().includes(custSearch.toLowerCase())
        );

        const custOrders = (c) => orders.filter(o=>
          o.delivery_address?.includes(c.address?.street||"____") ||
          String(o.phone||"").includes(c.phone||"____")
        );

        if(selectedCust) {
          const co = custOrders(selectedCust);
          const cRev = co.filter(o=>o.status==="delivered").reduce((s,o)=>s+(o.total||0),0);
          return (
            <div style={{ padding:"16px 24px",display:"flex",flexDirection:"column",gap:12 }}>
              <button onClick={()=>setSelectedCust(null)} style={{ alignSelf:"flex-start",background:"#F9FAFB",border:"1.5px solid #F3F4F6",borderRadius:10,padding:"7px 14px",fontSize:13,fontWeight:700,cursor:"pointer",color:"#374151",fontFamily:"inherit" }}>← Volver</button>
              {/* Customer card */}
              <div style={{ background:"linear-gradient(135deg,#FF4D4D,#FF6B6B)",borderRadius:20,padding:"20px 22px" }}>
                <div style={{ display:"flex",alignItems:"center",gap:14,marginBottom:16 }}>
                  <div style={{ width:56,height:56,borderRadius:99,background:"rgba(255,255,255,0.25)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:26,fontWeight:800,color:"#fff" }}>
                    {selectedCust.name?.[0]?.toUpperCase()||"?"}
                  </div>
                  <div>
                    <div style={{ fontSize:18,fontWeight:900,color:"#fff" }}>{selectedCust.name}</div>
                    <div style={{ fontSize:13,color:"rgba(255,255,255,0.75)" }}>📱 {selectedCust.phone}</div>
                    {selectedCust.email&&<div style={{ fontSize:12,color:"rgba(255,255,255,0.65)" }}>✉️ {selectedCust.email}</div>}
                  </div>
                </div>
                <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8 }}>
                  {[{l:"Pedidos",v:selectedCust.totalOrders||co.length},{l:"Gastado",v:`$${cRev}`},{l:"Registro",v:new Date(selectedCust.createdAt).toLocaleDateString("es-MX",{day:"numeric",month:"short"})}].map((s,i)=>(
                    <div key={i} style={{ background:"rgba(255,255,255,0.2)",borderRadius:10,padding:"9px 10px",textAlign:"center" }}>
                      <div style={{ fontSize:15,fontWeight:900,color:"#fff" }}>{s.v}</div>
                      <div style={{ fontSize:10,color:"rgba(255,255,255,0.7)" }}>{s.l}</div>
                    </div>
                  ))}
                </div>
              </div>
              {/* Address */}
              {selectedCust.address&&(
                <div style={{ background:"#fff",borderRadius:16,padding:"14px 16px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
                  <div style={{ fontSize:13,fontWeight:800,color:"#111",marginBottom:10 }}>📍 Dirección registrada</div>
                  <div style={{ fontSize:13,color:"#374151",lineHeight:1.7 }}>
                    {selectedCust.address.street} #{selectedCust.address.number}<br/>
                    {selectedCust.address.colonia}{selectedCust.address.cp?`, CP ${selectedCust.address.cp}`:""}
                    {selectedCust.address.refs&&<><br/><span style={{ color:"#9CA3AF" }}>📌 {selectedCust.address.refs}</span></>}
                  </div>
                </div>
              )}
              {/* Order history */}
              <div style={{ background:"#fff",borderRadius:16,padding:"14px 16px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
                <div style={{ fontSize:13,fontWeight:800,color:"#111",marginBottom:10 }}>📦 Historial de pedidos</div>
                {co.length===0?<div style={{ fontSize:13,color:"#9CA3AF",textAlign:"center",padding:"12px 0" }}>Sin pedidos registrados</div>:co.slice(0,5).map((o,i)=>(
                  <div key={o.id} style={{ display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:i<Math.min(co.length,5)-1?"1px solid #F9FAFB":"none" }}>
                    <div><div style={{ fontSize:13,fontWeight:600,color:"#111" }}>{o.restaurant_name}</div><div style={{ fontSize:11,color:"#9CA3AF" }}>#{o.id}</div></div>
                    <div style={{ textAlign:"right" }}><div style={{ fontSize:13,fontWeight:800,color:"#FF4D4D" }}>${o.total}</div><div style={{ background:`${({pending:"#F59E0B",delivered:"#16A34A",cancelled:"#EF4444"}[o.status]||"#6B7280")}18`,color:{pending:"#F59E0B",delivered:"#16A34A",cancelled:"#EF4444"}[o.status]||"#6B7280",fontSize:10,fontWeight:700,padding:"2px 7px",borderRadius:99 }}>{o.status}</div></div>
                  </div>
                ))}
              </div>
            </div>
          );
        }

        return (
          <div style={{ padding:"16px 24px",display:"flex",flexDirection:"column",gap:12 }}>
            {/* Stats */}
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:9 }}>
              {[{icon:"👥",l:"Total",v:allCustomers.length,bg:"#EEF2FF",c:"#6366F1"},{icon:"🆕",l:"Este mes",v:allCustomers.filter(c=>new Date(c.createdAt).getMonth()===new Date().getMonth()).length,bg:"#F0FDF4",c:"#16A34A"},{icon:"🟢",l:"Activos",v:allCustomers.filter(c=>c.active!==false).length,bg:"#FFF7ED",c:"#F97316"}].map((s,i)=>(
                <div key={i} style={{ background:s.bg,borderRadius:13,padding:"12px 10px",textAlign:"center" }}>
                  <div style={{ fontSize:20 }}>{s.icon}</div>
                  <div style={{ fontSize:18,fontWeight:900,color:s.c,marginTop:3 }}>{s.v}</div>
                  <div style={{ fontSize:10,color:"#6B7280",marginTop:1 }}>{s.l}</div>
                </div>
              ))}
            </div>
            {/* Search */}
            <div style={{ background:"#F9FAFB",border:"1.5px solid #F3F4F6",borderRadius:12,padding:"10px 14px",display:"flex",alignItems:"center",gap:8 }}>
              <span style={{ fontSize:15,opacity:0.4 }}>🔍</span>
              <input value={custSearch} onChange={e=>setCustSearch(e.target.value)} placeholder="Buscar por nombre, teléfono o correo…" style={{ border:"none",background:"transparent",fontSize:14,color:"#111",outline:"none",flex:1,fontFamily:"inherit" }}/>
              {custSearch&&<span onClick={()=>setCustSearch("")} style={{ fontSize:14,opacity:0.4,cursor:"pointer" }}>✕</span>}
            </div>
            {/* List */}
            {filtered.length===0?(
              <div style={{ textAlign:"center",padding:"44px 0",color:"#9CA3AF" }}>
                <div style={{ fontSize:44 }}>👥</div>
                <div style={{ fontSize:14,fontWeight:700,color:"#374151",marginTop:8 }}>{allCustomers.length===0?"Sin clientes registrados":"Sin resultados"}</div>
                {allCustomers.length===0&&<div style={{ fontSize:12,marginTop:4 }}>Los clientes aparecerán aquí cuando se registren</div>}
              </div>
            ):filtered.map(c=>(
              <div key={c.id} onClick={()=>setSelectedCust(c)} style={{ background:"#fff",borderRadius:18,padding:"14px 16px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)",cursor:"pointer",display:"flex",alignItems:"center",gap:12 }}>
                <div style={{ width:44,height:44,borderRadius:99,background:"linear-gradient(135deg,#FF4D4D,#FF6B6B)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,fontWeight:800,color:"#fff",flexShrink:0 }}>
                  {c.name?.[0]?.toUpperCase()||"?"}
                </div>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:14,fontWeight:800,color:"#111" }}>{c.name}</div>
                  <div style={{ fontSize:12,color:"#9CA3AF",marginTop:1 }}>📱 {c.phone}{c.email?` · ${c.email}`:""}</div>
                  <div style={{ fontSize:11,color:"#9CA3AF",marginTop:1 }}>
                    {c.address?.colonia?`📍 ${c.address.colonia}`:""} · Desde {new Date(c.createdAt).toLocaleDateString("es-MX",{day:"numeric",month:"short",year:"numeric"})}
                  </div>
                </div>
                <div style={{ textAlign:"right",flexShrink:0 }}>
                  <div style={{ background:c.active!==false?"#F0FDF4":"#FFF5F5",color:c.active!==false?"#16A34A":"#FF4D4D",fontSize:10,fontWeight:700,padding:"3px 9px",borderRadius:99 }}>{c.active!==false?"Activo":"Inactivo"}</div>
                  <svg width="7" height="12" viewBox="0 0 8 14" fill="none" style={{ marginTop:4,opacity:0.25 }}><path d="M1 1l6 6-6 6" stroke="#111" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                </div>
              </div>
            ))}
          </div>
        );
      })()}

      {/* ── TAB: ESTADÍSTICAS ── */}
      {adminTab==="estadisticas"&&(
        <div style={{ padding:"16px 24px",display:"flex",flexDirection:"column",gap:13 }}>
          <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:10 }}>
            {[{icon:"💰",l:"Ingresos totales",v:`$${totalRevenue.toLocaleString()}`,c:"#16A34A",bg:"#F0FDF4"},{icon:"📦",l:"Pedidos totales",v:orders.length,c:"#6366F1",bg:"#EEF2FF"},{icon:"✅",l:"Entregados",v:totalDelivered,c:"#16A34A",bg:"#F0FDF4"},{icon:"💵",l:"Ticket promedio",v:`$${avgOrder}`,c:"#F59E0B",bg:"#FFFBEB"},{icon:"🏪",l:"Restaurantes",v:restaurants.filter(r=>r.active).length,c:"#6366F1",bg:"#EEF2FF"},{icon:"🍽️",l:"Cuentas rest.",v:restAccounts.filter(a=>a.active).length,c:"#F97316",bg:"#FFF7ED"},{icon:"🛵",l:"Repartidores",v:drivers.filter(d=>d.active).length,c:"#FF4D4D",bg:"#FFF5F5"}].map((s,i)=>(
              <div key={i} style={{ background:s.bg,borderRadius:15,padding:"13px 15px" }}><div style={{ fontSize:20 }}>{s.icon}</div><div style={{ fontSize:19,fontWeight:900,color:s.c,marginTop:4 }}>{s.v}</div><div style={{ fontSize:11,color:"#6B7280",marginTop:2 }}>{s.l}</div></div>
            ))}
          </div>
          <div style={{ background:"#fff",borderRadius:16,padding:"15px 16px",boxShadow:"0 1px 6px rgba(0,0,0,0.06)" }}>
            <div style={{ fontSize:13,fontWeight:800,color:"#111",marginBottom:3 }}>📅 Pedidos — últimos 7 días</div>
            <div style={{ fontSize:11,color:"#9CA3AF",marginBottom:12 }}>{ordersByDay.reduce((s,d)=>s+d.v,0)} pedidos en total</div>
            <MiniBar data={ordersByDay} color="#6366F1" height={75}/>
          </div>
          <div style={{ background:"#fff",borderRadius:16,padding:"15px 16px",boxShadow:"0 1px 6px rgba(0,0,0,0.06)" }}>
            <div style={{ fontSize:13,fontWeight:800,color:"#111",marginBottom:3 }}>💰 Ingresos — últimos 7 días</div>
            <div style={{ fontSize:11,color:"#9CA3AF",marginBottom:12 }}>${revenueByDay.reduce((s,d)=>s+d.v,0).toLocaleString()} en ingresos</div>
            <MiniBar data={revenueByDay} color="#16A34A" height={75}/>
          </div>
          <div style={{ background:"#fff",borderRadius:16,padding:"15px 16px",boxShadow:"0 1px 6px rgba(0,0,0,0.06)" }}>
            <div style={{ fontSize:13,fontWeight:800,color:"#111",marginBottom:13 }}>📊 Distribución de estados</div>
            {statusDist.map((s,i)=>{ const pct=orders.length>0?Math.round((s.count/orders.length)*100):0; return (
              <div key={i} style={{ marginBottom:i<statusDist.length-1?11:0 }}>
                <div style={{ display:"flex",justifyContent:"space-between",marginBottom:4 }}><span style={{ fontSize:12,fontWeight:600,color:"#374151" }}>{s.label}</span><span style={{ fontSize:12,fontWeight:700,color:s.color }}>{s.count} <span style={{ color:"#9CA3AF",fontWeight:500 }}>({pct}%)</span></span></div>
                <div style={{ background:"#F3F4F6",borderRadius:99,height:7 }}><div style={{ background:s.color,borderRadius:99,height:7,width:`${pct}%`,transition:"width 0.6s ease",minWidth:pct>0?6:0 }}/></div>
              </div>
            );})}
          </div>
          <div style={{ background:"#fff",borderRadius:16,padding:"15px 16px",boxShadow:"0 1px 6px rgba(0,0,0,0.06)" }}>
            <div style={{ fontSize:13,fontWeight:800,color:"#111",marginBottom:13 }}>🏆 Ingresos por restaurante</div>
            {revenueByRest.length===0?<div style={{ textAlign:"center",padding:"16px 0",color:"#9CA3AF",fontSize:12 }}>Sin datos aún</div>:revenueByRest.map((r,i)=>(
              <div key={i} style={{ display:"flex",alignItems:"center",gap:10,padding:"9px 0",borderBottom:i<revenueByRest.length-1?"1px solid #F9FAFB":"none" }}>
                <span style={{ fontSize:20 }}>{r.emoji||"🍽️"}</span>
                <div style={{ flex:1 }}><div style={{ fontSize:12,fontWeight:700,color:"#111",marginBottom:3 }}>{r.name}</div><div style={{ background:"#F3F4F6",borderRadius:99,height:5 }}><div style={{ background:"#6366F1",borderRadius:99,height:5,width:`${revenueByRest[0].revenue>0?(r.revenue/revenueByRest[0].revenue)*100:0}%`,transition:"width 0.6s" }}/></div></div>
                <div style={{ textAlign:"right",flexShrink:0 }}><div style={{ fontSize:13,fontWeight:900,color:"#16A34A" }}>${r.revenue}</div><div style={{ fontSize:10,color:"#9CA3AF" }}>{r.orders} pedidos</div></div>
              </div>
            ))}
          </div>
          <div style={{ background:"#fff",borderRadius:16,padding:"15px 16px",boxShadow:"0 1px 6px rgba(0,0,0,0.06)" }}>
            <div style={{ fontSize:13,fontWeight:800,color:"#111",marginBottom:12 }}>🛵 Repartidores</div>
            {drivers.length===0?<div style={{ textAlign:"center",padding:"16px 0",color:"#9CA3AF",fontSize:12 }}>Sin repartidores</div>:drivers.map((d,i)=>(
              <div key={d.id} style={{ display:"flex",alignItems:"center",gap:10,padding:"9px 0",borderBottom:i<drivers.length-1?"1px solid #F9FAFB":"none" }}>
                <div style={{ width:34,height:34,borderRadius:99,background:"linear-gradient(135deg,#6366F1,#8B5CF6)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,flexShrink:0 }}>🛵</div>
                <div style={{ flex:1 }}><div style={{ fontSize:12,fontWeight:700,color:"#111" }}>{d.name}</div><div style={{ fontSize:10,color:"#9CA3AF" }}>{d.vehicle||"—"}</div></div>
                <div style={{ background:d.active?"#F0FDF4":"#FFF5F5",color:d.active?"#16A34A":"#FF4D4D",fontSize:10,fontWeight:700,padding:"2px 8px",borderRadius:99 }}>{d.active?"Activo":"Inactivo"}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── TAB: CONFIG ── */}
      {adminTab==="config"&&(
        <div style={{ padding:"16px 24px 80px",display:"flex",flexDirection:"column",gap:13 }}>
          <div style={{ background:"#fff",borderRadius:16,padding:"16px 18px",boxShadow:"0 1px 6px rgba(0,0,0,0.06)" }}>
            <div style={{ fontSize:13,fontWeight:800,color:"#111",marginBottom:13 }}>🏪 General</div>
            {[{k:"appName",l:"NOMBRE DE LA APP",ph:"YummiGoApp"},{k:"city",l:"CIUDAD",ph:"Aguascalientes"}].map(f=>(
              <div key={f.k} style={{ marginBottom:11 }}><div style={{ fontSize:11,fontWeight:700,color:"#6B7280",marginBottom:5 }}>{f.l}</div><input value={cfgForm[f.k]} onChange={e=>setCF(f.k)(e.target.value)} placeholder={f.ph} style={{ width:"100%",padding:"10px 13px",background:"#F9FAFB",border:"1.5px solid #F3F4F6",borderRadius:10,fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }} onFocus={e=>e.target.style.borderColor="#6366F1"} onBlur={e=>e.target.style.borderColor="#F3F4F6"}/></div>
            ))}
            <div style={{ display:"flex",gap:10 }}>
              <div style={{ flex:1 }}><div style={{ fontSize:11,fontWeight:700,color:"#6B7280",marginBottom:5 }}>APERTURA</div><input type="time" value={cfgForm.openTime} onChange={e=>setCF("openTime")(e.target.value)} style={{ width:"100%",padding:"10px 13px",background:"#F9FAFB",border:"1.5px solid #F3F4F6",borderRadius:10,fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}/></div>
              <div style={{ flex:1 }}><div style={{ fontSize:11,fontWeight:700,color:"#6B7280",marginBottom:5 }}>CIERRE</div><input type="time" value={cfgForm.closeTime} onChange={e=>setCF("closeTime")(e.target.value)} style={{ width:"100%",padding:"10px 13px",background:"#F9FAFB",border:"1.5px solid #F3F4F6",borderRadius:10,fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}/></div>
            </div>
          </div>
          <div style={{ background:"#fff",borderRadius:16,padding:"16px 18px",boxShadow:"0 1px 6px rgba(0,0,0,0.06)" }}>
            <div style={{ fontSize:13,fontWeight:800,color:"#111",marginBottom:13 }}>🚚 Envío y comisiones</div>
            {[{k:"deliveryBase",l:"ENVÍO BASE ($)",ph:"25"},{k:"deliveryMax",l:"ENVÍO MÁXIMO ($)",ph:"55"},{k:"minOrder",l:"PEDIDO MÍNIMO ($)",ph:"0"},{k:"commissionPct",l:"COMISIÓN PLATAFORMA (%)",ph:"15"}].map((f,i)=>(
              <div key={f.k} style={{ marginBottom:i<3?11:0 }}><div style={{ fontSize:11,fontWeight:700,color:"#6B7280",marginBottom:5 }}>{f.l}</div><input type="number" value={cfgForm[f.k]} onChange={e=>setCF(f.k)(parseFloat(e.target.value)||0)} placeholder={f.ph} style={{ width:"100%",padding:"10px 13px",background:"#F9FAFB",border:"1.5px solid #F3F4F6",borderRadius:10,fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }} onFocus={e=>e.target.style.borderColor="#6366F1"} onBlur={e=>e.target.style.borderColor="#F3F4F6"}/></div>
            ))}
          </div>
          <div style={{ background:"#fff",borderRadius:16,padding:"16px 18px",boxShadow:"0 1px 6px rgba(0,0,0,0.06)" }}>
            <div style={{ fontSize:13,fontWeight:800,color:"#111",marginBottom:13 }}>🔧 Opciones</div>
            {[{k:"allowNewOrders",l:"Permitir nuevos pedidos",s:"Si está apagado, no se aceptan órdenes"},{k:"maintenanceMode",l:"Modo mantenimiento",s:"Muestra aviso a usuarios"},{k:"showRatings",l:"Mostrar calificaciones",s:"Visible en lista de restaurantes"}].map((item,i,arr)=>(
              <div key={item.k} style={{ display:"flex",alignItems:"center",gap:12,padding:"11px 0",borderBottom:i<arr.length-1?"1px solid #F9FAFB":"none" }}>
                <div style={{ flex:1 }}><div style={{ fontSize:13,fontWeight:600,color:"#111" }}>{item.l}</div><div style={{ fontSize:11,color:"#9CA3AF",marginTop:1 }}>{item.s}</div></div>
                <Toggle value={cfgForm[item.k]} onChange={()=>setCF(item.k)(!cfgForm[item.k])}/>
              </div>
            ))}
          </div>
          <div style={{ background:"#EEF2FF",borderRadius:16,padding:"16px 18px" }}>
            <div style={{ fontSize:13,fontWeight:800,color:"#6366F1",marginBottom:11 }}>🔐 Credenciales de administrador</div>
            <div style={{ display:"flex",justifyContent:"space-between",marginBottom:5 }}><span style={{ fontSize:12,color:"#6B7280" }}>Usuario</span><span style={{ fontSize:12,fontWeight:700,color:"#111",fontFamily:"monospace" }}>{ADMIN_CREDENTIALS.user}</span></div>
            <div style={{ display:"flex",justifyContent:"space-between" }}><span style={{ fontSize:12,color:"#6B7280" }}>Contraseña</span><span style={{ fontSize:12,fontWeight:700,color:"#111",fontFamily:"monospace" }}>{ADMIN_CREDENTIALS.pass}</span></div>
            <div style={{ fontSize:11,color:"#6366F1",marginTop:9,lineHeight:1.5 }}>⚠️ No compartas estas credenciales. Guárdalas en un lugar seguro.</div>
          </div>
          <button onClick={saveCfg} style={{ width:"100%",padding:"15px",background:"#6366F1",color:"#fff",border:"none",borderRadius:15,fontSize:15,fontWeight:700,cursor:"pointer",fontFamily:"inherit",boxShadow:"0 4px 16px rgba(99,102,241,0.3)" }}>Guardar configuración ✓</button>
        </div>
      )}

      {/* Modals */}
      {modal==="addRest"&&<Modal title="➕ Nuevo restaurante" onClose={()=>setModal(null)}><RestForm onSave={addRestaurant} onClose={()=>setModal(null)}/></Modal>}
      {modal==="editRest"&&<Modal title="✏️ Editar restaurante" onClose={()=>setModal(null)}><RestForm initial={activeRest} onSave={updateRestaurant} onClose={()=>setModal(null)}/></Modal>}
      {modal==="addItem"&&<Modal title="➕ Nuevo platillo" onClose={()=>setModal(null)}><ItemForm onSave={addItem} onClose={()=>setModal(null)}/></Modal>}
      {modal==="editItem"&&<Modal title="✏️ Editar platillo" onClose={()=>setModal(null)}><ItemForm initial={editTarget} onSave={updateItem} onClose={()=>setModal(null)}/></Modal>}

      {/* Restaurant account modal */}
      {restAccountModal&&(
        <div style={{ position:"fixed",inset:0,background:"rgba(0,0,0,0.5)",zIndex:700,display:"flex",alignItems:"flex-end",justifyContent:"center" }} onClick={()=>setRestAccountModal(false)}>
          <div onClick={e=>e.stopPropagation()} style={{ background:"#fff",width:"100%",maxWidth:430,borderRadius:"24px 24px 0 0",padding:"20px 24px 36px",maxHeight:"92vh",overflowY:"auto" }}>
            <div style={{ width:40,height:4,background:"#E5E7EB",borderRadius:99,margin:"0 auto 18px" }}/>
            <div style={{ fontSize:17,fontWeight:800,color:"#111",marginBottom:18 }}>{editRestAccount?"✏️ Editar cuenta":"🍽️ Nueva cuenta de restaurante"}</div>

            {/* Emoji picker */}
            <div style={{ marginBottom:14 }}>
              <div style={{ fontSize:11,fontWeight:700,color:"#6B7280",marginBottom:8 }}>EMOJI DEL RESTAURANTE</div>
              <div style={{ display:"flex",flexWrap:"wrap",gap:7 }}>
                {EMOJIS.map(e=><div key={e} onClick={()=>setRA("emoji")(e)} style={{ width:38,height:38,borderRadius:10,fontSize:20,display:"flex",alignItems:"center",justifyContent:"center",background:restAccountForm.emoji===e?"#F97316":"#F9FAFB",border:`1.5px solid ${restAccountForm.emoji===e?"#F97316":"#F3F4F6"}`,cursor:"pointer" }}>{e}</div>)}
              </div>
            </div>

            <div style={{ marginBottom:12 }}>
              <div style={{ fontSize:11,fontWeight:700,color:"#6B7280",marginBottom:5 }}>NOMBRE DEL RESTAURANTE *</div>
              <input value={restAccountForm.restaurantName} onChange={e=>setRA("restaurantName")(e.target.value)} placeholder="Ej: Nápoli Pizza"
                style={{ width:"100%",padding:"11px 14px",background:"#F9FAFB",border:`2px solid ${restAccountErr.restaurantName?"#FF4D4D":"#F3F4F6"}`,borderRadius:11,fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}
                onFocus={e=>e.target.style.borderColor="#F97316"} onBlur={e=>e.target.style.borderColor=restAccountErr.restaurantName?"#FF4D4D":"#F3F4F6"}/>
              {restAccountErr.restaurantName&&<div style={{ fontSize:11,color:"#FF4D4D",marginTop:2 }}>{restAccountErr.restaurantName}</div>}
            </div>

            <div style={{ background:"#FFF7ED",borderRadius:13,padding:"13px 15px",marginBottom:12,border:"1.5px solid #FED7AA" }}>
              <div style={{ fontSize:11,fontWeight:800,color:"#F97316",marginBottom:10,letterSpacing:0.4 }}>🔑 CREDENCIALES DE ACCESO AL PANEL</div>
              <div style={{ marginBottom:10 }}>
                <div style={{ fontSize:11,fontWeight:700,color:"#6B7280",marginBottom:5 }}>USUARIO (correo) *</div>
                <input value={restAccountForm.user} onChange={e=>setRA("user")(e.target.value)} placeholder="napoli@yummigo.mx" autoCapitalize="none"
                  style={{ width:"100%",padding:"10px 13px",background:"#fff",border:`2px solid ${restAccountErr.user?"#FF4D4D":"#FDBA74"}`,borderRadius:11,fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}
                  onFocus={e=>e.target.style.borderColor="#F97316"} onBlur={e=>e.target.style.borderColor=restAccountErr.user?"#FF4D4D":"#FDBA74"}/>
                {restAccountErr.user&&<div style={{ fontSize:11,color:"#FF4D4D",marginTop:2 }}>{restAccountErr.user}</div>}
              </div>
              <div>
                <div style={{ fontSize:11,fontWeight:700,color:"#6B7280",marginBottom:5 }}>CONTRASEÑA *</div>
                <input value={restAccountForm.pass} onChange={e=>setRA("pass")(e.target.value)} placeholder="Mínimo 6 caracteres"
                  style={{ width:"100%",padding:"10px 13px",background:"#fff",border:`2px solid ${restAccountErr.pass?"#FF4D4D":"#FDBA74"}`,borderRadius:11,fontSize:14,fontFamily:"monospace",color:"#111",outline:"none",boxSizing:"border-box" }}
                  onFocus={e=>e.target.style.borderColor="#F97316"} onBlur={e=>e.target.style.borderColor=restAccountErr.pass?"#FF4D4D":"#FDBA74"}/>
                {restAccountErr.pass&&<div style={{ fontSize:11,color:"#FF4D4D",marginTop:2 }}>{restAccountErr.pass}</div>}
              </div>
              <div style={{ marginTop:8,fontSize:11,color:"#92400E",lineHeight:1.5 }}>💡 El restaurante usará estas credenciales para acceder a su panel de pedidos.</div>
            </div>

            <div style={{ marginBottom:14 }}>
              <div style={{ fontSize:11,fontWeight:700,color:"#6B7280",marginBottom:5 }}>TELÉFONO DE CONTACTO</div>
              <input value={restAccountForm.phone} onChange={e=>setRA("phone")(e.target.value)} placeholder="473-000-0000"
                style={{ width:"100%",padding:"10px 13px",background:"#F9FAFB",border:"2px solid #F3F4F6",borderRadius:11,fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}
                onFocus={e=>e.target.style.borderColor="#F97316"} onBlur={e=>e.target.style.borderColor="#F3F4F6"}/>
            </div>

            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18 }}>
              <span style={{ fontSize:14,fontWeight:700,color:"#111" }}>Cuenta activa</span>
              <Toggle value={restAccountForm.active} onChange={()=>setRA("active")(!restAccountForm.active)}/>
            </div>
            <button onClick={saveRestAccount} style={{ width:"100%",padding:"15px",background:"#F97316",color:"#fff",border:"none",borderRadius:13,fontSize:15,fontWeight:700,cursor:"pointer",fontFamily:"inherit",boxShadow:"0 4px 14px rgba(249,115,22,0.35)" }}>
              {editRestAccount?"Guardar cambios ✓":"Crear cuenta de restaurante ✓"}
            </button>
          </div>
        </div>
      )}

      {/* Driver modal */}
      {driverModal&&(
        <div style={{ position:"fixed",inset:0,background:"rgba(0,0,0,0.5)",zIndex:700,display:"flex",alignItems:"flex-end",justifyContent:"center" }} onClick={()=>setDriverModal(false)}>
          <div onClick={e=>e.stopPropagation()} style={{ background:"#fff",width:"100%",maxWidth:430,borderRadius:"24px 24px 0 0",padding:"20px 24px 36px",maxHeight:"92vh",overflowY:"auto" }}>
            <div style={{ width:40,height:4,background:"#E5E7EB",borderRadius:99,margin:"0 auto 18px" }}/>
            <div style={{ fontSize:17,fontWeight:800,color:"#111",marginBottom:18 }}>{editDriver?"✏️ Editar repartidor":"➕ Nuevo repartidor"}</div>
            <div style={{ marginBottom:12 }}><div style={{ fontSize:11,fontWeight:700,color:"#6B7280",marginBottom:5 }}>NOMBRE COMPLETO *</div><input value={driverForm.name} onChange={e=>setDF("name")(e.target.value)} placeholder="Ej: Juan Pérez" style={{ width:"100%",padding:"11px 14px",background:"#F9FAFB",border:`2px solid ${driverFormErr.name?"#FF4D4D":"#F3F4F6"}`,borderRadius:11,fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}/>{driverFormErr.name&&<div style={{ fontSize:11,color:"#FF4D4D",marginTop:2 }}>{driverFormErr.name}</div>}</div>
            <div style={{ background:"#F5F3FF",borderRadius:13,padding:"13px 15px",marginBottom:12 }}>
              <div style={{ fontSize:11,fontWeight:800,color:"#6366F1",marginBottom:10,letterSpacing:0.4 }}>🔑 CREDENCIALES DE ACCESO</div>
              <div style={{ marginBottom:10 }}><div style={{ fontSize:11,fontWeight:700,color:"#6B7280",marginBottom:5 }}>USUARIO (correo) *</div><input value={driverForm.user} onChange={e=>setDF("user")(e.target.value)} placeholder="juan@yummigo.mx" autoCapitalize="none" style={{ width:"100%",padding:"10px 13px",background:"#fff",border:`2px solid ${driverFormErr.user?"#FF4D4D":"#E5E0FF"}`,borderRadius:11,fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}/>{driverFormErr.user&&<div style={{ fontSize:11,color:"#FF4D4D",marginTop:2 }}>{driverFormErr.user}</div>}</div>
              <div><div style={{ fontSize:11,fontWeight:700,color:"#6B7280",marginBottom:5 }}>CONTRASEÑA *</div><input value={driverForm.pass} onChange={e=>setDF("pass")(e.target.value)} placeholder="Mínimo 6 caracteres" style={{ width:"100%",padding:"10px 13px",background:"#fff",border:`2px solid ${driverFormErr.pass?"#FF4D4D":"#E5E0FF"}`,borderRadius:11,fontSize:14,fontFamily:"monospace",color:"#111",outline:"none",boxSizing:"border-box" }}/>{driverFormErr.pass&&<div style={{ fontSize:11,color:"#FF4D4D",marginTop:2 }}>{driverFormErr.pass}</div>}</div>
            </div>
            <div style={{ marginBottom:12 }}><div style={{ fontSize:11,fontWeight:700,color:"#6B7280",marginBottom:5 }}>TELÉFONO</div><input value={driverForm.phone} onChange={e=>setDF("phone")(e.target.value)} placeholder="449-000-0000" style={{ width:"100%",padding:"10px 13px",background:"#F9FAFB",border:"2px solid #F3F4F6",borderRadius:11,fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}/></div>
            <div style={{ display:"flex",gap:10,marginBottom:12 }}>
              <div style={{ flex:2 }}><div style={{ fontSize:11,fontWeight:700,color:"#6B7280",marginBottom:5 }}>VEHÍCULO</div><input value={driverForm.vehicle} onChange={e=>setDF("vehicle")(e.target.value)} placeholder="Honda CB125" style={{ width:"100%",padding:"10px 13px",background:"#F9FAFB",border:"2px solid #F3F4F6",borderRadius:11,fontSize:14,fontFamily:"inherit",color:"#111",outline:"none",boxSizing:"border-box" }}/></div>
              <div style={{ flex:1 }}><div style={{ fontSize:11,fontWeight:700,color:"#6B7280",marginBottom:5 }}>PLACA</div><input value={driverForm.plate} onChange={e=>setDF("plate")(e.target.value.toUpperCase())} placeholder="ABC-123" style={{ width:"100%",padding:"10px 13px",background:"#F9FAFB",border:"2px solid #F3F4F6",borderRadius:11,fontSize:14,fontFamily:"monospace",color:"#111",outline:"none",boxSizing:"border-box" }}/></div>
            </div>
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18 }}><span style={{ fontSize:14,fontWeight:700,color:"#111" }}>Cuenta activa</span><Toggle value={driverForm.active} onChange={()=>setDF("active")(!driverForm.active)}/></div>
            <button onClick={saveDriver} style={{ width:"100%",padding:"15px",background:"#6366F1",color:"#fff",border:"none",borderRadius:13,fontSize:15,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>{editDriver?"Guardar cambios ✓":"Crear repartidor ✓"}</button>
          </div>
        </div>
      )}
    </div>
  );
}


function RestForm({ initial, onSave, onClose }) {
  const [form,setForm]=useState(initial||{name:"",cuisine:"",emoji:"🍽️",address:"",phone:"",hours:"",active:true});
  const [saving,setSaving]=useState(false);
  const set=k=>v=>setForm(f=>({...f,[k]:v}));
  return <>
    <div style={{ marginBottom:14 }}>
      <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:8 }}>EMOJI</div>
      <div style={{ display:"flex",flexWrap:"wrap",gap:8 }}>
        {EMOJIS.map(e=><div key={e} onClick={()=>set("emoji")(e)} style={{ width:42,height:42,borderRadius:12,fontSize:22,display:"flex",alignItems:"center",justifyContent:"center",background:form.emoji===e?"#FF4D4D":"#F9FAFB",border:`1.5px solid ${form.emoji===e?"#FF4D4D":"#F3F4F6"}`,cursor:"pointer" }}>{e}</div>)}
      </div>
    </div>
    <Field label="NOMBRE" value={form.name} onChange={set("name")} placeholder="Ej: Nápoli Pizza"/>
    <Field label="TIPO DE COCINA" value={form.cuisine} onChange={set("cuisine")} placeholder="Ej: Italiana · Pizza"/>
    <Field label="DIRECCIÓN" value={form.address} onChange={set("address")} placeholder="Calle, colonia"/>
    <Field label="TELÉFONO" value={form.phone} onChange={set("phone")} placeholder="55 0000 0000"/>
    <Field label="HORARIO" value={form.hours} onChange={set("hours")} placeholder="12:00 - 23:00"/>
    <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20 }}>
      <span style={{ fontSize:14,fontWeight:700,color:"#111" }}>Restaurante activo</span><Toggle value={form.active} onChange={()=>set("active")(!form.active)}/>
    </div>
    <button onClick={async()=>{if(!form.name)return;setSaving(true);await onSave(form);setSaving(false);onClose();}} style={{ width:"100%",padding:"15px",background:saving?"#9CA3AF":"#FF4D4D",color:"#fff",border:"none",borderRadius:14,fontSize:15,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>{saving?"Guardando…":"Guardar ✓"}</button>
  </>;
}
function ItemForm({ initial, onSave, onClose }) {
  const [form,setForm]=useState(initial||{name:"",description:"",price:"",category:"Otros",available:true});
  const [saving,setSaving]=useState(false);
  const set=k=>v=>setForm(f=>({...f,[k]:v}));
  return <>
    <Field label="NOMBRE" value={form.name} onChange={set("name")} placeholder="Ej: Pizza Margherita"/>
    <Field label="DESCRIPCIÓN" value={form.description} onChange={set("description")} placeholder="Ingredientes"/>
    <Field label="PRECIO ($)" value={form.price} onChange={set("price")} type="number" placeholder="0"/>
    <div style={{ marginBottom:14 }}>
      <div style={{ fontSize:12,fontWeight:700,color:"#6B7280",marginBottom:8 }}>CATEGORÍA</div>
      <div style={{ display:"flex",flexWrap:"wrap",gap:8 }}>
        {CATS.map(c=><div key={c} onClick={()=>set("category")(c)} style={{ padding:"6px 12px",borderRadius:99,fontSize:12,fontWeight:700,background:form.category===c?CAT_COLORS[c]||"#FF4D4D":"#F9FAFB",color:form.category===c?"#fff":"#6B7280",border:`1.5px solid ${form.category===c?"transparent":"#F3F4F6"}`,cursor:"pointer" }}>{c}</div>)}
      </div>
    </div>
    <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20 }}>
      <span style={{ fontSize:14,fontWeight:700 }}>Disponible</span><Toggle value={form.available} onChange={()=>set("available")(!form.available)}/>
    </div>
    <button onClick={async()=>{if(!form.name||!form.price)return;setSaving(true);await onSave({...form,price:parseFloat(form.price)});setSaving(false);onClose();}} style={{ width:"100%",padding:"15px",background:saving?"#9CA3AF":"#FF4D4D",color:"#fff",border:"none",borderRadius:14,fontSize:15,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>{saving?"Guardando…":"Guardar ✓"}</button>
  </>;
}


// ─────────────────────────────────────────
// RESTAURANT CREDENTIALS (stored in localStorage by admin)
// ─────────────────────────────────────────
const loadRestaurantAccounts = () => {
  try {
    const saved = JSON.parse(localStorage.getItem("yg_rest_accounts")||"null");
    if(saved) return saved;
    return []; // Admin creates these from Admin Panel
  } catch { return []; }
};
const saveRestaurantAccounts = (list) => localStorage.setItem("yg_rest_accounts", JSON.stringify(list));

// ─────────────────────────────────────────
// RESTAURANT PANEL SCREEN
// ─────────────────────────────────────────
function RestaurantPanelScreen({ onBack, session, onLogout }) {
  const [orders, setOrders]           = useState([]);
  const [loading, setLoading]         = useState(true);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [tab, setTab]                 = useState("pending"); // pending | active | history
  const [pulse, setPulse]             = useState(false);
  const [countdown, setCountdown]     = useState({});
  const [rejectModal, setRejectModal] = useState(null);
  const [rejectReason, setRejectReason] = useState("");

  const STATUS_COLOR = { pending:"#F59E0B",confirmed:"#6366F1",preparing:"#F97316",ready:"#8B5CF6",delivering:"#2563EB",delivered:"#16A34A",cancelled:"#EF4444",rejected:"#EF4444" };
  const STATUS_LABEL = { pending:"Nuevo pedido",confirmed:"Confirmado",preparing:"En preparación",ready:"Listo para recolectar",delivering:"En camino",delivered:"Entregado",cancelled:"Cancelado",rejected:"Rechazado" };
  const STATUS_ICON  = { pending:"🔔",confirmed:"✅",preparing:"👨‍🍳",ready:"📦",delivering:"🛵",delivered:"🎉",cancelled:"❌",rejected:"🚫" };

  // Load orders for this restaurant
  const loadOrders = () => {
    sbGet("orders", `restaurant_name=eq.${encodeURIComponent(session.restaurantName)}&order=created_at.desc&limit=50`)
      .then(d => { setOrders(Array.isArray(d)?d:[]); setLoading(false); });
  };

  useEffect(() => {
    loadOrders();
    const t1 = setInterval(loadOrders, 8000); // poll every 8s
    const t2 = setInterval(() => setPulse(p=>!p), 800);
    return () => { clearInterval(t1); clearInterval(t2); };
  }, [session.restaurantName]);

  // Countdown timer for pending orders (2 min to accept)
  useEffect(() => {
    const t = setInterval(() => {
      const now = Date.now();
      const cd = {};
      orders.filter(o=>o.status==="pending").forEach(o => {
        const created = new Date(o.created_at).getTime();
        const elapsed = Math.floor((now - created) / 1000);
        const remaining = Math.max(0, 120 - elapsed);
        cd[o.id] = remaining;
      });
      setCountdown(cd);
    }, 1000);
    return () => clearInterval(t);
  }, [orders]);

  const updateStatus = async (order, newStatus, extra={}) => {
    await sbPatch("orders", order.id, { status: newStatus, ...extra });
    setOrders(p => p.map(o => o.id===order.id ? {...o, status:newStatus, ...extra} : o));
    if(selectedOrder?.id===order.id) setSelectedOrder({...order, status:newStatus, ...extra});
  };

  const acceptOrder = (order) => updateStatus(order, "confirmed");
  const startPrep   = (order) => updateStatus(order, "preparing");
  const markReady   = (order) => updateStatus(order, "ready");
  const rejectOrder = (order) => {
    updateStatus(order, "rejected", { rejection_reason: rejectReason });
    setRejectModal(null); setRejectReason("");
  };

  const pendingOrders  = orders.filter(o=>o.status==="pending");
  const activeOrders   = orders.filter(o=>["confirmed","preparing","ready","delivering"].includes(o.status));
  const historyOrders  = orders.filter(o=>["delivered","cancelled","rejected"].includes(o.status));

  const currentList = tab==="pending"?pendingOrders:tab==="active"?activeOrders:historyOrders;

  // Driver tracking progress (simulated based on status)
  const driverProgress = selectedOrder?.status==="delivering" ? 65 : selectedOrder?.status==="ready" ? 20 : 0;

  if(selectedOrder) {
    const o = selectedOrder;
    const items = Array.isArray(o.items) ? o.items : [];
    const isPending   = o.status==="pending";
    const isConfirmed = o.status==="confirmed";
    const isPreparing = o.status==="preparing";
    const isReady     = o.status==="ready";
    const isDelivering= o.status==="delivering";
    const isDone      = ["delivered","cancelled","rejected"].includes(o.status);

    return (
      <div style={{ background:"#F9FAFB", minHeight:"100vh", paddingBottom:100 }}>
        {/* Header */}
        <div style={{ background:"#fff",padding:"14px 24px 14px",borderBottom:"1px solid #F3F4F6",position:"sticky",top:0,zIndex:90 }}>
          <div style={{ display:"flex",alignItems:"center",gap:12 }}>
            <div onClick={()=>setSelectedOrder(null)} style={{ width:36,height:36,borderRadius:10,background:"#F9FAFB",border:"1.5px solid #F3F4F6",fontSize:16,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center" }}>←</div>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:15,fontWeight:800,color:"#111" }}>Pedido #{o.id}</div>
              <div style={{ fontSize:11,color:"#9CA3AF" }}>{o.created_at?new Date(o.created_at).toLocaleString("es-MX",{day:"numeric",month:"short",hour:"2-digit",minute:"2-digit"}):"—"}</div>
            </div>
            <div style={{ background:`${STATUS_COLOR[o.status]||"#6B7280"}18`,color:STATUS_COLOR[o.status]||"#6B7280",fontSize:11,fontWeight:700,padding:"4px 12px",borderRadius:99,display:"flex",alignItems:"center",gap:5 }}>
              <span>{STATUS_ICON[o.status]}</span> {STATUS_LABEL[o.status]}
            </div>
          </div>
        </div>

        <div style={{ padding:"16px 24px",display:"flex",flexDirection:"column",gap:14 }}>

          {/* STATUS TIMELINE */}
          <div style={{ background:"#fff",borderRadius:18,padding:"16px 18px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
            <div style={{ fontSize:13,fontWeight:800,color:"#111",marginBottom:14 }}>📍 Estado del pedido</div>
            {[
              {s:"pending",  l:"Nuevo pedido",          i:"🔔"},
              {s:"confirmed",l:"Confirmado",              i:"✅"},
              {s:"preparing",l:"En preparación",         i:"👨‍🍳"},
              {s:"ready",    l:"Listo para recolectar",  i:"📦"},
              {s:"delivering",l:"Repartidor en camino",  i:"🛵"},
              {s:"delivered",l:"Entregado",              i:"🎉"},
            ].map((step,i,arr)=>{
              const statuses=["pending","confirmed","preparing","ready","delivering","delivered","cancelled","rejected"];
              const curIdx=statuses.indexOf(o.status);
              const stepIdx=statuses.indexOf(step.s);
              const done=curIdx>stepIdx&&!isDone||o.status===step.s;
              const active=o.status===step.s;
              const past=curIdx>stepIdx;
              return (
                <div key={step.s} style={{ display:"flex",gap:12,paddingBottom:i<arr.length-1?12:0,position:"relative" }}>
                  {i<arr.length-1&&<div style={{ position:"absolute",left:17,top:36,bottom:0,width:2,background:past?"#16A34A":"#F3F4F6",zIndex:0 }}/>}
                  <div style={{ width:36,height:36,borderRadius:99,flexShrink:0,zIndex:1,background:past?"#16A34A":active?"#FF4D4D":"#F9FAFB",border:`2px solid ${past?"#16A34A":active?"#FF4D4D":"#E5E7EB"}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,transition:"all 0.3s",transform:active?"scale(1.1)":"scale(1)" }}>
                    {past?<span style={{ color:"#fff",fontSize:14 }}>✓</span>:step.i}
                  </div>
                  <div style={{ paddingTop:8 }}>
                    <div style={{ fontSize:13,fontWeight:active?800:past?600:400,color:active?"#FF4D4D":past?"#374151":"#9CA3AF" }}>{step.l}</div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* DRIVER TRACKING — visible when ready or delivering */}
          {(isReady||isDelivering)&&(
            <div style={{ background:"#fff",borderRadius:18,padding:"16px 18px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
              <div style={{ fontSize:13,fontWeight:800,color:"#111",marginBottom:12 }}>🛵 Seguimiento del repartidor</div>
              {/* Mini map */}
              <div style={{ background:"#F0F4FF",borderRadius:14,height:160,position:"relative",overflow:"hidden",marginBottom:12 }}>
                <svg style={{ position:"absolute",inset:0 }} width="100%" height="100%">
                  <path d="M 40 130 Q 100 60 180 80 Q 260 100 330 30" stroke="#E5E7EB" strokeWidth="3" strokeDasharray="6 4" fill="none" strokeLinecap="round"/>
                  <path d="M 40 130 Q 100 60 180 80 Q 260 100 330 30" stroke="#FF4D4D" strokeWidth="3" fill="none" strokeLinecap="round" strokeDasharray={`${driverProgress*2.8} 999`}/>
                </svg>
                {/* Restaurant */}
                <div style={{ position:"absolute",left:20,bottom:20,width:32,height:32,borderRadius:99,background:"#FF4D4D",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,boxShadow:"0 2px 8px rgba(255,77,77,0.4)" }}>🏪</div>
                {/* Client */}
                <div style={{ position:"absolute",right:20,top:18,width:32,height:32,borderRadius:99,background:"#111",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16 }}>🏠</div>
                {/* Driver dot */}
                <div style={{ position:"absolute",left:`${18+driverProgress*0.6}%`,top:`${65-Math.sin(driverProgress*0.04)*22}%`,transform:"translate(-50%,-50%)",transition:"all 1s ease" }}>
                  <div style={{ width:34,height:34,borderRadius:99,background:isDelivering?"#6366F1":"#F97316",display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,boxShadow:`0 0 0 4px ${isDelivering?"rgba(99,102,241,0.25)":"rgba(249,115,22,0.25)"},0 4px 12px rgba(0,0,0,0.15)` }}>🛵</div>
                </div>
                {/* Status badge */}
                <div style={{ position:"absolute",top:10,left:"50%",transform:"translateX(-50%)",background:"#fff",borderRadius:99,padding:"4px 12px",fontSize:11,fontWeight:700,color:isDelivering?"#6366F1":"#F97316",boxShadow:"0 2px 8px rgba(0,0,0,0.1)",whiteSpace:"nowrap" }}>
                  {isReady?"⏳ Repartidor por llegar":"🛵 En camino al cliente"}
                </div>
              </div>
              {/* Driver info */}
              {o.driver_name&&(
                <div style={{ display:"flex",alignItems:"center",gap:12,padding:"10px 0",borderTop:"1px solid #F9FAFB" }}>
                  <div style={{ width:40,height:40,borderRadius:99,background:"linear-gradient(135deg,#6366F1,#8B5CF6)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:20 }}>🛵</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:13,fontWeight:700,color:"#111" }}>{o.driver_name}</div>
                    <div style={{ fontSize:11,color:"#9CA3AF" }}>{o.driver_vehicle||""} {o.driver_plate?`· ${o.driver_plate}`:""}</div>
                  </div>
                  <div style={{ display:"flex",gap:8 }}>
                    {o.driver_phone&&<a href={`tel:${o.driver_phone}`} style={{ textDecoration:"none" }}><div style={{ width:38,height:38,borderRadius:11,background:"#F0FDF4",display:"flex",alignItems:"center",justifyContent:"center",fontSize:18 }}>📞</div></a>}
                  </div>
                </div>
              )}
              {!o.driver_name&&<div style={{ fontSize:12,color:"#9CA3AF",textAlign:"center",padding:"6px 0" }}>Asignando repartidor...</div>}
            </div>
          )}

          {/* CLIENT INFO */}
          <div style={{ background:"#fff",borderRadius:18,padding:"16px 18px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
            <div style={{ fontSize:13,fontWeight:800,color:"#111",marginBottom:12 }}>👤 Datos del cliente</div>
            {[
              {icon:"📍",label:"Dirección de entrega",value:o.delivery_address},
              {icon:"📞",label:"Teléfono",value:o.client_phone||"—"},
              {icon:"👤",label:"Nombre",value:o.client_name||"—"},
              {icon:"💳",label:"Método de pago",value:o.payment_method},
              ...(o.note?[{icon:"📝",label:"Nota del cliente",value:o.note}]:[]),
            ].map((row,i,arr)=>(
              <div key={i} style={{ display:"flex",gap:12,padding:"9px 0",borderBottom:i<arr.length-1?"1px solid #F9FAFB":"none" }}>
                <span style={{ fontSize:18,flexShrink:0 }}>{row.icon}</span>
                <div>
                  <div style={{ fontSize:10,color:"#9CA3AF",fontWeight:700,marginBottom:2 }}>{row.label.toUpperCase()}</div>
                  <div style={{ fontSize:13,fontWeight:600,color:row.value&&row.value!=="—"?"#111":"#D1D5DB" }}>{row.value||"—"}</div>
                </div>
                {row.icon==="📞"&&row.value&&row.value!=="—"&&(
                  <a href={`tel:${row.value}`} style={{ marginLeft:"auto",textDecoration:"none" }}>
                    <div style={{ background:"#F0FDF4",borderRadius:8,padding:"4px 10px",fontSize:11,fontWeight:700,color:"#16A34A" }}>Llamar</div>
                  </a>
                )}
              </div>
            ))}
          </div>

          {/* ORDER ITEMS */}
          <div style={{ background:"#fff",borderRadius:18,padding:"16px 18px",boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
            <div style={{ fontSize:13,fontWeight:800,color:"#111",marginBottom:12 }}>🍽️ Productos del pedido</div>
            {items.map((item,i)=>(
              <div key={i} style={{ display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:i<items.length-1?"1px solid #F9FAFB":"none" }}>
                <div style={{ display:"flex",alignItems:"center",gap:10 }}>
                  <div style={{ width:28,height:28,borderRadius:8,background:"#FFF5F5",display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,fontWeight:800,color:"#FF4D4D" }}>{item.qty}</div>
                  <span style={{ fontSize:14,fontWeight:600,color:"#111" }}>{item.name}</span>
                </div>
                <span style={{ fontSize:14,fontWeight:700,color:"#374151" }}>${item.price*item.qty}</span>
              </div>
            ))}
            <div style={{ marginTop:12,paddingTop:12,borderTop:"2px solid #F3F4F6" }}>
              {[
                {l:"Subtotal",v:`$${o.subtotal||0}`},
                ...(o.discount>0?[{l:"Descuento",v:`-$${o.discount}`,c:"#16A34A"}]:[]),
                {l:"Envío",v:o.delivery_fee===0?"GRATIS":`$${o.delivery_fee||0}`,c:o.delivery_fee===0?"#16A34A":undefined},
              ].map((r,i)=>(
                <div key={i} style={{ display:"flex",justifyContent:"space-between",padding:"4px 0" }}>
                  <span style={{ fontSize:13,color:"#6B7280" }}>{r.l}</span>
                  <span style={{ fontSize:13,fontWeight:700,color:r.c||"#111" }}>{r.v}</span>
                </div>
              ))}
              <div style={{ display:"flex",justifyContent:"space-between",paddingTop:10,marginTop:6,borderTop:"2px solid #111" }}>
                <span style={{ fontSize:15,fontWeight:900 }}>Total</span>
                <span style={{ fontSize:16,fontWeight:900,color:"#FF4D4D" }}>${o.total}</span>
              </div>
            </div>
          </div>
        </div>

        {/* ACTION BUTTONS */}
        {!isDone&&(
          <div style={{ position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:430,background:"#fff",borderTop:"1px solid #F3F4F6",padding:"14px 24px 28px",zIndex:10 }}>
            {isPending&&(
              <div style={{ display:"flex",gap:10 }}>
                <button onClick={()=>setRejectModal(o)} style={{ flex:1,padding:"14px",background:"#FFF5F5",color:"#FF4D4D",border:"1.5px solid #FFE4E4",borderRadius:14,fontSize:14,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>✕ Rechazar</button>
                <button onClick={()=>acceptOrder(o)} style={{ flex:2,padding:"14px",background:"#16A34A",color:"#fff",border:"none",borderRadius:14,fontSize:14,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>✓ Aceptar pedido</button>
              </div>
            )}
            {isConfirmed&&(
              <button onClick={()=>startPrep(o)} style={{ width:"100%",padding:"16px",background:"#F97316",color:"#fff",border:"none",borderRadius:16,fontSize:15,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>👨‍🍳 Iniciar preparación</button>
            )}
            {isPreparing&&(
              <button onClick={()=>markReady(o)} style={{ width:"100%",padding:"16px",background:"#8B5CF6",color:"#fff",border:"none",borderRadius:16,fontSize:15,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>📦 Marcar como listo</button>
            )}
            {isReady&&(
              <div style={{ background:"#F5F3FF",borderRadius:14,padding:"14px 16px",textAlign:"center" }}>
                <div style={{ fontSize:14,fontWeight:700,color:"#6366F1" }}>⏳ Esperando repartidor</div>
                <div style={{ fontSize:12,color:"#9CA3AF",marginTop:4 }}>El pedido será recogido pronto</div>
              </div>
            )}
            {isDelivering&&(
              <div style={{ background:"#EEF2FF",borderRadius:14,padding:"14px 16px",textAlign:"center" }}>
                <div style={{ fontSize:14,fontWeight:700,color:"#6366F1" }}>🛵 Repartidor en camino</div>
                <div style={{ fontSize:12,color:"#9CA3AF",marginTop:4 }}>El pedido está en ruta al cliente</div>
              </div>
            )}
          </div>
        )}

        {/* Reject modal */}
        {rejectModal&&(
          <div style={{ position:"fixed",inset:0,background:"rgba(0,0,0,0.5)",zIndex:800,display:"flex",alignItems:"flex-end",justifyContent:"center" }} onClick={()=>setRejectModal(null)}>
            <div onClick={e=>e.stopPropagation()} style={{ background:"#fff",width:"100%",maxWidth:430,borderRadius:"24px 24px 0 0",padding:"20px 24px 36px" }}>
              <div style={{ width:40,height:4,background:"#E5E7EB",borderRadius:99,margin:"0 auto 18px" }}/>
              <div style={{ fontSize:17,fontWeight:800,color:"#111",marginBottom:6 }}>✕ Rechazar pedido #{rejectModal.id}</div>
              <div style={{ fontSize:13,color:"#9CA3AF",marginBottom:16 }}>Indica el motivo para informar al cliente</div>
              <div style={{ display:"flex",flexDirection:"column",gap:8,marginBottom:16 }}>
                {["Sin ingredientes disponibles","Restaurante cerrado temporalmente","Muy alta demanda en este momento","Dirección fuera de cobertura","Otro motivo"].map(r=>(
                  <div key={r} onClick={()=>setRejectReason(r)}
                    style={{ padding:"11px 14px",borderRadius:12,border:`2px solid ${rejectReason===r?"#FF4D4D":"#F3F4F6"}`,background:rejectReason===r?"#FFF5F5":"#F9FAFB",cursor:"pointer",fontSize:13,fontWeight:rejectReason===r?700:500,color:rejectReason===r?"#FF4D4D":"#374151" }}>
                    {r}
                  </div>
                ))}
              </div>
              <button onClick={()=>rejectReason&&rejectOrder(rejectModal)} disabled={!rejectReason}
                style={{ width:"100%",padding:"15px",background:rejectReason?"#FF4D4D":"#E5E7EB",color:rejectReason?"#fff":"#9CA3AF",border:"none",borderRadius:14,fontSize:15,fontWeight:700,cursor:rejectReason?"pointer":"not-allowed",fontFamily:"inherit" }}>
                Confirmar rechazo
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ── ORDERS LIST VIEW ──
  return (
    <div style={{ background:"#F9FAFB", minHeight:"100vh", paddingBottom:80 }}>
      {/* Header */}
      <div style={{ background:"#fff",padding:"14px 24px 0",borderBottom:"1px solid #F3F4F6",position:"sticky",top:0,zIndex:90 }}>
        <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12 }}>
          <div>
            <div style={{ fontSize:12,color:"#9CA3AF",fontWeight:600,letterSpacing:0.4 }}>PANEL DE RESTAURANTE</div>
            <div style={{ fontSize:18,fontWeight:900,color:"#111",display:"flex",alignItems:"center",gap:8 }}>
              {session.restaurantEmoji||"🍽️"} {session.restaurantName}
            </div>
          </div>
          <div style={{ display:"flex",flexDirection:"column",alignItems:"flex-end",gap:4 }}>
            {pendingOrders.length>0&&(
              <div style={{ background:"#FF4D4D",color:"#fff",fontSize:11,fontWeight:700,padding:"3px 10px",borderRadius:99,display:"flex",alignItems:"center",gap:5,animation:"bounce 0.6s ease",boxShadow:"0 2px 8px rgba(255,77,77,0.4)" }}>
                <div style={{ width:6,height:6,borderRadius:99,background:"#fff",opacity:pulse?1:0.4,transition:"opacity 0.4s" }}/>
                {pendingOrders.length} nuevos
              </div>
            )}
          </div>
        </div>
        {/* Stats bar */}
        <div style={{ display:"flex",gap:0,marginLeft:-24,marginRight:-24,padding:"8px 24px",background:"#F9FAFB",marginBottom:0 }}>
          {[{icon:"🔔",label:"Nuevos",count:pendingOrders.length,c:"#FF4D4D"},{icon:"⏳",label:"Activos",count:activeOrders.length,c:"#6366F1"},{icon:"✅",label:"Historial",count:historyOrders.length,c:"#16A34A"}].map((s,i)=>(
            <div key={i} style={{ flex:1,textAlign:"center",padding:"4px 0" }}>
              <div style={{ fontSize:18 }}>{s.icon}</div>
              <div style={{ fontSize:16,fontWeight:900,color:s.c }}>{s.count}</div>
              <div style={{ fontSize:10,color:"#9CA3AF" }}>{s.label}</div>
            </div>
          ))}
        </div>
        {/* Nav tabs */}
        <div style={{ display:"flex",marginLeft:-24,marginRight:-24,paddingLeft:24,paddingRight:24,borderTop:"1px solid #F3F4F6" }}>
          {[{id:"pending",l:"🔔 Nuevos",n:pendingOrders.length},{id:"active",l:"⏳ Activos",n:activeOrders.length},{id:"history",l:"📋 Historial",n:historyOrders.length}].map(t=>(
            <div key={t.id} onClick={()=>setTab(t.id)}
              style={{ flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:2,padding:"10px 0",cursor:"pointer",borderBottom:`2.5px solid ${tab===t.id?"#FF4D4D":"transparent"}`,transition:"border 0.2s",position:"relative" }}>
              <span style={{ fontSize:11,fontWeight:tab===t.id?800:500,color:tab===t.id?"#FF4D4D":"#9CA3AF" }}>{t.l}</span>
              {t.n>0&&tab!==t.id&&<div style={{ position:"absolute",top:6,right:"20%",width:14,height:14,borderRadius:99,background:"#FF4D4D",color:"#fff",fontSize:8,fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center" }}>{t.n}</div>}
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding:"14px 24px",display:"flex",flexDirection:"column",gap:10 }}>
        {loading?(
          [1,2,3].map(i=>(<div key={i} style={{ background:"#fff",borderRadius:16,padding:"16px",display:"flex",flexDirection:"column",gap:8 }}><Skeleton h={14} w="55%"/><Skeleton h={10} w="70%"/></div>))
        ):currentList.length===0?(
          <div style={{ textAlign:"center",padding:"50px 0" }}>
            <div style={{ fontSize:52 }}>{tab==="pending"?"🔔":tab==="active"?"⏳":"📋"}</div>
            <div style={{ fontSize:15,fontWeight:700,color:"#374151",marginTop:12 }}>
              {tab==="pending"?"Sin pedidos nuevos":tab==="active"?"Sin pedidos activos":"Sin historial aún"}
            </div>
            <div style={{ fontSize:13,color:"#9CA3AF",marginTop:4 }}>
              {tab==="pending"?"Los pedidos nuevos aparecerán aquí automáticamente":""}
            </div>
          </div>
        ):currentList.map(order=>{
          const items = Array.isArray(order.items)?order.items:[];
          const isPend = order.status==="pending";
          const cd = countdown[order.id];
          return (
            <div key={order.id} onClick={()=>setSelectedOrder(order)}
              style={{ background:"#fff",borderRadius:18,padding:"16px",boxShadow:`0 1px 8px rgba(0,0,0,${isPend?0.1:0.05})`,cursor:"pointer",border:`2px solid ${isPend?"#FF4D4D":"transparent"}`,position:"relative",overflow:"hidden",transition:"transform 0.15s" }}
              onMouseEnter={e=>e.currentTarget.style.transform="translateX(3px)"}
              onMouseLeave={e=>e.currentTarget.style.transform="translateX(0)"}>
              {/* Pulse bar for new orders */}
              {isPend&&<div style={{ position:"absolute",top:0,left:0,right:0,height:3,background:"#FF4D4D",animation:"shimmer 1.5s infinite" }}/>}
              <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8 }}>
                <div>
                  <div style={{ fontSize:14,fontWeight:800,color:"#111",display:"flex",alignItems:"center",gap:6 }}>
                    {STATUS_ICON[order.status]} Pedido #{order.id}
                    {isPend&&<div style={{ background:"#FF4D4D",color:"#fff",fontSize:9,fontWeight:700,padding:"2px 7px",borderRadius:99,animation:"bounce 0.6s ease" }}>NUEVO</div>}
                  </div>
                  <div style={{ fontSize:11,color:"#9CA3AF",marginTop:2 }}>{order.created_at?new Date(order.created_at).toLocaleString("es-MX",{hour:"2-digit",minute:"2-digit"}):"—"}</div>
                </div>
                <div style={{ textAlign:"right" }}>
                  <div style={{ background:`${STATUS_COLOR[order.status]||"#6B7280"}18`,color:STATUS_COLOR[order.status]||"#6B7280",fontSize:10,fontWeight:700,padding:"3px 10px",borderRadius:99 }}>{STATUS_LABEL[order.status]}</div>
                  <div style={{ fontSize:14,fontWeight:900,color:"#FF4D4D",marginTop:4 }}>${order.total}</div>
                </div>
              </div>
              <div style={{ fontSize:12,color:"#6B7280",marginBottom:8 }}>{items.map(i=>`${i.name} ×${i.qty}`).join(", ")||"—"}</div>
              <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center" }}>
                <div style={{ fontSize:11,color:"#9CA3AF",display:"flex",alignItems:"center",gap:4 }}>
                  <span>📍</span>{order.delivery_address?.split(",")[0]||"—"}
                </div>
                {isPend&&cd!==undefined&&(
                  <div style={{ background:cd<30?"#FFF5F5":"#FFFBEB",borderRadius:99,padding:"3px 10px",fontSize:11,fontWeight:700,color:cd<30?"#FF4D4D":"#F59E0B",display:"flex",alignItems:"center",gap:4 }}>
                    ⏱ {Math.floor(cd/60)}:{String(cd%60).padStart(2,"0")}
                  </div>
                )}
              </div>
              {isPend&&(
                <div style={{ display:"flex",gap:8,marginTop:12 }}>
                  <button onClick={e=>{e.stopPropagation();setRejectModal(order);}} style={{ flex:1,padding:"9px",background:"#FFF5F5",border:"1.5px solid #FFE4E4",borderRadius:10,fontSize:13,fontWeight:700,cursor:"pointer",color:"#FF4D4D",fontFamily:"inherit" }}>✕ Rechazar</button>
                  <button onClick={e=>{e.stopPropagation();acceptOrder(order);}} style={{ flex:2,padding:"9px",background:"#16A34A",border:"none",borderRadius:10,fontSize:13,fontWeight:700,cursor:"pointer",color:"#fff",fontFamily:"inherit" }}>✓ Aceptar</button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Reject modal */}
      {rejectModal&&(
        <div style={{ position:"fixed",inset:0,background:"rgba(0,0,0,0.5)",zIndex:800,display:"flex",alignItems:"flex-end",justifyContent:"center" }} onClick={()=>setRejectModal(null)}>
          <div onClick={e=>e.stopPropagation()} style={{ background:"#fff",width:"100%",maxWidth:430,borderRadius:"24px 24px 0 0",padding:"20px 24px 36px" }}>
            <div style={{ width:40,height:4,background:"#E5E7EB",borderRadius:99,margin:"0 auto 18px" }}/>
            <div style={{ fontSize:17,fontWeight:800,color:"#111",marginBottom:6 }}>✕ Rechazar pedido</div>
            <div style={{ fontSize:13,color:"#9CA3AF",marginBottom:16 }}>Selecciona el motivo</div>
            <div style={{ display:"flex",flexDirection:"column",gap:8,marginBottom:16 }}>
              {["Sin ingredientes disponibles","Restaurante cerrado temporalmente","Muy alta demanda en este momento","Dirección fuera de cobertura","Otro motivo"].map(r=>(
                <div key={r} onClick={()=>setRejectReason(r)}
                  style={{ padding:"11px 14px",borderRadius:12,border:`2px solid ${rejectReason===r?"#FF4D4D":"#F3F4F6"}`,background:rejectReason===r?"#FFF5F5":"#F9FAFB",cursor:"pointer",fontSize:13,fontWeight:rejectReason===r?700:500,color:rejectReason===r?"#FF4D4D":"#374151" }}>
                  {r}
                </div>
              ))}
            </div>
            <button onClick={()=>rejectReason&&rejectOrder(rejectModal)} disabled={!rejectReason}
              style={{ width:"100%",padding:"15px",background:rejectReason?"#FF4D4D":"#E5E7EB",color:rejectReason?"#fff":"#9CA3AF",border:"none",borderRadius:14,fontSize:15,fontWeight:700,cursor:rejectReason?"pointer":"not-allowed",fontFamily:"inherit" }}>
              Confirmar rechazo
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────
// RESTAURANT ACCOUNTS MANAGER (in Admin)
// ─────────────────────────────────────────
// [Managed inside AdminScreen config tab — see below]

// ─────────────────────────────────────────
// PROFILE SCREEN  ★ UPDATED with all 8 menu items
// ─────────────────────────────────────────
function ProfileScreen({ showToast, restaurants, menuItems, setRestaurants, setMenuItems, customerSession, onCustomerLogout, onShowAuthGate }) {
  const [view, setView] = useState("main");
  const [session, setSession] = useState(getSession);
  const addrCount = loadAddresses().length;
  const payCount  = loadPayments().length + 1;
  const isNewUser = !localStorage.getItem("hasOrdered");
  const isGuest   = !customerSession;

  const handleLogout = () => { clearSession(); setSession(null); setView("main"); };

  // ── Screens that need NO auth ──
  if(view==="addresses")     return <AddressManager          onBack={()=>setView("main")} />;
  if(view==="payments")      return <PaymentManager          onBack={()=>setView("main")} />;
  if(view==="discounts")     return <DiscountCodesScreen     onBack={()=>setView("main")} />;
  if(view==="shipping")      return <ShippingCalculatorScreen onBack={()=>setView("main")} />;
  if(view==="notifications") return <NotificationsScreen     onBack={()=>setView("main")} />;
  if(view==="help")          return <HelpCenterScreen        onBack={()=>setView("main")} showToast={showToast||(() => {})} />;

  // ── RESTAURANT PANEL — requires restaurant or admin session ──
  if(view==="restaurant") {
    const ok = session && (session.role==="restaurant" || session.role==="admin");
    if(!ok) return (
      <LoginScreen role="restaurant" onBack={()=>setView("main")}
        onSuccess={(s)=>{ setSession(s); }}/>
    );
    return (
      <div>
        <div style={{ background:"#fff",padding:"10px 24px 10px",borderBottom:"1px solid #F3F4F6",display:"flex",justifyContent:"space-between",alignItems:"center" }}>
          <button onClick={()=>setView("main")} style={{ background:"none",border:"none",fontSize:13,fontWeight:700,color:"#6B7280",cursor:"pointer",display:"flex",alignItems:"center",gap:6 }}>← Volver</button>
          <div style={{ fontSize:12,fontWeight:700,color:"#F97316" }}>🍽️ {session.restaurantName||"Restaurante"}</div>
          <button onClick={handleLogout} style={{ background:"#FFF7ED",border:"none",borderRadius:8,padding:"6px 12px",fontSize:12,fontWeight:700,color:"#F97316",cursor:"pointer",fontFamily:"inherit" }}>Cerrar sesión</button>
        </div>
        <RestaurantPanelScreen session={session} onBack={()=>setView("main")} onLogout={handleLogout}/>
      </div>
    );
  }

  // ── DRIVER PANEL — requires driver or admin session ──
  if(view==="driver") {
    const ok = session && (session.role==="driver" || session.role==="admin");
    if(!ok) return (
      <LoginScreen role="driver" onBack={()=>setView("main")}
        onSuccess={(s)=>{ setSession(s); setSession(s); }}/>
    );
    return (
      <div>
        <div style={{ background:"#fff",padding:"10px 24px 10px",borderBottom:"1px solid #F3F4F6",display:"flex",justifyContent:"space-between",alignItems:"center" }}>
          <button onClick={()=>setView("main")} style={{ background:"none",border:"none",fontSize:13,fontWeight:700,color:"#6B7280",cursor:"pointer",display:"flex",alignItems:"center",gap:6 }}>← Volver</button>
          <div style={{ fontSize:12,color:"#9CA3AF" }}>👤 {session.name}</div>
          <button onClick={handleLogout} style={{ background:"#FFF5F5",border:"none",borderRadius:8,padding:"6px 12px",fontSize:12,fontWeight:700,color:"#FF4D4D",cursor:"pointer",fontFamily:"inherit" }}>Cerrar sesión</button>
        </div>
        <DriverScreen/>
      </div>
    );
  }

  // ── ADMIN PANEL — requires admin session only ──
  if(view==="admin") {
    if(!session || session.role!=="admin") return (
      <LoginScreen role="admin" onBack={()=>setView("main")}
        onSuccess={(s)=>{ setSession(s); }}/>
    );
    return (
      <div>
        <div style={{ background:"#fff",padding:"10px 24px 10px",borderBottom:"1px solid #F3F4F6",display:"flex",justifyContent:"space-between",alignItems:"center" }}>
          <button onClick={()=>setView("main")} style={{ background:"none",border:"none",fontSize:13,fontWeight:700,color:"#6B7280",cursor:"pointer",display:"flex",alignItems:"center",gap:6 }}>← Volver</button>
          <div style={{ fontSize:12,fontWeight:700,color:"#6366F1" }}>⚙️ Admin</div>
          <button onClick={handleLogout} style={{ background:"#EEF2FF",border:"none",borderRadius:8,padding:"6px 12px",fontSize:12,fontWeight:700,color:"#6366F1",cursor:"pointer",fontFamily:"inherit" }}>Cerrar sesión</button>
        </div>
        <AdminScreen restaurants={restaurants||[]} menuItems={menuItems||[]} setRestaurants={setRestaurants||(() => {})} setMenuItems={setMenuItems||(() => {})} showToast={showToast||(() => {})}/>
      </div>
    );
  }

  const MENU_ITEMS = [
    { icon:"📍", label:"Direcciones de entrega",   sub:addrCount===0?"Sin direcciones guardadas":`${addrCount} guardada${addrCount!==1?"s":""}`,  view:"addresses",    badge:null,              locked:false, accent:"#FFF0F0" },
    { icon:"💳", label:"Métodos de pago",           sub:`${payCount} método${payCount!==1?"s":""} disponible${payCount!==1?"s":""}`,               view:"payments",     badge:null,              locked:false, accent:"#FFF0F0" },
    { icon:"🎁", label:"Códigos de descuento",      sub:"Descuentos y cupones activos",                                                             view:"discounts",    badge:isNewUser?"Nuevo":null, locked:false, accent:"#FFF0F0" },
    { icon:"🚚", label:"Calculadora de Envío",      sub:"Tarifa real por kilómetro",                                                                view:"shipping",     badge:null,              locked:false, accent:"#FFF0F0" },
    { icon:"🍽️", label:"Panel de Restaurante",      sub:"Gestión de pedidos en tiempo real",                                                        view:"restaurant",   badge:"🔒",              locked:true,  accent:"#FFF7ED", lockColor:"#F97316", lockBg:"#FFF7ED" },
    { icon:"🛵", label:"Panel del Repartidor",      sub:"Requiere inicio de sesión",                                                                view:"driver",       badge:"🔒",              locked:true,  accent:"#F0EEFF", lockColor:"#FF4D4D", lockBg:"#FFF0F0" },
    { icon:"⚙️", label:"Panel de Admin",            sub:"Solo administradores",                                                                     view:"admin",        badge:"🔒",              locked:true,  accent:"#F0EEFF", lockColor:"#6366F1", lockBg:"#EEF2FF" },
    { icon:"🔔", label:"Notificaciones",             sub:"Alertas de pedidos y promos",                                                              view:"notifications",badge:null,              locked:false, accent:"#FFF0F0" },
    { icon:"❓", label:"Centro de Ayuda",            sub:"FAQ y canales de soporte",                                                                 view:"help",         badge:null,              locked:false, accent:"#FFF0F0" },
  ];

  return (
    <div style={{ background:"#F9FAFB", minHeight:"100vh", paddingBottom:100 }}>
      {/* Header */}
      <div style={{ background:"#fff", padding:"14px 24px 20px", borderBottom:"1px solid #F3F4F6" }}>
        <div style={{ fontSize:13,color:"#9CA3AF",fontWeight:500 }}>Mi cuenta</div>
        <div style={{ fontSize:20,fontWeight:900,color:"#111" }}>Perfil</div>
      </div>

      {/* Avatar */}
      <div style={{ padding:"24px 24px 0",display:"flex",flexDirection:"column",alignItems:"center",gap:10 }}>
        {isGuest ? (
          <>
            <div style={{ width:76,height:76,borderRadius:99,background:"#F3F4F6",display:"flex",alignItems:"center",justifyContent:"center",fontSize:32,border:"3px dashed #E5E7EB" }}>👤</div>
            <div style={{ fontSize:18,fontWeight:800,color:"#111" }}>Modo Invitado</div>
            <div style={{ fontSize:13,color:"#9CA3AF",textAlign:"center",lineHeight:1.5 }}>Navega libremente. Necesitas una cuenta para ordenar.</div>
            <div style={{ display:"flex",gap:10,marginTop:4,width:"100%" }}>
              <button onClick={onShowAuthGate}
                style={{ flex:1,padding:"12px",background:"#FF4D4D",color:"#fff",border:"none",borderRadius:13,fontSize:14,fontWeight:700,cursor:"pointer",fontFamily:"inherit",boxShadow:"0 3px 12px rgba(255,77,77,0.3)" }}>
                ✨ Crear cuenta
              </button>
              <button onClick={onShowAuthGate}
                style={{ flex:1,padding:"12px",background:"#F9FAFB",color:"#111",border:"1.5px solid #F3F4F6",borderRadius:13,fontSize:14,fontWeight:700,cursor:"pointer",fontFamily:"inherit" }}>
                Iniciar sesión
              </button>
            </div>
          </>
        ) : (
          <>
            <div style={{ width:76,height:76,borderRadius:99,background:"linear-gradient(135deg,#FF4D4D,#FF6B6B)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:34,boxShadow:"0 4px 20px rgba(255,77,77,0.3)" }}>
              {customerSession.name?.[0]?.toUpperCase()||"👤"}
            </div>
            <div style={{ fontSize:18,fontWeight:800,color:"#111" }}>{customerSession.name}</div>
            <div style={{ fontSize:13,color:"#9CA3AF" }}>📱 {customerSession.phone}</div>
            {customerSession.email&&<div style={{ fontSize:12,color:"#9CA3AF" }}>✉️ {customerSession.email}</div>}
            <div style={{ display:"flex",alignItems:"center",gap:6,marginTop:2 }}>
              <span style={{ fontSize:14 }}>🌶️</span>
              <span style={{ fontSize:13,color:"#9CA3AF" }}>Aguascalientes</span>
            </div>
            {isNewUser&&(
              <div style={{ background:"linear-gradient(90deg,#FF4D4D,#FF6B6B)",color:"#fff",fontSize:12,fontWeight:700,padding:"5px 16px",borderRadius:99,marginTop:4,boxShadow:"0 2px 10px rgba(255,77,77,0.3)" }}>
                🎁 Tienes envío gratis disponible
              </div>
            )}
          </>
        )}
      </div>

      {/* Menu list — matches screenshot exactly */}
      <div style={{ padding:"20px 24px 0" }}>
        <div style={{ background:"#fff",borderRadius:20,overflow:"hidden",boxShadow:"0 1px 8px rgba(0,0,0,0.06)" }}>
          {MENU_ITEMS.map((item, i) => (
            <div key={item.view} onClick={()=>setView(item.view)}
              style={{ display:"flex",alignItems:"center",gap:14,padding:"17px 20px",cursor:"pointer",borderBottom:i<MENU_ITEMS.length-1?"1px solid #F7F7F7":"none",transition:"background 0.15s" }}
              onMouseEnter={e=>e.currentTarget.style.background="#FAFAFA"}
              onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
              <div style={{ width:44,height:44,borderRadius:12,background:item.locked?"#F0EEFF":"#FFF0F0",display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0 }}>
                {item.icon}
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:15,fontWeight:600,color:"#111",display:"flex",alignItems:"center",gap:6 }}>
                  {item.label}
                  {item.locked&&<span style={{ fontSize:11,color:item.view==="admin"?"#6366F1":"#FF4D4D",background:item.view==="admin"?"#EEF2FF":"#FFF0F0",padding:"1px 7px",borderRadius:99,fontWeight:700 }}>Acceso restringido</span>}
                </div>
                <div style={{ fontSize:12,color:"#9CA3AF",marginTop:2 }}>{item.sub}</div>
              </div>
              {item.badge&&!item.locked&&(
                <div style={{ background:"#FF4D4D",color:"#fff",fontSize:10,fontWeight:700,padding:"2px 8px",borderRadius:99,marginRight:6,flexShrink:0 }}>{item.badge}</div>
              )}
              <svg width="8" height="14" viewBox="0 0 8 14" fill="none" style={{ flexShrink:0,opacity:0.25 }}>
                <path d="M1 1l6 6-6 6" stroke="#111" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
          ))}
        </div>

        <div style={{ textAlign:"center",padding:"20px 0 8px",color:"#D1D5DB",fontSize:12 }}>
          Versión 1.0.0 · Aguascalientes 🌶️
        </div>
        {!isGuest&&(
          <button onClick={onCustomerLogout}
            style={{ width:"100%",padding:"13px",background:"#FFF5F5",color:"#FF4D4D",border:"1.5px solid #FFE4E4",borderRadius:14,fontSize:14,fontWeight:700,cursor:"pointer",fontFamily:"inherit",marginBottom:4 }}>
            Cerrar sesión
          </button>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────
// SPLASH SCREEN
// ─────────────────────────────────────────
function SplashScreen({ onDone }) {
  const [phase, setPhase] = useState("in");
  useEffect(()=>{
    const t1=setTimeout(()=>setPhase("hold"),400);
    const t2=setTimeout(()=>setPhase("out"),2600);
    const t3=setTimeout(()=>onDone(),3200);
    return()=>{ clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  },[]);
  return (
    <div style={{ position:"fixed",inset:0,zIndex:9999,background:"linear-gradient(160deg,#1a1a1a 0%,#111 60%,#0a0a0a 100%)",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",transition:"opacity 0.6s ease",opacity:phase==="out"?0:1 }}>
      <style>{`
        @keyframes logoIn{from{opacity:0;transform:scale(0.8) translateY(20px)}to{opacity:1;transform:scale(1) translateY(0)}}
        @keyframes logoFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-12px)}}
        @keyframes glowPulse{0%,100%{opacity:0.3}50%{opacity:0.6}}
        @keyframes tagIn{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
        @keyframes dot1{0%,80%,100%{transform:scale(0.4);opacity:0.3}40%{transform:scale(1);opacity:1}}
        @keyframes dot2{0%,80%,100%{transform:scale(0.4);opacity:0.3}40%{transform:scale(1);opacity:1}}
        @keyframes dot3{0%,80%,100%{transform:scale(0.4);opacity:0.3}40%{transform:scale(1);opacity:1}}
      `}</style>
      <div style={{ position:"absolute",top:0,left:0,right:0,height:3,background:"linear-gradient(90deg,#FF4D4D,#FF6B6B,#FF4D4D)",animation:"glowPulse 2s ease-in-out infinite" }}/>
      <div style={{ animation:phase==="hold"?"logoFloat 2s ease-in-out infinite":"logoIn 0.6s cubic-bezier(0.34,1.56,0.64,1) forwards",marginBottom:28,filter:"drop-shadow(0 8px 32px rgba(255,77,77,0.5))" }}>
        <div style={{ width:120,height:120,borderRadius:36,background:"rgba(255,77,77,0.15)",backdropFilter:"blur(12px)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:64,boxShadow:"0 8px 40px rgba(0,0,0,0.3)",border:"1px solid rgba(255,255,255,0.1)" }}>🛵</div>
      </div>
      <div style={{ animation:"tagIn 0.5s ease 0.2s both",textAlign:"center",marginBottom:8 }}>
        <div style={{ fontSize:44,fontWeight:900,lineHeight:1,letterSpacing:-1 }}>
          <span style={{ color:"#FF4D4D" }}>Yummi</span><span style={{ color:"#fff" }}>Go</span><span style={{ color:"rgba(255,255,255,0.35)",fontSize:28,fontWeight:700 }}>App</span>
        </div>
      </div>
      <div style={{ animation:"tagIn 0.5s ease 0.5s both",textAlign:"center" }}>
        <div style={{ fontSize:15,color:"rgba(255,255,255,0.5)",fontWeight:500 }}>Tu comida favorita, a un toque 🔥</div>
      </div>
      <div style={{ position:"absolute",bottom:64,display:"flex",gap:10 }}>
        {[{delay:"0s",color:"#FF4D4D"},{delay:"0.15s",color:"#FF6B6B"},{delay:"0.3s",color:"#FF4D4D"}].map((d,i)=>(
          <div key={i} style={{ width:9,height:9,borderRadius:"50%",background:d.color,animation:`dot${i+1} 1.2s ease-in-out ${d.delay} infinite` }}/>
        ))}
      </div>
      <div style={{ position:"absolute",bottom:34,fontSize:12,color:"rgba(255,255,255,0.25)" }}>Aguascalientes 🌶️</div>
      <div style={{ position:"absolute",bottom:0,left:0,right:0,height:3,background:"linear-gradient(90deg,#FF4D4D,#FF6B6B,#FF4D4D)" }}/>
    </div>
  );
}

// ─────────────────────────────────────────
// ROOT APP
// ─────────────────────────────────────────
export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [tab, setTab]               = useState("home");
  const [screen, setScreen]         = useState("home");
  const [restaurants, setRestaurants] = useState([]);
  const [menuItems, setMenuItems]     = useState([]);
  const [loading, setLoading]         = useState(true);
  const [selectedRest, setSelectedRest] = useState(null);
  const [orderNumber, setOrderNumber]   = useState(null);
  const [trackingOrder, setTrackingOrder] = useState(null);
  const [toast, setToast]     = useState(null);
  const [globalCart, setGlobalCart] = useState([]);

  // ── Customer session (guest by default) ──
  const [customerSession, setCustomerSessionState] = useState(()=>getCustomerSession());
  const [showAuthGate, setShowAuthGate] = useState(false);
  const [pendingCheckout, setPendingCheckout] = useState(false);

  const isGuest = !customerSession;

  const handleCustomerLogin = (session) => {
    setCustomerSessionState(session);
    setShowAuthGate(false);
    if(pendingCheckout) { setPendingCheckout(false); setScreen("checkout"); }
  };
  const handleCustomerLogout = () => { clearCustomerSession(); setCustomerSessionState(null); };

  const showToast = (msg, type="success") => { setToast({msg,type}); setTimeout(()=>setToast(null),2500); };

  useEffect(()=>{
    Promise.all([
      sbGet("restaurants","active=eq.true&order=rating.desc"),
      sbGet("menu_items","available=eq.true&order=category.asc,name.asc"),
    ]).then(([rests,items])=>{
      // Use DB data if available, otherwise show demo data
      const restData  = Array.isArray(rests)  && rests.length  > 0 ? rests  : DEMO_RESTAURANTS;
      const itemData  = Array.isArray(items)  && items.length  > 0 ? items  : DEMO_MENU_ITEMS;
      setRestaurants(restData);
      setMenuItems(itemData);
      setLoading(false);
    }).catch(()=>{
      setRestaurants(DEMO_RESTAURANTS);
      setMenuItems(DEMO_MENU_ITEMS);
      setLoading(false);
    });
  },[]);

  const updateGlobalCart = (item, delta) => {
    setGlobalCart(prev=>{
      const ex=prev.find(i=>i.id===item.id);
      if(!ex&&delta>0) return [...prev,{...item,qty:1}];
      return prev.map(i=>i.id===item.id?{...i,qty:i.qty+delta}:i).filter(i=>i.qty>0);
    });
  };

  const [autoPromo, setAutoPromo] = useState(null);

  const handleSelectRestaurant = (r, promo=null) => {
    setSelectedRest(r); setAutoPromo(promo);
    // Require login before checkout
    if(isGuest) { setPendingCheckout(true); setShowAuthGate(true); }
    else { setScreen("checkout"); }
  };
  const handleOrderPlaced  = (num) => {
    // Update customer stats
    if(customerSession) {
      const customers = loadCustomers();
      const updated = customers.map(c => c.id===customerSession.id ? {...c, totalOrders:(c.totalOrders||0)+1} : c);
      saveCustomers(updated);
    }
    setOrderNumber(num); setGlobalCart([]); setScreen("placed");
  };
  const handleTrack        = (id,name) => { setTrackingOrder({id,name}); setScreen("tracking"); };
  const handleCartCheckout = () => {
    if(isGuest) { setPendingCheckout(true); setShowAuthGate(true); return; }
    if(selectedRest) setScreen("checkout");
    else if(globalCart.length>0){ setSelectedRest(restaurants.find(r=>r.id===globalCart[0]?.restaurant_id)||null); setScreen("checkout"); }
  };

  const showNav  = screen==="home";
  const cartCount = globalCart.reduce((s,i)=>s+i.qty,0);

  return (
    <div style={{ fontFamily:"'DM Sans','Helvetica Neue',sans-serif",background:"#F9FAFB",height:"100vh",maxWidth:430,margin:"0 auto",position:"relative",overflowY:"auto",overflowX:"hidden" }}>
      <style>{`
        @keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}
        @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
        @keyframes bounce{0%,100%{transform:scale(1)}50%{transform:scale(1.2)}}
        *{box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
        html,body{margin:0;padding:0;height:100%;}
        ::-webkit-scrollbar{display:none}
      `}</style>

      {showSplash && <SplashScreen onDone={()=>setShowSplash(false)}/>}
      {toast && <Toast msg={toast.msg} type={toast.type}/>}

      {/* Customer auth gate */}
      {showAuthGate && <CheckoutAuthGate onSuccess={handleCustomerLogin} onClose={()=>{ setShowAuthGate(false); setPendingCheckout(false); }}/>}

      {screen==="checkout"&&selectedRest&&(
        <CheckoutScreen restaurant={selectedRest} onBack={()=>setScreen("home")} onOrderPlaced={handleOrderPlaced} initialPromo={autoPromo} customerSession={customerSession}/>
      )}
      {screen==="placed"&&(
        <OrderPlacedScreen orderNumber={orderNumber} restaurant={selectedRest} onTrack={()=>{ setScreen("tracking"); setTrackingOrder({id:orderNumber,name:selectedRest?.name}); }}/>
      )}
      {screen==="tracking"&&(
        <TrackingScreen orderNumber={trackingOrder?.id} restaurant={selectedRest||{name:trackingOrder?.name,emoji:"🍽️"}} onBack={()=>{ setScreen("home"); setTab("orders"); }}/>
      )}

      {screen==="home"&&(
        <div style={{ height:"100%",overflowY:"auto",WebkitOverflowScrolling:"touch" }}>
          {tab==="home"&&(
            <HomeScreen restaurants={restaurants} loading={loading} onSelectRestaurant={handleSelectRestaurant}
              globalCart={globalCart} onUpdateGlobalCart={updateGlobalCart} onCheckout={handleCartCheckout}/>
          )}
          {tab==="orders"&&<OrdersScreen onTrack={(id,name)=>{ setTrackingOrder({id,name}); setScreen("tracking"); }}/>}
          {tab==="profile"&&<ProfileScreen showToast={showToast} restaurants={restaurants} menuItems={menuItems} setRestaurants={setRestaurants} setMenuItems={setMenuItems} customerSession={customerSession} onCustomerLogout={handleCustomerLogout} onShowAuthGate={()=>setShowAuthGate(true)}/>}
        </div>
      )}

      {/* Bottom Nav — 4 tabs matching screenshot: Inicio, Buscar, Pedidos, Perfil */}
      {showNav&&(
        <div style={{ position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:430,background:"#fff",borderTop:"1px solid #F3F4F6",padding:"10px 0 20px",display:"flex",justifyContent:"space-around",zIndex:200 }}>
          {[
            { id:"home",    icon:<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>, label:"Inicio" },
            { id:"search",  icon:<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>, label:"Buscar" },
            { id:"orders",  icon:<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>, label:"Pedidos" },
            { id:"profile", icon:<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>, label:"Perfil" },
          ].map(t=>(
            <div key={t.id}
              onClick={()=>{ if(t.id==="search"){ setTab("home"); } else setTab(t.id); }}
              style={{ display:"flex",flexDirection:"column",alignItems:"center",gap:3,cursor:"pointer",position:"relative",color:tab===t.id?"#FF4D4D":"#9CA3AF",transition:"color 0.2s" }}>
              <div style={{ padding:"4px 16px",borderRadius:12,background:tab===t.id?"#FFF0F0":"transparent" }}>
                {t.icon}
              </div>
              <span style={{ fontSize:10,fontWeight:tab===t.id?700:500 }}>{t.label}</span>
              {t.id==="orders"&&cartCount>0&&(
                <div style={{ position:"absolute",top:-2,right:6,width:16,height:16,borderRadius:99,background:"#FF4D4D",color:"#fff",fontSize:9,fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",border:"2px solid #fff" }}>{cartCount}</div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
